import { defineConfig, loadEnv } from 'vite';
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(import.meta.dirname);
const WEB = path.join(ROOT, 'web');

function htmlInputs(dir, acc = {}) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'src' || entry.name === 'public') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) htmlInputs(full, acc);
    else if (entry.name.endsWith('.html')) {
      const key = path.relative(WEB, full).replace(/\\/g, '/').replace(/\.html$/, '').replace(/\//g, '_') || 'index';
      acc[key] = full;
    }
  }
  return acc;
}

/** Serves /api/* from the same handlers Vercel runs, so `npm run dev` works end to end. */
function localApi() {
  return {
    name: 'local-api',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url.startsWith('/api/')) return next();
        const name = req.url.slice(5).split('?')[0];
        const file = path.join(ROOT, 'api', `${name}.js`);
        if (!/^[a-z-]+$/.test(name) || !fs.existsSync(file)) { res.statusCode = 404; return res.end('Not found'); }
        try {
          const mod = await server.ssrLoadModule(file);
          const chunks = [];
          for await (const c of req) chunks.push(c);
          const request = new Request(`http://${req.headers.host || 'localhost'}${req.url}`, {
            method: req.method,
            headers: req.headers,
            body: ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(chunks),
          });
          const response = await mod.default.fetch(request);
          res.statusCode = response.status;
          response.headers.forEach((v, k) => res.setHeader(k, v));
          if (response.body) for await (const chunk of response.body) res.write(chunk);
          res.end();
        } catch (err) {
          console.error(err);
          res.statusCode = 500;
          res.end('Local API error');
        }
      });
    },
  };
}

export default defineConfig(({ mode }) => {
  // Make server-only variables (ANTHROPIC_API_KEY etc.) visible to the local /api handlers.
  const fileEnv = loadEnv(mode, ROOT, '');
  for (const [k, v] of Object.entries(fileEnv)) if (process.env[k] === undefined) process.env[k] = v;
  return {
  root: WEB,
  envDir: ROOT,
  base: process.env.PREVIEW === '1' ? './' : '/',
  publicDir: path.join(WEB, 'public'),
  plugins: [localApi()],
  build: {
    outDir: path.join(ROOT, 'dist'),
    emptyOutDir: true,
    target: 'es2022',
    chunkSizeWarningLimit: 900,
    rollupOptions: { input: htmlInputs(WEB) },
  },
  server: { port: 5173 },
  preview: { port: 4173 },
  };
});
