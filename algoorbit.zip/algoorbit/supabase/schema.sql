-- AlgoOrbit database schema for Supabase.
-- Run once in the Supabase dashboard: SQL Editor → New query → paste → Run.
-- Safe to re-run: every statement is idempotent.
--
-- Security model
--   * Row Level Security is ON for every table. Each signed-in user can only see and change their own rows.
--   * The browser uses the publishable (anon) key, which maps to the `anon` / `authenticated` roles.
--   * Only the server (secret key → `service_role`) can touch tutor usage counters.
--   * XP, levels and streaks are derived from progress rows, so there is no score column anyone could inflate.

-- ---------------------------------------------------------------------------
-- profiles: one row per user, created automatically on sign-up
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id           uuid primary key references auth.users (id) on delete cascade,
  display_name text check (display_name is null or char_length(display_name) between 1 and 40),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "profiles: read own" on public.profiles;
create policy "profiles: read own" on public.profiles
  for select to authenticated
  using ((select auth.uid()) = id);

drop policy if exists "profiles: update own" on public.profiles;
create policy "profiles: update own" on public.profiles
  for update to authenticated
  using ((select auth.uid()) = id)
  with check ((select auth.uid()) = id);

revoke all on public.profiles from anon, authenticated;
grant select on public.profiles to authenticated;
grant update (display_name) on public.profiles to authenticated;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    nullif(left(trim(coalesce(
      new.raw_user_meta_data ->> 'display_name',
      new.raw_user_meta_data ->> 'full_name',
      split_part(new.email, '@', 1),
      ''
    )), 40), '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists profiles_touch on public.profiles;
create trigger profiles_touch
  before update on public.profiles
  for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------------------
-- progress: one row per concept/problem a user has completed
-- item_id format: "<topic>:c<n>" for concepts, "<topic>:p:<leetcode-slug>" for problems
-- ---------------------------------------------------------------------------
create table if not exists public.progress (
  user_id      uuid not null default auth.uid() references auth.users (id) on delete cascade,
  item_id      text not null
               check (char_length(item_id) <= 120 and item_id ~ '^[a-z0-9-]+:(c[0-9]{1,2}|p:[a-z0-9-]+)$'),
  completed_at timestamptz not null default now()
               check (completed_at > '2024-01-01' and completed_at < now() + interval '1 day'),
  primary key (user_id, item_id)
);

alter table public.progress enable row level security;

drop policy if exists "progress: read own" on public.progress;
create policy "progress: read own" on public.progress
  for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "progress: insert own" on public.progress;
create policy "progress: insert own" on public.progress
  for insert to authenticated
  with check ((select auth.uid()) = user_id);

drop policy if exists "progress: delete own" on public.progress;
create policy "progress: delete own" on public.progress
  for delete to authenticated
  using ((select auth.uid()) = user_id);

revoke all on public.progress from anon, authenticated;
grant select, insert, delete on public.progress to authenticated;

-- Cap rows per user so nobody can use the table as free storage (the roadmap has < 400 items).
create or replace function public.enforce_progress_cap()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select count(*) from public.progress where user_id = new.user_id) >= 600 then
    raise exception 'progress limit reached' using errcode = 'check_violation';
  end if;
  return new;
end;
$$;

drop trigger if exists progress_cap on public.progress;
create trigger progress_cap
  before insert on public.progress
  for each row execute function public.enforce_progress_cap();

-- ---------------------------------------------------------------------------
-- tutor_usage: daily message counter per user, written only by the server
-- ---------------------------------------------------------------------------
create table if not exists public.tutor_usage (
  user_id uuid not null references auth.users (id) on delete cascade,
  day     date not null default ((now() at time zone 'utc')::date),
  count   integer not null default 0 check (count >= 0),
  primary key (user_id, day)
);

alter table public.tutor_usage enable row level security;

drop policy if exists "tutor_usage: read own" on public.tutor_usage;
create policy "tutor_usage: read own" on public.tutor_usage
  for select to authenticated
  using ((select auth.uid()) = user_id);

revoke all on public.tutor_usage from anon, authenticated;
grant select on public.tutor_usage to authenticated;

-- Atomically consume one tutor message. Returns messages left today, or -1 if the limit is reached.
create or replace function public.consume_tutor_quota(p_user_id uuid, p_limit integer)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  used integer;
begin
  if p_limit < 1 then
    return -1;
  end if;
  insert into public.tutor_usage as t (user_id, day, count)
  values (p_user_id, (now() at time zone 'utc')::date, 1)
  on conflict (user_id, day) do update
    set count = t.count + 1
    where t.count < p_limit
  returning t.count into used;

  if used is null then
    return -1;
  end if;
  return p_limit - used;
end;
$$;

revoke all on function public.consume_tutor_quota(uuid, integer) from public, anon, authenticated;
grant execute on function public.consume_tutor_quota(uuid, integer) to service_role;

-- Give a used message back (called when the AI provider fails before replying).
create or replace function public.refund_tutor_quota(p_user_id uuid)
returns void
language sql
security definer
set search_path = ''
as $$
  update public.tutor_usage
     set count = greatest(count - 1, 0)
   where user_id = p_user_id and day = (now() at time zone 'utc')::date;
$$;

revoke all on function public.refund_tutor_quota(uuid) from public, anon, authenticated;
grant execute on function public.refund_tutor_quota(uuid) to service_role;

-- Old usage rows are not needed after a while; keep the table small.
create index if not exists tutor_usage_day_idx on public.tutor_usage (day);
