// Generates every HTML page, the slim roadmap data the browser needs, and SEO files.
// Run automatically by `npm run dev` and `npm run build`.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadDotEnv, siteConfig, writeFile } from './lib/util.mjs';
import { layout } from './lib/layout.mjs';
import * as P from './lib/pages.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const WEB = path.join(ROOT, 'web');
loadDotEnv(ROOT);
const cfg = siteConfig();
const content = await import('../web/src/content/index.js');
const { TOPICS, ORBITS, XP, LEVELS } = content;
const DIFF = { E: 'Easy', M: 'Medium', H: 'Hard' };

// 1. Clean previously generated pages (everything in web/ except src/ and public/).
for (const entry of fs.readdirSync(WEB)) {
  if (entry === 'src' || entry === 'public') continue;
  fs.rmSync(path.join(WEB, entry), { recursive: true, force: true });
}

// 2. Pages
const pages = [
  P.homePage(cfg, content),
  P.learnIndexPage(cfg, content),
  ...TOPICS.map((t, i) => P.topicPage(cfg, content, t, i)),
  P.practicePage(cfg, content),
  P.roadmapPage(cfg, content),
  P.tutorPage(cfg, content),
  P.loginPage(cfg, content),
  P.resetPage(cfg, content),
  P.accountPage(cfg, content),
  P.aboutPage(cfg, content),
  P.contactPage(cfg, content),
  P.privacyPage(cfg, content),
  P.termsPage(cfg, content),
  P.notFoundPage(cfg, content),
];

for (const page of pages) {
  const out = page.path === '/404/'
    ? path.join(WEB, '404.html')
    : path.join(WEB, page.path, 'index.html');
  writeFile(out, layout(cfg, page));
}

// 3. Slim data for the browser (roadmap, progress maths, tutor topic list).
const slim = {
  orbits: ORBITS,
  xp: XP,
  levels: LEVELS,
  topics: TOPICS.map((t) => ({
    id: t.id, orbit: t.orbit, title: t.title, short: t.short, summary: t.summary,
    prereqs: t.prereqs, hours: t.hours,
    concepts: t.concepts.length,
    problems: t.problems.map(([slug, , d]) => [slug, d]),
  })),
};
writeFile(path.join(WEB, 'src/generated/roadmap.json'), JSON.stringify(slim));

// 3b. Search index, loaded only when someone opens search. Rows: [kind, label, detail, path].
const search = [];
for (const [i, t] of TOPICS.entries()) {
  const orbit = ORBITS.find((o) => o.id === t.orbit);
  const to = `/learn/${t.id}/`;
  search.push(['Level', t.title, `Level ${i + 1}, ${orbit.title}`, to]);
  for (const [name] of t.patterns) search.push(['Pattern', name, t.short, `${to}#patterns`]);
  for (const [name] of t.concepts) search.push(['Concept', name, t.short, `${to}#concepts`]);
  for (const [, name, d] of t.problems) search.push(['Problem', name, `${t.short}, ${DIFF[d]}`, `${to}#practice`]);
}
writeFile(path.join(WEB, 'src/generated/search.json'), JSON.stringify(search));

// 4. SEO + platform files in public/
const pub = path.join(WEB, 'public');
const indexable = pages.filter((p) => !p.noindex);
writeFile(path.join(pub, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${indexable.map((p) => `  <url><loc>${cfg.url}${p.path}</loc><lastmod>${cfg.today}</lastmod><changefreq>${p.path.startsWith('/learn/') ? 'monthly' : 'weekly'}</changefreq><priority>${p.path === '/' ? '1.0' : p.path.startsWith('/learn/') ? '0.8' : '0.5'}</priority></url>`).join('\n')}
</urlset>
`);
writeFile(path.join(pub, 'robots.txt'), `User-agent: *
Allow: /
Disallow: /account/
Disallow: /reset/
Disallow: /api/

Sitemap: ${cfg.url}/sitemap.xml
`);
const adsTxt = path.join(pub, 'ads.txt');
if (cfg.adsenseClient) {
  writeFile(adsTxt, `google.com, ${cfg.adsenseClient.replace(/^ca-/, '')}, DIRECT, f08c47fec0942fa0\n`);
} else if (fs.existsSync(adsTxt)) {
  fs.rmSync(adsTxt);
}
writeFile(path.join(pub, 'site.webmanifest'), JSON.stringify({
  name: cfg.name, short_name: cfg.name, start_url: '/roadmap/', display: 'standalone',
  background_color: '#f6f7f9', theme_color: '#f6f7f9',
  icons: [{ src: '/icon-192.png', sizes: '192x192', type: 'image/png' }, { src: '/icon-512.png', sizes: '512x512', type: 'image/png' }],
}, null, 2));

// 5. Report
const warn = [];
if (!process.env.SITE_URL) warn.push('SITE_URL not set — canonical URLs and sitemap point to localhost.');
if (!cfg.contactEmail) warn.push('CONTACT_EMAIL not set — the contact page has no address (AdSense reviewers look for one).');
if (!cfg.adsenseClient) warn.push('ADSENSE_CLIENT not set — no ad code or ads.txt generated.');
console.log(`Generated ${pages.length} pages for ${cfg.url}${cfg.preview ? ' (preview mode)' : ''}.`);
for (const w of warn) console.log(`  note: ${w}`);
