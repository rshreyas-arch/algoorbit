// Netlify Function: POST /api/delete-account — permanently deletes the signed-in user.
import { createDeleteAccountHandler } from '../../server/delete-account.js';

const handle = createDeleteAccountHandler();
export default (request) => handle(request);
export const config = { path: '/api/delete-account' };
