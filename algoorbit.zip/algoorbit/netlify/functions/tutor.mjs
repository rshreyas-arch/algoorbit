// Netlify Function: POST /api/tutor — streams an AI tutor reply.
import { createTutorHandler } from '../../server/tutor.js';

const handle = createTutorHandler();
export default (request) => handle(request);
export const config = { path: '/api/tutor' };
