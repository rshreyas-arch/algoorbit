import { Marked } from 'marked';
import DOMPurify from 'dompurify';
import hljs from 'highlight.js/lib/core';
import python from 'highlight.js/lib/languages/python';
import cpp from 'highlight.js/lib/languages/cpp';
import java from 'highlight.js/lib/languages/java';
import javascript from 'highlight.js/lib/languages/javascript';

hljs.registerLanguage('python', python);
hljs.registerLanguage('cpp', cpp);
hljs.registerLanguage('java', java);
hljs.registerLanguage('javascript', javascript);
hljs.registerAliases(['py'], { languageName: 'python' });
hljs.registerAliases(['c++', 'c', 'cc'], { languageName: 'cpp' });
hljs.registerAliases(['js'], { languageName: 'javascript' });

const marked = new Marked({ gfm: true });
marked.use({
  renderer: {
    code({ text, lang }) {
      const language = (lang || '').trim().split(/\s+/)[0].toLowerCase();
      const known = language && hljs.getLanguage(language);
      const body = known ? hljs.highlight(text, { language }).value : hljs.highlightAuto(text).value;
      return `<pre><code class="hljs">${body}</code></pre>`;
    },
  },
});

/** Markdown → sanitised HTML. Model output is untrusted, so everything goes through DOMPurify. */
export function renderMarkdown(src) {
  const html = marked.parse(src);
  return DOMPurify.sanitize(html, { USE_PROFILES: { html: true }, FORBID_TAGS: ['style', 'form', 'input', 'img'] });
}
