// The AlgoOrbit map: six low-poly floating islands climbing a spiral, one per world.
// Each topic is a tile (a level) on its island; rope bridges link the worlds in order.
// Cleared levels turn gold and get a spinning star; Orbi the mascot stands on your next level.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/addons/renderers/CSS2DRenderer.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { ORBITS, TOPICS } from './data.js';
import { TOPIC_ICONS } from '../content/icons.js';

const SPIRAL_R = 11.2;
const STEP = THREE.MathUtils.degToRad(52);
const START = Math.PI / 4; // world 1 sits nearest the camera
const RISE = 2.1;
const TILE = 1.08;
const TILE_H = 0.36;
const UP = new THREE.Vector3(0, 1, 0);
const VIEW_DIR = new THREE.Vector3(1, 0.95, 1).normalize();

const C = {
  tile: '#f7f5f1', tileDone: '#e9b949', earth: '#c9a68e', rockTop: '#d6c3b4', rockTip: '#8c7a74',
  stone: '#eee6dc', plank: '#b78c69', rope: '#7d6352', ink: '#101218', blue: '#3e5bd8', sun: '#f6c54a',
  trunk: '#87695a', pond: '#a3d2d6',
};

const ease = (t) => 1 - Math.pow(1 - Math.min(Math.max(t, 0), 1), 3);
const easeBack = (t) => { t = Math.min(Math.max(t, 0), 1); const c = 1.4; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };

function mulberry32(a) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function webglAvailable() {
  try {
    const c = document.createElement('canvas');
    return Boolean(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl')));
  } catch { return false; }
}

/* ------------------------------------------------------------------ */
/* Layout (pure geometry, no scene objects)                            */
/* ------------------------------------------------------------------ */
function bezier(a, b, c, t) {
  const u = 1 - t;
  return new THREE.Vector3(
    u * u * a.x + 2 * u * t * b.x + t * t * c.x, 0,
    u * u * a.z + 2 * u * t * b.z + t * t * c.z,
  );
}
const flat = (v) => new THREE.Vector3(v.x, 0, v.z).normalize();

function computeLayout() {
  let level = 0;
  const islands = ORBITS.map((o, i) => {
    const topics = TOPICS.filter((t) => t.orbit === o.id);
    const a = START + i * STEP;
    return {
      orbit: o, i, topics, a,
      r: 1.95 + topics.length * 0.37,
      center: new THREE.Vector3(Math.cos(a) * SPIRAL_R, i * RISE, Math.sin(a) * SPIRAL_R),
      levels: topics.map(() => ++level),
    };
  });
  islands.forEach((isl, i) => {
    const c = isl.center;
    const outward = flat(c);
    const prev = islands[i - 1];
    const next = islands[i + 1];
    isl.dirIn = prev ? flat(prev.center.clone().sub(c)) : null;
    isl.dirOut = next ? flat(next.center.clone().sub(c)) : null;
    // First and last worlds: run the path straight across the island, bending outward.
    if (!isl.dirIn) isl.dirIn = isl.dirOut.clone().negate().addScaledVector(outward, 0.5).normalize();
    if (!isl.dirOut) isl.dirOut = isl.dirIn.clone().negate().addScaledVector(outward, 0.5).normalize();
    const E = c.clone().addScaledVector(isl.dirIn, isl.r - 1.05);
    const X = c.clone().addScaledVector(isl.dirOut, isl.r - 1.05);
    // Bend the path toward the camera so back-facing islands still show their levels.
    const bend = outward.clone().addScaledVector(flat(VIEW_DIR), 1.2).normalize();
    const ctrl = c.clone().addScaledVector(bend, isl.r * 0.5);
    const n = isl.topics.length;
    isl.tilePos = isl.topics.map((_, k) => bezier(E, ctrl, X, n === 1 ? 0.5 : 0.08 + (0.84 * k) / (n - 1)).setY(c.y));
    isl.exit = c.clone().addScaledVector(isl.dirOut, isl.r - 0.75);
  });
  return islands;
}

function distToSegment(p, a, b) {
  const ab = b.clone().sub(a).setY(0);
  const t = THREE.MathUtils.clamp(p.clone().sub(a).setY(0).dot(ab) / Math.max(ab.lengthSq(), 1e-6), 0, 1);
  return p.clone().setY(0).distanceTo(a.clone().setY(0).addScaledVector(ab, t));
}

/* ------------------------------------------------------------------ */
/* Shared geometry & materials                                          */
/* ------------------------------------------------------------------ */
function makeKit() {
  const mats = new Map();
  const lambert = (color, extra = {}) => {
    const key = color + JSON.stringify(extra);
    if (!mats.has(key)) mats.set(key, new THREE.MeshLambertMaterial({ color, flatShading: true, ...extra }));
    return mats.get(key);
  };
  const geo = {
    tile: new RoundedBoxGeometry(TILE, TILE_H, TILE, 3, 0.14),
    stone: new THREE.CylinderGeometry(0.2, 0.22, 0.08, 7),
    plank: new THREE.BoxGeometry(0.95, 0.08, 0.3),
    trunk: new THREE.CylinderGeometry(0.06, 0.09, 0.42, 5),
    canopy: new THREE.IcosahedronGeometry(0.4, 0),
    pine: new THREE.ConeGeometry(0.42, 0.75, 6),
    pineTop: new THREE.ConeGeometry(0.3, 0.6, 6),
    bush: new THREE.IcosahedronGeometry(0.24, 0),
    rock: new THREE.DodecahedronGeometry(0.2, 0),
    flower: new THREE.IcosahedronGeometry(0.07, 0),
    crystal: new THREE.OctahedronGeometry(0.22, 0),
    stalk: new THREE.CapsuleGeometry(0.07, 0.26, 2, 6),
    cloud: new THREE.IcosahedronGeometry(1, 1),
    star: starGeometry(),
  };
  return { lambert, geo, dispose() { mats.forEach((m) => m.dispose()); Object.values(geo).forEach((g) => g.dispose()); } };
}

function starGeometry() {
  const s = new THREE.Shape();
  for (let k = 0; k < 10; k++) {
    const r = k % 2 ? 0.15 : 0.34;
    const a = (k / 10) * Math.PI * 2 + Math.PI / 2;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (k) s.lineTo(x, y); else s.moveTo(x, y);
  }
  s.closePath();
  const g = new THREE.ExtrudeGeometry(s, { depth: 0.1, bevelEnabled: true, bevelSize: 0.03, bevelThickness: 0.03, bevelSegments: 1 });
  g.center();
  return g;
}

/** Topic icon drawn onto a canvas, used as a decal on top of its tile. */
function iconTexture(id, color) {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="${color}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">${(TOPIC_ICONS[id] || '').replaceAll('currentColor', color)}</svg>`;
  const img = new Image();
  img.onload = () => {
    const g = canvas.getContext('2d');
    g.clearRect(0, 0, size, size);
    g.drawImage(img, 14, 14, size - 28, size - 28);
    tex.needsUpdate = true;
  };
  img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  return tex;
}

/* ------------------------------------------------------------------ */
/* Scene                                                                */
/* ------------------------------------------------------------------ */
/**
 * @param {HTMLElement} container
 * @param {{ mode: 'hero'|'map', getProgress: (id:string)=>{status:string,pct:number}, getNext?: ()=>string|null, onSelect?: (id:string|null)=>void }} opts
 */
export function createWorldScene(container, opts) {
  if (!webglAvailable()) return null;
  const { mode, getProgress, getNext = () => null, onSelect = () => {} } = opts;
  const isMap = mode === 'map';
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const small = Math.min(innerWidth, innerHeight) < 600;

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
  } catch { return null; }
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setClearColor(0x000000, 0);
  container.appendChild(renderer.domElement);

  let labels = null;
  if (isMap) {
    labels = new CSS2DRenderer();
    Object.assign(labels.domElement.style, { position: 'absolute', inset: '0', pointerEvents: 'none' });
    container.appendChild(labels.domElement);
  }

  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(-10, 10, 10, -10, 0.1, 500);
  const world = new THREE.Group();
  scene.add(world);

  /* ---------- Light ---------- */
  scene.add(new THREE.HemisphereLight('#e9e7f4', '#efd5c6', 1.85));
  const sun = new THREE.DirectionalLight('#ffe8d4', 2.2);
  sun.position.set(-12, 30, 18);
  sun.target.position.set(0, 4, 0);
  sun.castShadow = true;
  sun.shadow.mapSize.set(small ? 1024 : 2048, small ? 1024 : 2048);
  Object.assign(sun.shadow.camera, { left: -26, right: 26, top: 26, bottom: -26, near: 1, far: 90 });
  sun.shadow.bias = -0.0006;
  sun.shadow.normalBias = 0.03;
  scene.add(sun, sun.target);

  /* ---------- Build the world ---------- */
  const kit = makeKit();
  const { lambert, geo } = kit;
  const islands = computeLayout();
  const tiles = new Map(); // topicId -> record
  const islandGroups = [];
  const planks = [];
  const textures = [];
  const shadowy = (m) => { m.castShadow = true; m.receiveShadow = true; return m; };

  islands.forEach((isl) => {
    const rand = mulberry32(1337 + isl.i * 101);
    const g = new THREE.Group();
    g.position.copy(isl.center);
    world.add(g);
    islandGroups.push(g);

    // Body: grass cap, earth band, craggy rock underside.
    const body = new THREE.Group();
    body.rotation.y = rand() * Math.PI;
    g.add(body);
    const seg = 9;
    const r = isl.r;
    const grass = shadowy(new THREE.Mesh(new THREE.CylinderGeometry(r, r * 0.985, 0.34, seg), lambert(isl.orbit.color)));
    grass.position.y = -0.17;
    const earth = shadowy(new THREE.Mesh(new THREE.CylinderGeometry(r * 0.985, r * 0.9, 0.5, seg), lambert(C.earth)));
    earth.position.y = -0.59;
    const h = r * 1.3;
    const cone = new THREE.ConeGeometry(r * 0.9, h, seg, 4);
    cone.rotateX(Math.PI);
    cone.translate(0, -0.84 - h / 2, 0);
    const pos = cone.attributes.position;
    const cache = new Map();
    const colors = new Float32Array(pos.count * 3);
    const top = new THREE.Color(C.rockTop);
    const tip = new THREE.Color(C.rockTip);
    const tmp = new THREE.Color();
    for (let k = 0; k < pos.count; k++) {
      const x = pos.getX(k); const y = pos.getY(k); const z = pos.getZ(k);
      const depth = (-0.84 - y) / h;
      if (depth > 0.02) {
        const key = `${x.toFixed(3)},${y.toFixed(3)},${z.toFixed(3)}`;
        if (!cache.has(key)) cache.set(key, [1 + (rand() - 0.5) * 0.34, (rand() - 0.5) * 0.5]);
        const [s, dy] = cache.get(key);
        pos.setXYZ(k, x * s, y + dy * (depth < 0.98 ? 1 : 0.3), z * s);
      }
      tmp.copy(top).lerp(tip, THREE.MathUtils.clamp(depth, 0, 1));
      colors.set([tmp.r, tmp.g, tmp.b], k * 3);
    }
    cone.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    cone.computeVertexNormals();
    const rock = new THREE.Mesh(cone, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }));
    rock.castShadow = true;
    body.add(grass, earth, rock);

    // Tiles (levels)
    isl.topics.forEach((t, k) => {
      const p = isl.tilePos[k].clone().sub(isl.center);
      const mat = new THREE.MeshLambertMaterial({ color: C.tile });
      const mesh = shadowy(new THREE.Mesh(geo.tile, mat));
      mesh.position.set(p.x, TILE_H / 2 + 0.02, p.z);
      mesh.userData.topicId = t.id;
      g.add(mesh);

      const tex = iconTexture(t.id, isl.orbit.ui);
      textures.push(tex);
      const decal = new THREE.Mesh(new THREE.PlaneGeometry(TILE * 0.8, TILE * 0.8), new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false }));
      decal.rotation.x = -Math.PI / 2;
      decal.rotation.z = Math.atan2(VIEW_DIR.x, VIEW_DIR.z); // icon reads upright from the default camera
      decal.position.y = TILE_H / 2 + 0.005;
      mesh.add(decal);

      const star = new THREE.Mesh(geo.star, new THREE.MeshStandardMaterial({ color: C.sun, emissive: '#d98f1a', emissiveIntensity: 0.3, metalness: 0.35, roughness: 0.35 }));
      star.position.y = 0.95;
      star.castShadow = true;
      star.visible = false;
      mesh.add(star);

      let label = null;
      if (labels) {
        const el = document.createElement('div');
        el.className = 'tile-label';
        el.style.setProperty('--c', isl.orbit.ui);
        el.innerHTML = `<span class="n">${isl.levels[k]}</span>${t.short}`;
        label = new CSS2DObject(el);
        label.position.set(0, k % 2 ? 2.05 : 1.5, 0); // stagger so neighbouring labels don't collide
        mesh.add(label);
      }
      tiles.set(t.id, { topic: t, island: isl, mesh, mat, star, label, base: mesh.position.y, lift: 0, liftTarget: 0, status: 'todo', local: mesh.position.clone() });

      // Stepping stones to the next tile on this island
      if (k < isl.topics.length - 1) {
        const q = isl.tilePos[k + 1].clone().sub(isl.center);
        const d = p.distanceTo(q);
        const count = d > 1.9 ? 2 : 1;
        for (let s = 1; s <= count; s++) {
          const m = p.clone().lerp(q, s / (count + 1));
          const st = new THREE.Mesh(geo.stone, lambert(C.stone));
          st.position.set(m.x + (rand() - 0.5) * 0.12, 0.04, m.z + (rand() - 0.5) * 0.12);
          st.receiveShadow = true;
          g.add(st);
        }
      }
    });

    // World name label (shown in the overview)
    if (labels) {
      const el = document.createElement('div');
      el.className = 'world-label';
      el.style.setProperty('--c', isl.orbit.ui);
      el.style.setProperty('--t', isl.orbit.tint);
      el.innerHTML = `<b>World ${isl.orbit.n}</b>${isl.orbit.title}`;
      const wl = new CSS2DObject(el);
      const front = flat(VIEW_DIR).multiplyScalar(isl.r * 0.95);
      wl.position.set(front.x, -1.1, front.z); // on the island's front face, clear of the levels
      g.add(wl);
      isl.worldLabel = wl;
    }

    // Decorations, kept clear of the level path and bridges
    const local = (v) => v.clone().sub(isl.center);
    const pathPts = isl.tilePos.map(local);
    const inEdge = local(isl.center.clone().addScaledVector(isl.dirIn, isl.r));
    const outEdge = local(isl.center.clone().addScaledVector(isl.dirOut, isl.r));
    const clear = (v) => {
      if (pathPts.some((pp) => pp.distanceTo(v) < 1.05)) return false;
      for (let k = 0; k < pathPts.length - 1; k++) if (distToSegment(v, pathPts[k], pathPts[k + 1]) < 0.75) return false;
      if (distToSegment(v, pathPts[pathPts.length - 1], outEdge) < 0.9) return false;
      if (distToSegment(v, inEdge, pathPts[0]) < 0.9) return false;
      return true;
    };
    const spot = (pad = 0.55) => {
      for (let tries = 0; tries < 40; tries++) {
        const a = rand() * Math.PI * 2;
        const d = Math.sqrt(rand()) * (isl.r - pad);
        const v = new THREE.Vector3(Math.cos(a) * d, 0, Math.sin(a) * d);
        if (clear(v)) return v;
      }
      return null;
    };
    const place = (obj, pad) => { const v = spot(pad); if (!v) return; obj.position.add(v); obj.rotation.y = rand() * Math.PI * 2; g.add(obj); };
    const tree = (color, s = 1) => {
      const o = new THREE.Group();
      const tr = shadowy(new THREE.Mesh(geo.trunk, lambert(C.trunk))); tr.position.y = 0.21;
      const cn = shadowy(new THREE.Mesh(geo.canopy, lambert(color))); cn.position.y = 0.62;
      o.add(tr, cn); o.scale.setScalar(s); return o;
    };
    const pine = (color, s = 1) => {
      const o = new THREE.Group();
      const tr = shadowy(new THREE.Mesh(geo.trunk, lambert(C.trunk))); tr.position.y = 0.2;
      const a = shadowy(new THREE.Mesh(geo.pine, lambert(color))); a.position.y = 0.7;
      const b = shadowy(new THREE.Mesh(geo.pineTop, lambert(color))); b.position.y = 1.08;
      o.add(tr, a, b); o.scale.setScalar(s); return o;
    };
    const one = (geometry, color, y, s = 1, extra) => { const m = shadowy(new THREE.Mesh(geometry, lambert(color, extra))); m.position.y = y * s; m.scale.setScalar(s); return m; };

    const biome = isl.orbit.id;
    if (biome === 'foundations') {
      for (let k = 0; k < 4; k++) place(tree('#7fa35a', 0.9 + rand() * 0.4));
      for (let k = 0; k < 6; k++) place(one(geo.bush, '#98b86f', 0.12, 0.8 + rand() * 0.6));
      for (let k = 0; k < 14; k++) place(one(geo.flower, ['#fbf7f0', '#e8b3b9', '#edcf7e'][k % 3], 0.07));
    } else if (biome === 'patterns') {
      const pond = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.75, 0.04, 12), lambert(C.pond));
      pond.position.y = 0.01; pond.receiveShadow = true; place(pond, 1.1);
      for (let k = 0; k < 3; k++) place(tree('#5f9e8f', 0.85 + rand() * 0.4));
      for (let k = 0; k < 3; k++) place(one(geo.rock, '#ddd6cc', 0.1, 0.8 + rand() * 0.8));
      for (let k = 0; k < 4; k++) place(one(geo.bush, '#7cb6a5', 0.12, 0.9));
    } else if (biome === 'linear') {
      for (let k = 0; k < 12; k++) place(one(geo.stalk, rand() > 0.4 ? '#9d8fcf' : '#b9aee0', 0.2, 0.9 + rand() * 0.4));
      for (let k = 0; k < 2; k++) place(tree('#8e80c4', 0.9));
      for (let k = 0; k < 3; k++) place(one(geo.rock, '#f1eef6', 0.1, 1));
    } else if (biome === 'trees') {
      for (let k = 0; k < 10; k++) place(pine(rand() > 0.5 ? '#507f5d' : '#64936c', 0.8 + rand() * 0.5));
    } else if (biome === 'graphs') {
      for (let k = 0; k < 6; k++) {
        const o = new THREE.Group();
        const n = 2 + Math.floor(rand() * 3);
        for (let c = 0; c < n; c++) {
          const m = new THREE.Mesh(geo.crystal, new THREE.MeshStandardMaterial({ color: c % 2 ? '#d4dcf2' : '#a1b1de', roughness: 0.3, metalness: 0.08, flatShading: true, emissive: '#7d8fcf', emissiveIntensity: 0.1 }));
          m.castShadow = true;
          m.scale.set(0.6, 1.6 + rand(), 0.6);
          m.position.set((rand() - 0.5) * 0.3, 0.3, (rand() - 0.5) * 0.3);
          m.rotation.set((rand() - 0.5) * 0.6, rand() * 3, (rand() - 0.5) * 0.6);
          o.add(m);
        }
        place(o);
      }
      for (let k = 0; k < 3; k++) place(one(geo.rock, '#c3cbe2', 0.1, 1));
    } else if (biome === 'mastery') {
      for (let k = 0; k < 6; k++) place(one(geo.rock, '#c98668', 0.1, 0.9 + rand() * 0.9));
      for (let k = 0; k < 4; k++) place(one(geo.bush, '#e2a083', 0.12, 0.9));
      for (let k = 0; k < 3; k++) place(tree('#d68660', 0.8 + rand() * 0.3));
      // Summit flag
      const flag = new THREE.Group();
      const pole = shadowy(new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.4, 6), lambert('#3c3f4a')));
      pole.position.y = 1.2;
      const cloth = new THREE.BufferGeometry();
      cloth.setAttribute('position', new THREE.Float32BufferAttribute([0, 2.35, 0, 0, 1.65, 0, 0.95, 2.0, 0], 3));
      cloth.computeVertexNormals();
      const banner = shadowy(new THREE.Mesh(cloth, new THREE.MeshLambertMaterial({ color: C.sun, side: THREE.DoubleSide })));
      flag.add(pole, banner);
      flag.position.copy(local(isl.exit));
      g.add(flag);
      isl.flag = banner;
      isl.summit = flag.position.clone();
    }
  });

  /* ---------- Rope bridges between worlds ---------- */
  const bridges = new THREE.Group();
  world.add(bridges);
  for (let i = 0; i < islands.length - 1; i++) {
    const a = islands[i].tilePos[islands[i].tilePos.length - 1].clone();
    const b = islands[i + 1].tilePos[0].clone();
    const dir = b.clone().sub(a).setY(0).normalize();
    a.addScaledVector(dir, 0.7).y += 0.04;
    b.addScaledVector(dir, -0.7).y += 0.04;
    const len = a.distanceTo(b);
    const n = Math.max(4, Math.floor(len / 0.4));
    const yaw = Math.atan2(dir.x, dir.z);
    const side = new THREE.Vector3(dir.z, 0, -dir.x);
    const ropeL = [];
    const ropeR = [];
    for (let k = 0; k <= n; k++) {
      const t = k / n;
      const p = a.clone().lerp(b, t);
      p.y -= Math.sin(Math.PI * t) * 0.45;
      const m = shadowy(new THREE.Mesh(geo.plank, lambert(C.plank)));
      m.position.copy(p);
      m.rotation.y = yaw + Math.PI / 2;
      m.rotation.x = 0;
      m.userData.order = i * 100 + k;
      bridges.add(m);
      planks.push(m);
      ropeL.push(p.clone().addScaledVector(side, 0.5).setY(p.y + 0.42));
      ropeR.push(p.clone().addScaledVector(side, -0.5).setY(p.y + 0.42));
    }
    for (const pts of [ropeL, ropeR]) {
      bridges.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: C.rope })));
    }
  }

  /* ---------- Clouds ---------- */
  const clouds = [];
  {
    const rand = mulberry32(99);
    const cloudMat = new THREE.MeshLambertMaterial({ color: '#ffffff', emissive: '#f2e4ec', emissiveIntensity: 0.32, flatShading: true });
    for (let k = 0; k < 8; k++) {
      const o = new THREE.Group();
      const puffs = 3 + Math.floor(rand() * 3);
      for (let p = 0; p < puffs; p++) {
        const m = new THREE.Mesh(geo.cloud, cloudMat);
        const s = 0.45 + rand() * 0.5;
        m.scale.set(s * 1.2, s * 0.8, s);
        m.position.set((p - puffs / 2) * 0.9, rand() * 0.3, (rand() - 0.5) * 0.6);
        o.add(m);
      }
      const ang = rand() * Math.PI * 2;
      // Low clouds drift under the islands; high ones stay outside the spiral so they never cover a level.
      const high = k % 3 === 0;
      const rad = high ? 18 + rand() * 6 : 4 + rand() * 16;
      o.userData = { ang, rad, y: high ? 4 + rand() * 9 : -7 + rand() * 4, speed: 0.008 + rand() * 0.012 };
      o.position.set(Math.cos(ang) * rad, o.userData.y, Math.sin(ang) * rad);
      world.add(o);
      clouds.push(o);
    }
  }

  /* ---------- Orbi, the mascot ---------- */
  const mascot = new THREE.Group();
  {
    const bodyMat = new THREE.MeshStandardMaterial({ color: C.sun, roughness: 0.45 });
    const inkMat = new THREE.MeshStandardMaterial({ color: C.ink, roughness: 0.4 });
    const blueMat = new THREE.MeshStandardMaterial({ color: C.blue, roughness: 0.4 });
    const bodyM = new THREE.Mesh(new THREE.SphereGeometry(0.42, 28, 18), bodyMat);
    bodyM.castShadow = true;
    const eyeGeo = new THREE.SphereGeometry(0.065, 12, 8);
    const eyeL = new THREE.Mesh(eyeGeo, inkMat); eyeL.scale.set(1, 1.45, 0.6); eyeL.position.set(-0.14, 0.06, 0.38);
    const eyeR = eyeL.clone(); eyeR.position.x = 0.14;
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.28, 6), inkMat); stem.position.y = 0.52;
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.025, 6, 20), blueMat); ring.position.y = 0.68; ring.rotation.x = Math.PI / 2.3;
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), blueMat); ball.position.y = 0.68;
    const inner = new THREE.Group();
    inner.add(bodyM, eyeL, eyeR, stem, ring, ball);
    inner.position.y = 0.42;
    mascot.scale.setScalar(1.25);
    mascot.add(inner);
    mascot.userData.inner = inner;
    world.add(mascot);
  }
  const pulse = new THREE.Mesh(new THREE.RingGeometry(0.85, 1.0, 40), new THREE.MeshBasicMaterial({ color: C.blue, transparent: true, opacity: 0.6, depthWrite: false, side: THREE.DoubleSide }));
  pulse.rotation.x = -Math.PI / 2;
  world.add(pulse);

  /* ---------- Framing ---------- */
  const target = new THREE.Vector3(0, RISE * 2.5, 0);
  let baseH = 10;
  const framingPoints = [];
  islands.forEach((isl) => {
    for (let k = 0; k < 10; k++) {
      const a = (k / 10) * Math.PI * 2;
      framingPoints.push(isl.center.clone().add(new THREE.Vector3(Math.cos(a) * isl.r, 1.2, Math.sin(a) * isl.r)));
    }
    framingPoints.push(isl.center.clone().add(new THREE.Vector3(0, -0.84 - isl.r * 1.3, 0)));
  });

  function fit() {
    const w = container.clientWidth || 1;
    const h = container.clientHeight || 1;
    const aspect = w / h;
    camera.position.copy(new THREE.Vector3(0, RISE * 2.5, 0)).addScaledVector(VIEW_DIR, 120);
    camera.lookAt(0, RISE * 2.5, 0);
    camera.updateMatrixWorld();
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion);
    const up = new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion);
    const origin = new THREE.Vector3(0, RISE * 2.5, 0);
    let minX = Infinity; let maxX = -Infinity; let minY = Infinity; let maxY = -Infinity;
    const turns = isMap ? [0] : Array.from({ length: 12 }, (_, k) => (k / 12) * Math.PI * 2);
    for (const rot of turns) {
      for (const p of framingPoints) {
        const v = p.clone().applyAxisAngle(UP, rot).sub(origin);
        const x = v.dot(right); const y = v.dot(up);
        minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y);
      }
    }
    target.copy(origin).addScaledVector(right, (minX + maxX) / 2).addScaledVector(up, (minY + maxY) / 2);
    const halfW = (maxX - minX) / 2;
    const halfH = (maxY - minY) / 2;
    baseH = Math.max(halfH, halfW / aspect) * (isMap ? 1.04 : 1.0);
    camera.position.copy(target).addScaledVector(VIEW_DIR, 120);
    camera.lookAt(target);
    applyFrustum(aspect);
    controls?.target.copy(target);
  }
  function applyFrustum(aspect) {
    camera.left = -baseH * aspect; camera.right = baseH * aspect;
    camera.top = baseH; camera.bottom = -baseH;
    camera.updateProjectionMatrix();
  }

  /* ---------- Controls (map) ---------- */
  let controls = null;
  let anim = null;
  let pristine = true;
  const home = { target: new THREE.Vector3(), zoom: 1 };
  if (isMap) {
    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.09;
    controls.screenSpacePanning = true;
    controls.minZoom = 0.7;
    controls.maxZoom = 4.5;
    controls.zoomSpeed = 1.2;
    controls.minPolarAngle = 0.55;
    controls.maxPolarAngle = 1.2;
    controls.touches = { ONE: THREE.TOUCH.PAN, TWO: THREE.TOUCH.DOLLY_ROTATE };
    controls.mouseButtons = { LEFT: THREE.MOUSE.PAN, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.ROTATE };
    controls.addEventListener('start', () => { anim = null; pristine = false; });
  }

  function flyTo(toTarget, toZoom, ms = 850) {
    anim = { t0: performance.now(), ms: reduced ? 1 : ms, fromT: controls.target.clone(), toT: toTarget.clone(), fromZ: camera.zoom, toZ: toZoom, offset: camera.position.clone().sub(controls.target) };
  }

  /* ---------- Status painting ---------- */
  let selected = null;
  let hovered = null;
  let nextId = null;
  let mascotHop = null;
  const gold = new THREE.Color(C.tileDone);
  const white = new THREE.Color(C.tile);

  function mascotSpot(id) {
    if (id && tiles.has(id)) { const t = tiles.get(id); return t.island.center.clone().add(t.local).setY(t.island.center.y + TILE_H + 0.02); }
    const last = islands[islands.length - 1];
    return last.center.clone().add(last.summit || new THREE.Vector3()).add(new THREE.Vector3(-0.7, 0, 0.4));
  }

  function refresh() {
    const n = getNext();
    for (const [id, t] of tiles) {
      const { status, pct } = getProgress(id);
      t.status = status;
      if (status === 'done') t.mat.color.copy(gold);
      else if (status === 'progress') t.mat.color.copy(white).lerp(new THREE.Color(t.island.orbit.color), 0.35 + pct / 250);
      else t.mat.color.copy(white);
      t.star.visible = status === 'done';
      t.liftTarget = id === selected ? 0.32 : id === hovered ? 0.16 : 0;
      if (t.label) {
        const el = t.label.element;
        el.classList.toggle('done', status === 'done');
        el.classList.toggle('next', id === n);
        el.classList.toggle('hover', id === hovered);
        el.classList.toggle('sel', id === selected);
      }
    }
    if (n !== nextId) {
      const to = mascotSpot(n);
      if (nextId === null && !mascotHop) mascot.position.copy(to);
      else mascotHop = { t0: performance.now(), from: mascot.position.clone(), to, ms: reduced ? 1 : 700 };
      nextId = n;
    }
    pulse.visible = Boolean(n);
    if (n) { const p = mascotSpot(n); pulse.position.set(p.x, p.y - TILE_H - 0.0, p.z); pulse.position.y = tiles.get(n).island.center.y + 0.03; }
  }

  /* ---------- Picking & selection (map) ---------- */
  const raycaster = new THREE.Raycaster();
  const ptr = new THREE.Vector2();
  const pickable = [...tiles.values()].map((t) => t.mesh);
  const pick = (ev) => {
    const rect = renderer.domElement.getBoundingClientRect();
    ptr.set(((ev.clientX - rect.left) / rect.width) * 2 - 1, -((ev.clientY - rect.top) / rect.height) * 2 + 1);
    raycaster.setFromCamera(ptr, camera);
    const hit = raycaster.intersectObjects(pickable, false)[0];
    return hit ? hit.object.userData.topicId : null;
  };

  function select(id, { fly = true } = {}) {
    selected = id;
    refresh();
    if (!controls || !fly) return;
    pristine = false;
    if (id) {
      const t = tiles.get(id);
      const p = t.island.center.clone().add(t.local);
      // Keep the tile left of centre on wide screens so the side panel doesn't cover it.
      const right = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion);
      const zoom = Math.max(camera.zoom, small ? 2.2 : 2.4);
      const shift = innerWidth > 760 ? (baseH * (container.clientWidth / container.clientHeight)) / zoom * 0.35 : 0;
      const up = new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion);
      const vshift = innerWidth > 760 ? 0 : -(baseH / zoom) * 0.35;
      flyTo(p.addScaledVector(right, shift).addScaledVector(up, -vshift), zoom);
    } else {
      flyTo(home.target, home.zoom);
    }
  }

  if (isMap) {
    renderer.domElement.addEventListener('pointermove', (ev) => {
      if (ev.pointerType !== 'mouse' || ev.buttons) return;
      const id = pick(ev);
      if (id !== hovered) { hovered = id; renderer.domElement.style.cursor = id ? 'pointer' : 'grab'; refresh(); }
    });
    let down = null;
    renderer.domElement.addEventListener('pointerdown', (ev) => { down = { x: ev.clientX, y: ev.clientY }; });
    renderer.domElement.addEventListener('pointerup', (ev) => {
      if (!down || Math.hypot(ev.clientX - down.x, ev.clientY - down.y) > 6) return;
      const id = pick(ev);
      if (id) { select(id); onSelect(id); } else if (selected) { select(null); onSelect(null); }
    });
    renderer.domElement.style.cursor = 'grab';
  }

  /* ---------- Loop ---------- */
  const t0 = performance.now();
  let last = t0;
  let visible = true;
  let active = true;
  let raf = 0;
  let introDone = reduced;
  const camPos = new THREE.Vector3();

  function tick(now) {
    raf = requestAnimationFrame(tick);
    if (!visible || !active || document.hidden) { last = now; return; }
    const dt = Math.min((now - last) / 1000, 0.05);
    last = now;
    const t = (now - t0) / 1000;

    // One orchestrated entrance: islands rise into place, then the bridges are laid plank by plank.
    if (!introDone) {
      islandGroups.forEach((g, i) => {
        const k = easeBack((t - i * 0.12) / 0.9);
        g.position.y = islands[i].center.y - (1 - k) * 9;
        g.scale.setScalar(0.6 + 0.4 * Math.min(k, 1));
      });
      planks.forEach((p, k) => p.scale.setScalar(ease((t - 0.9 - k * 0.012) / 0.25)));
      if (t > 0.9 + planks.length * 0.012 + 0.3) {
        introDone = true;
        if (isMap && pristine && container.clientWidth / container.clientHeight < 0.9 && nextId) {
          const tile = tiles.get(nextId);
          const p = tile.island.center.clone().add(tile.local);
          pristine = false;
          flyTo(p, 2.6, 1100);
        }
        islandGroups.forEach((g, i) => { g.position.y = islands[i].center.y; g.scale.setScalar(1); });
        planks.forEach((p) => p.scale.setScalar(1));
      }
    }

    if (!reduced) {
      if (!isMap) world.rotation.y += dt * 0.06;
      for (const c of clouds) {
        c.userData.ang += dt * c.userData.speed;
        c.position.set(Math.cos(c.userData.ang) * c.userData.rad, c.userData.y, Math.sin(c.userData.ang) * c.userData.rad);
      }
      for (const tile of tiles.values()) if (tile.star.visible) tile.star.rotation.y += dt * 1.6;
      const last5 = islands[islands.length - 1];
      if (last5.flag) last5.flag.rotation.y = Math.sin(t * 2) * 0.18;
    }

    // Tile lift on hover/selection
    for (const tile of tiles.values()) {
      tile.lift += (tile.liftTarget - tile.lift) * Math.min(1, dt * 12);
      tile.mesh.position.y = tile.base + tile.lift;
    }

    // Mascot: hop to the next level, bob, face the camera
    if (mascotHop) {
      const k = Math.min((now - mascotHop.t0) / mascotHop.ms, 1);
      mascot.position.lerpVectors(mascotHop.from, mascotHop.to, ease(k));
      mascot.position.y += Math.sin(Math.PI * k) * 1.4;
      if (k >= 1) mascotHop = null;
    }
    const bob = reduced ? 0 : Math.abs(Math.sin(t * 2.6)) * 0.22;
    const lifted = nextId && tiles.has(nextId) ? tiles.get(nextId).lift : 0;
    mascot.userData.inner.position.y = 0.42 + bob + lifted;
    mascot.userData.inner.scale.set(1 + (0.22 - bob) * 0.12, 1 - (0.22 - bob) * 0.12, 1 + (0.22 - bob) * 0.12);
    camera.getWorldPosition(camPos);
    const mw = mascot.getWorldPosition(new THREE.Vector3());
    mascot.lookAt(camPos.x, mw.y, camPos.z);
    if (pulse.visible) {
      const k = reduced ? 0.5 : (t * 0.7) % 1;
      pulse.scale.setScalar(0.85 + k * 0.6);
      pulse.material.opacity = 0.7 * (1 - k);
    }

    if (anim && controls) {
      const k = ease((now - anim.t0) / anim.ms);
      controls.target.lerpVectors(anim.fromT, anim.toT, k);
      camera.position.copy(controls.target).add(anim.offset);
      camera.zoom = THREE.MathUtils.lerp(anim.fromZ, anim.toZ, k);
      camera.updateProjectionMatrix();
      if (k >= 1) anim = null;
    }
    if (controls) {
      controls.update();
      // Keep panning within the world.
      const lim = 22;
      const tx = THREE.MathUtils.clamp(controls.target.x, -lim, lim);
      const tz = THREE.MathUtils.clamp(controls.target.z, -lim, lim);
      const ty = THREE.MathUtils.clamp(controls.target.y, -4, RISE * 6 + 4);
      if (tx !== controls.target.x || ty !== controls.target.y || tz !== controls.target.z) {
        const d = new THREE.Vector3(tx, ty, tz).sub(controls.target);
        controls.target.add(d);
        camera.position.add(d);
      }
      // Level of detail for labels: world names in the overview, level names when zoomed in.
      const near = camera.zoom >= 1.6;
      for (const [id, tile] of tiles) tile.label.visible = introDone && (near || id === nextId || id === selected || id === hovered);
      for (const isl of islands) isl.worldLabel.visible = introDone && !near;
    }

    renderer.render(scene, camera);
    labels?.render(scene, camera);
  }

  /* ---------- Resize / visibility ---------- */
  function onResize() {
    const w = container.clientWidth || 1;
    const h = container.clientHeight || 1;
    renderer.setSize(w, h, false);
    labels?.setSize(w, h);
    if (pristine || !isMap) {
      fit();
      home.target.copy(target);
      home.zoom = 1;
    } else {
      applyFrustum(w / h);
    }
  }
  const ro = new ResizeObserver(onResize);
  ro.observe(container);
  const io = new IntersectionObserver(([e]) => { visible = e.isIntersecting; }, { threshold: 0 });
  io.observe(container);
  onResize();
  refresh();
  raf = requestAnimationFrame(tick);

  return {
    refresh,
    select,
    focusNext() {
      const id = getNext();
      if (id) { select(id); onSelect(id); }
    },
    showAll() { select(null); onSelect(null); },
    get selected() { return selected; },
    setActive(on) { active = on; },
    dispose() {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      controls?.dispose();
      textures.forEach((t) => t.dispose());
      kit.dispose();
      renderer.dispose();
      container.innerHTML = '';
    },
  };
}
