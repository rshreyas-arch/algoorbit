// Auth + learning progress. Guests keep progress in localStorage; signed-in users sync to Supabase
// (row-level security guarantees each account can only read and change its own rows).
import { AUTH_ENABLED, SUPABASE_URL, SUPABASE_KEY } from './config.js';
import { TOPICS, LEVELS, itemXp, ITEM_RE } from './data.js';

const LOCAL_KEY = 'algoorbit:progress:v1';
const listeners = new Set();

const state = {
  items: new Map(), // itemId -> ISO timestamp
  user: null,
  profile: null,
  ready: false,
  remote: false,
};

let sb = null;

/* ---------------- Supabase client (loaded only when needed) ---------------- */
function storedSessionKey() {
  try { return `sb-${new URL(SUPABASE_URL).hostname.split('.')[0]}-auth-token`; } catch { return ''; }
}
function hasStoredSession() {
  try { return Boolean(localStorage.getItem(storedSessionKey())); } catch { return false; }
}

export async function getClient() {
  if (!AUTH_ENABLED) return null;
  if (sb) return sb;
  const { createClient } = await import('@supabase/supabase-js');
  sb = createClient(SUPABASE_URL, SUPABASE_KEY, {
    auth: { flowType: 'pkce', persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
  });
  return sb;
}

/* ---------------- Local storage ---------------- */
function readLocal() {
  try {
    const raw = JSON.parse(localStorage.getItem(LOCAL_KEY) || '{}');
    return new Map(Object.entries(raw).filter(([k, v]) => ITEM_RE.test(k) && typeof v === 'string'));
  } catch { return new Map(); }
}
function writeLocal(map) {
  try { localStorage.setItem(LOCAL_KEY, JSON.stringify(Object.fromEntries(map))); } catch { /* storage full or blocked */ }
}
function clearLocal() {
  try { localStorage.removeItem(LOCAL_KEY); } catch { /* ignore */ }
}

/* ---------------- Init ---------------- */
let initPromise = null;
/**
 * @param {{ needAuth?: boolean }} opts needAuth forces loading Supabase (login, account, tutor pages)
 */
export function init(opts = {}) {
  if (!initPromise) initPromise = doInit(opts);
  return initPromise;
}

async function doInit({ needAuth = false } = {}) {
  state.items = readLocal();
  if (AUTH_ENABLED && (needAuth || hasStoredSession() || /[?&#](code|access_token)=/.test(location.href))) {
    const client = await getClient();
    const { data } = await client.auth.getSession();
    await applySession(data.session);
    client.auth.onAuthStateChange((event, session) => {
      // Defer: Supabase recommends not awaiting other calls inside this callback.
      setTimeout(() => {
        if (event === 'SIGNED_OUT') applySession(null);
        else if (event === 'SIGNED_IN' && session?.user?.id !== state.user?.id) applySession(session);
        else if (event === 'USER_UPDATED' && session) { state.user = session.user; emit(); }
      }, 0);
    });
  }
  state.ready = true;
  emit();
  return state;
}

let applying = null;
function applySession(session) {
  // Supabase can report the same sign-in twice (initial session + SIGNED_IN); run once per user.
  const key = session?.user?.id || 'none';
  if (applying?.key === key) return applying.promise;
  const promise = doApplySession(session);
  applying = { key, promise };
  return promise;
}

async function doApplySession(session) {
  if (!session) {
    state.user = null;
    state.profile = null;
    state.remote = false;
    state.items = readLocal();
    emit();
    return;
  }
  state.user = session.user;
  state.remote = true;
  try {
    await mergeGuestProgress();
    await loadRemote();
    const { data } = await sb.from('profiles').select('display_name').eq('id', state.user.id).maybeSingle();
    state.profile = data || { display_name: null };
  } catch (err) {
    console.warn('Could not load account data', err);
  }
  emit();
}

async function loadRemote() {
  const { data, error } = await sb.from('progress').select('item_id, completed_at').limit(1000);
  if (error) throw error;
  state.items = new Map(data.map((r) => [r.item_id, r.completed_at]));
}

async function mergeGuestProgress() {
  const local = readLocal();
  if (!local.size) return;
  const rows = [...local].map(([item_id, completed_at]) => ({ user_id: state.user.id, item_id, completed_at }));
  const { error } = await sb.from('progress').upsert(rows, { onConflict: 'user_id,item_id', ignoreDuplicates: true });
  if (!error) clearLocal();
}

/* ---------------- Queries ---------------- */
export const getState = () => state;
export const isDone = (id) => state.items.has(id);

export function onChange(fn) {
  listeners.add(fn);
  if (state.ready) fn(state);
  return () => listeners.delete(fn);
}
function emit() { for (const fn of listeners) fn(state); }

/* ---------------- Mutations ---------------- */
export async function setDone(id, done) {
  if (!itemXp.has(id)) return { ok: false };
  const before = stats();
  const prev = state.items.get(id);
  if (done) state.items.set(id, new Date().toISOString());
  else state.items.delete(id);
  emit();

  if (!state.remote) {
    writeLocal(state.items);
    return { ok: true, before, after: stats() };
  }
  const q = done
    ? sb.from('progress').insert({ user_id: state.user.id, item_id: id })
    : sb.from('progress').delete().eq('user_id', state.user.id).eq('item_id', id);
  const { error } = await q;
  if (error && !(done && error.code === '23505')) {
    // Roll back the optimistic update.
    if (done) state.items.delete(id); else state.items.set(id, prev);
    emit();
    return { ok: false, error };
  }
  return { ok: true, before, after: stats() };
}

export async function updateDisplayName(name) {
  const clean = name.trim().slice(0, 40);
  const { error } = await sb.from('profiles').update({ display_name: clean || null }).eq('id', state.user.id);
  if (!error) { state.profile = { ...state.profile, display_name: clean }; emit(); }
  return { error };
}

export async function signOut() {
  if (sb) await sb.auth.signOut();
  await applySession(null);
}

/* ---------------- Derived stats ---------------- */
export function levelFor(xp) {
  let i = 0;
  while (i + 1 < LEVELS.length && xp >= LEVELS[i + 1].at) i++;
  return { index: i, current: LEVELS[i], next: LEVELS[i + 1] || null };
}

const dayKey = (iso) => {
  const d = new Date(iso);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
};

export function streak(items = state.items) {
  const days = new Set([...items.values()].map(dayKey));
  const cursor = new Date();
  if (!days.has(dayKey(cursor.toISOString()))) cursor.setDate(cursor.getDate() - 1); // today not done yet: count up to yesterday
  let n = 0;
  while (days.has(dayKey(cursor.toISOString()))) { n++; cursor.setDate(cursor.getDate() - 1); }
  return n;
}

export function topicProgress(topicId) {
  const t = TOPICS.find((x) => x.id === topicId);
  let concepts = 0;
  let problems = 0;
  for (let k = 1; k <= t.concepts; k++) if (state.items.has(`${t.id}:c${k}`)) concepts++;
  for (const [slug] of t.problems) if (state.items.has(`${t.id}:p:${slug}`)) problems++;
  const total = t.concepts + t.problems.length;
  const done = concepts + problems;
  const complete = concepts === t.concepts && problems >= Math.min(3, t.problems.length);
  return {
    concepts, problems, done, total,
    pct: Math.round((done / total) * 100),
    status: complete ? 'done' : done > 0 ? 'progress' : 'todo',
  };
}

export function stats() {
  let xp = 0;
  for (const id of state.items.keys()) xp += itemXp.get(id) || 0;
  const perTopic = new Map(TOPICS.map((t) => [t.id, topicProgress(t.id)]));
  const topicsDone = [...perTopic.values()].filter((p) => p.status === 'done').length;
  const next =
    TOPICS.find((t) => perTopic.get(t.id).status !== 'done' && t.prereqs.every((p) => perTopic.get(p).status === 'done')) ||
    TOPICS.find((t) => perTopic.get(t.id).status !== 'done') || null;
  return { xp, level: levelFor(xp), streak: streak(), perTopic, topicsDone, next: next?.id || null, items: state.items.size };
}
