import { init, onChange, stats, getState } from './store.js';
import { url } from './config.js';

/* ---------------- Toast ---------------- */
const COIN = '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><circle cx="12" cy="12" r="9.5" fill="#e9b949" stroke="#7d570c" stroke-width="1.6"/><path d="M12 7v10M9.5 9.5h4a1.8 1.8 0 0 1 0 3.5h-3a1.8 1.8 0 0 0 0 3.5h4" fill="none" stroke="#7d570c" stroke-width="1.8" stroke-linecap="round"/></svg>';
let toastTimer;
export function toast(message, kind = '') {
  const el = document.querySelector('.toast');
  if (!el) return;
  el.innerHTML = '';
  if (kind === 'xp') el.insertAdjacentHTML('afterbegin', COIN);
  el.append(document.createTextNode(message));
  el.className = 'toast';
  void el.offsetWidth; // restart the pop animation when toasts arrive back to back
  el.className = `toast show ${kind}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = 'toast'; }, 2600);
}

/** A short burst of confetti in the world colours. Skipped when the viewer prefers reduced motion. */
export function confetti() {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const canvas = document.createElement('canvas');
  canvas.className = 'confetti';
  const dpr = Math.min(devicePixelRatio || 1, 2);
  canvas.width = innerWidth * dpr;
  canvas.height = innerHeight * dpr;
  document.body.appendChild(canvas);
  const g = canvas.getContext('2d');
  g.scale(dpr, dpr);
  const colors = ['#e9b949', '#b5cf8e', '#93cbbf', '#bdb0dd', '#a8b9e0', '#e8b196', '#101218'];
  const parts = Array.from({ length: 140 }, () => ({
    x: innerWidth / 2 + (Math.random() - 0.5) * 160,
    y: innerHeight * 0.62,
    vx: (Math.random() - 0.5) * 13,
    vy: -9 - Math.random() * 11,
    r: Math.random() * Math.PI,
    vr: (Math.random() - 0.5) * 0.35,
    w: 7 + Math.random() * 6,
    h: 4 + Math.random() * 5,
    c: colors[(Math.random() * colors.length) | 0],
  }));
  const t0 = performance.now();
  const frame = (now) => {
    const t = now - t0;
    g.clearRect(0, 0, innerWidth, innerHeight);
    for (const p of parts) {
      p.vy += 0.38; p.vx *= 0.99; p.x += p.vx; p.y += p.vy; p.r += p.vr;
      g.save();
      g.globalAlpha = Math.max(0, 1 - t / 2200);
      g.translate(p.x, p.y); g.rotate(p.r);
      g.fillStyle = p.c;
      g.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      g.restore();
    }
    if (t < 2200) requestAnimationFrame(frame); else canvas.remove();
  };
  requestAnimationFrame(frame);
}

/** Celebrate XP changes after a toggle. */
export function celebrate(result) {
  if (!result?.ok || !result.before) return;
  const gained = result.after.xp - result.before.xp;
  if (result.after.level.index > result.before.level.index) {
    toast(`Rank up! You're now a ${result.after.level.current.name}.`, 'xp');
    confetti();
  } else if (gained > 0) {
    toast(`+${gained} XP`, 'xp');
  }
}

/* ---------------- Header ---------------- */
function bindMenu() {
  const btn = document.querySelector('.menu-btn');
  const nav = document.getElementById('site-nav');
  if (!btn || !nav) return;
  btn.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    btn.setAttribute('aria-expanded', String(open));
    btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  });
}

function initials(state) {
  const name = state.profile?.display_name || state.user?.user_metadata?.full_name || state.user?.email || '?';
  return name.trim().charAt(0).toUpperCase() || '?';
}

/** Fill every [data-xp], [data-level-name], [data-streak], [data-done-topics] on the page. */
export function paintStats() {
  const s = stats();
  const set = (sel, v) => document.querySelectorAll(sel).forEach((el) => { el.textContent = v; });
  set('[data-xp]', s.xp.toLocaleString('en-IN'));
  set('[data-level-name]', s.level.current.name);
  set('[data-streak]', s.streak);
  set('[data-done-topics]', `${s.topicsDone}/${s.perTopic.size}`);
  return s;
}

function paintHeader(state) {
  const signedIn = Boolean(state.user);
  document.querySelectorAll('[data-auth="in"]').forEach((el) => { el.hidden = !signedIn; });
  document.querySelectorAll('[data-auth="out"]').forEach((el) => { el.hidden = signedIn; });
  document.querySelectorAll('[data-initial]').forEach((el) => { el.textContent = initials(state); });
  document.querySelectorAll('[data-sync-note]').forEach((el) => {
    if (signedIn) el.textContent = 'Synced to your account.';
  });
  paintStats();
}

/* ---------------- Ads ---------------- */
function initAds() {
  const cfgEl = document.getElementById('ad-config');
  if (!cfgEl) return;
  let cfg;
  try { cfg = JSON.parse(cfgEl.textContent); } catch { return; }
  document.querySelectorAll('[data-ad-slot]').forEach((slot) => {
    const ins = document.createElement('ins');
    ins.className = 'adsbygoogle';
    ins.style.display = 'block';
    ins.dataset.adClient = cfg.client;
    ins.dataset.adSlot = cfg.slot;
    ins.dataset.adFormat = 'auto';
    ins.dataset.fullWidthResponsive = 'true';
    slot.appendChild(ins);
    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch { /* blocked by an ad blocker */ }
  });
}

/* ---------------- Search ---------------- */
function bindSearch() {
  const open = () => import('./search.js').then((m) => m.openSearch());
  document.querySelectorAll('[data-search-open]').forEach((btn) => btn.addEventListener('click', open));
  document.addEventListener('keydown', (e) => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.target.isContentEditable;
    if ((e.key === 'k' && (e.metaKey || e.ctrlKey)) || (e.key === '/' && !typing && !e.metaKey && !e.ctrlKey && !e.altKey)) {
      e.preventDefault();
      open();
    }
  });
}

/* ---------------- Boot ---------------- */
export async function boot(opts = {}) {
  bindMenu();
  bindSearch();
  initAds();
  onChange(paintHeader);
  await init(opts);
  return getState();
}

export { url };
