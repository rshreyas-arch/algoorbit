import data from '../generated/roadmap.json';

export const ORBITS = data.orbits;
export const TOPICS = data.topics;
export const XP = data.xp;
export const LEVELS = data.levels;

export const topicById = new Map(TOPICS.map((t) => [t.id, t]));
export const orbitById = new Map(ORBITS.map((o) => [o.id, o]));

/** The quick check on a topic page is tracked like a problem, so it needs no extra database rule. */
export const quizItem = (topicId) => `${topicId}:p:quiz`;

/** Every trackable item id → XP value. Concepts are "topic:cN", problems "topic:p:slug", the quick check "topic:p:quiz". */
export const itemXp = new Map();
for (const t of TOPICS) {
  for (let k = 1; k <= t.concepts; k++) itemXp.set(`${t.id}:c${k}`, XP.concept);
  for (const [slug, d] of t.problems) itemXp.set(`${t.id}:p:${slug}`, XP[d]);
  itemXp.set(quizItem(t.id), XP.quiz);
}

export const ITEM_RE = /^[a-z0-9-]+:(c[0-9]{1,2}|p:[a-z0-9-]+)$/;
