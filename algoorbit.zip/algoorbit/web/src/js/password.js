const COMMON = new Set(['password', 'password1', '12345678', '123456789', '1234567890', 'qwerty123', 'iloveyou', 'admin123', 'welcome1', 'letmein1', 'abcd1234', 'password123', 'qwertyuiop']);

/** 0–4 rough strength score for the meter. Supabase enforces the real minimum server-side. */
export function score(pw) {
  if (!pw) return 0;
  if (pw.length < 8 || COMMON.has(pw.toLowerCase())) return 1;
  let s = 1;
  if (pw.length >= 12) s++;
  if (pw.length >= 16) s++;
  const classes = [/[a-z]/, /[A-Z]/, /\d/, /[^a-zA-Z0-9]/].filter((r) => r.test(pw)).length;
  if (classes >= 3) s++;
  return Math.min(s, 4);
}

export function bindPasswordUI(root = document) {
  root.querySelectorAll('.pw-toggle').forEach((btn) => {
    const input = document.getElementById(btn.getAttribute('aria-controls'));
    btn.addEventListener('click', () => {
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.textContent = show ? 'Hide' : 'Show';
      btn.setAttribute('aria-pressed', String(show));
    });
  });
}

export function bindStrength(input, meter) {
  input.addEventListener('input', () => { meter.dataset.score = String(score(input.value)); });
}

const MESSAGES = {
  invalid_credentials: "That email and password don't match. Try again, or reset your password.",
  email_not_confirmed: 'Confirm your email first — open the link we sent to your inbox.',
  user_already_exists: 'An account with this email already exists. Sign in instead.',
  email_exists: 'An account with this email already exists. Sign in instead.',
  weak_password: 'Choose a stronger password: at least 8 characters, not a common one.',
  over_request_rate_limit: 'Too many attempts. Wait a minute and try again.',
  over_email_send_rate_limit: 'Too many emails sent. Wait a few minutes before requesting another.',
  same_password: 'Your new password must be different from the old one.',
  validation_failed: 'Check the email address and try again.',
};

export function authMessage(error) {
  if (!error) return '';
  if (error.code && MESSAGES[error.code]) return MESSAGES[error.code];
  if (error.status === 429) return MESSAGES.over_request_rate_limit;
  if (/network|fetch/i.test(error.message || '')) return 'Network error — check your connection and try again.';
  return error.message || 'Something went wrong. Try again.';
}

/** Only allow same-site relative redirects (prevents open-redirect abuse of ?next=). */
export function safeNext(raw, fallback = '/roadmap/') {
  if (!raw || !raw.startsWith('/') || raw.startsWith('//') || raw.includes('\\')) return fallback;
  return raw;
}
