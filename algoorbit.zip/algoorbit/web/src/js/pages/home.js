import { boot } from '../ui.js';
import { onChange, stats, topicProgress } from '../store.js';
import { TOPICS, ORBITS } from '../data.js';

boot();

const heroEl = document.getElementById('hero-scene');
let scene = null;
// Load Three.js after first paint so the headline renders immediately.
const start = () => import('../world-scene.js').then(({ createWorldScene }) => {
  scene = createWorldScene(heroEl, {
    mode: 'hero',
    getProgress: topicProgress,
    getNext: () => stats().next,
  });
});
if ('requestIdleCallback' in window) requestIdleCallback(start, { timeout: 800 });
else setTimeout(start, 200);

onChange(() => {
  scene?.refresh();
  document.querySelectorAll('[data-topic-chip]').forEach((el) => {
    el.classList.toggle('done', topicProgress(el.dataset.topicChip).status === 'done');
  });
  for (const o of ORBITS) {
    const ids = TOPICS.filter((t) => t.orbit === o.id).map((t) => t.id);
    const cleared = ids.filter((id) => topicProgress(id).status === 'done').length;
    const meter = document.querySelector(`[data-world-meter="${o.id}"]`);
    if (meter) meter.style.width = `${(cleared / ids.length) * 100}%`;
    const count = document.querySelector(`[data-world-count="${o.id}"]`);
    if (count) count.textContent = `${cleared} of ${ids.length} cleared`;
  }
});
