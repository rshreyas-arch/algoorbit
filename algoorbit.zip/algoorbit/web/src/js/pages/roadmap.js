import { boot, url } from '../ui.js';
import { onChange, stats, topicProgress } from '../store.js';
import { TOPICS, topicById, orbitById } from '../data.js';
import { createWorldScene } from '../world-scene.js';
import { topicIcon, mascot } from '../../content/icons.js';

boot();

const sceneEl = document.getElementById('scene');
const panel = document.getElementById('topic-panel');
const panelBody = panel.querySelector('[data-panel-body]');
const listView = document.getElementById('list-view');
const toggles = [...document.querySelectorAll('[data-view]')];
const jumpBtn = document.querySelector('[data-jump]');
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const levelOf = (id) => TOPICS.findIndex((t) => t.id === id) + 1;

let current = null;

function renderPanel(id) {
  const t = topicById.get(id);
  const o = orbitById.get(t.orbit);
  const p = topicProgress(id);
  const isNext = stats().next === id;
  const prereqs = t.prereqs.map((pid) => topicById.get(pid));
  panel.style.setProperty('--c', o.ui);
  panel.style.setProperty('--t', o.tint);
  const status = p.status === 'done' ? 'Cleared' : p.done ? `${p.pct}% done` : 'Not started';
  panelBody.innerHTML = `
    <div class="p-head">
      <span class="icon-tile" style="background:var(--surface);box-shadow:var(--sh-1)">${topicIcon(t.id, 30)}</span>
      <div><span class="lv">Level ${levelOf(id)}, World ${o.n}: ${esc(o.title)}</span><h2>${esc(t.title)}</h2></div>
    </div>
    <div class="p-body">
      ${isNext ? `<div class="next-note">${mascot(32)}Orbi is waiting here. This is your next level.</div>` : ''}
      <p class="sum">${esc(t.summary)}</p>
      <div class="meter"><i style="width:${p.pct}%"></i></div>
      <div class="counts"><span>${status}</span><span>${t.concepts} concepts, ${t.problems.length} challenges, about ${t.hours} h</span></div>
      <p class="prereq">${prereqs.length ? `Builds on ${prereqs.map((x) => `<a href="${url(`/learn/${x.id}/`)}">${esc(x.short)}</a>`).join(', ')}` : 'A good place to start: no prerequisites.'}</p>
      <div class="actions">
        <a class="btn btn-go" href="${url(`/learn/${t.id}/`)}">${p.status === 'done' ? 'Review level' : p.done ? 'Continue level' : 'Start level'}</a>
        <a class="btn" href="${url('/tutor/')}?topic=${t.id}">Ask Orbi about ${esc(t.short)}</a>
      </div>
    </div>`;
}

function openPanel(id) {
  current = id;
  if (!id) { panel.classList.remove('open'); return; }
  renderPanel(id);
  panel.classList.add('open');
}

/* ---------- 3D scene ---------- */
const scene = createWorldScene(sceneEl, {
  mode: 'map',
  getProgress: topicProgress,
  getNext: () => stats().next,
  onSelect: openPanel,
});

panel.querySelector('.close').addEventListener('click', () => { scene?.select(null); openPanel(null); });
jumpBtn.addEventListener('click', () => {
  if (!listView.hidden) setView('3d');
  const id = stats().next;
  if (!id) return;
  if (scene) { scene.select(id); openPanel(id); } else location.href = url(`/learn/${id}/`);
});

/* Keyboard: the map is focusable; arrows move between levels, Enter opens one, Escape closes. */
if (scene) {
  sceneEl.tabIndex = 0;
  sceneEl.setAttribute('aria-hidden', 'false');
  sceneEl.setAttribute('role', 'application');
  sceneEl.setAttribute('aria-label', '3D map of the roadmap. Use the arrow keys to move between levels and Enter to open one. The List view shows the same roadmap as text.');
  sceneEl.addEventListener('keydown', (e) => {
    const ids = TOPICS.map((t) => t.id);
    const step = (dir) => {
      e.preventDefault();
      // First press lands on your next level; later presses move along the roadmap.
      const id = scene.selected
        ? ids[(ids.indexOf(scene.selected) + dir + ids.length) % ids.length]
        : stats().next || ids[0];
      scene.select(id); openPanel(id);
    };
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') step(1);
    else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') step(-1);
    else if (e.key === 'Enter' && scene.selected) location.href = url(`/learn/${scene.selected}/`);
    else if (e.key === 'Escape') { scene.select(null); openPanel(null); }
  });
} else {
  // No WebGL: the list is the roadmap.
  setView('list');
  toggles.find((b) => b.dataset.view === '3d').disabled = true;
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && current) { scene?.select(null); openPanel(null); }
});

/* ---------- View toggle ---------- */
function setView(v) {
  listView.hidden = v !== 'list';
  for (const b of toggles) b.setAttribute('aria-pressed', String(b.dataset.view === v));
  document.querySelector('.hud-legend').hidden = v === 'list';
  document.querySelector('.hud-help').hidden = v === 'list';
  if (v === 'list') { scene?.select(null, { fly: false }); openPanel(null); }
  scene?.setActive(v !== 'list');
  try { localStorage.setItem('algoorbit:view', v); } catch { /* ignore */ }
}
toggles.forEach((b) => b.addEventListener('click', () => setView(b.dataset.view)));
try { if (localStorage.getItem('algoorbit:view') === 'list') setView('list'); } catch { /* ignore */ }

/* ---------- Progress updates ---------- */
onChange(() => {
  scene?.refresh();
  const next = stats().next;
  jumpBtn.hidden = !next;
  document.querySelectorAll('[data-path-item]').forEach((li) => {
    const id = li.dataset.pathItem;
    const p = topicProgress(id);
    const o = orbitById.get(topicById.get(id).orbit);
    li.className = `path-item ${p.status === 'done' ? 'done' : p.status === 'progress' ? 'prog' : ''} ${id === next ? 'next' : ''}`;
    li.style.setProperty('--c', o.ui);
    li.style.setProperty('--t', o.tint);
    li.querySelector('[data-pct]').textContent = p.status === 'done' ? 'Cleared' : p.pct ? `${p.pct}%` : '';
    li.querySelector('.nx').hidden = id !== next;
  });
  if (current) renderPanel(current);
});

// Deep link: /roadmap/#arrays opens that level.
const hash = decodeURIComponent(location.hash.slice(1));
if (scene && topicById.has(hash)) setTimeout(() => { scene.select(hash); openPanel(hash); }, 1600);
