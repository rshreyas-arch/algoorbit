import { boot, toast, url, paintStats } from '../ui.js';
import { getClient, getState, onChange, signOut, updateDisplayName } from '../store.js';
import { AUTH_ENABLED } from '../config.js';

const signedInEls = document.querySelector('[data-signed-in]');
const gate = document.getElementById('account-gate');
const nameInput = document.getElementById('display-name');

await boot({ needAuth: AUTH_ENABLED });

onChange((state) => {
  const s = paintStats();
  const { current, next } = s.level;
  const pct = next ? ((s.xp - current.at) / (next.at - current.at)) * 100 : 100;
  document.querySelector('[data-level-meter]').style.width = `${Math.min(100, pct)}%`;
  document.querySelector('[data-level-from]').textContent = current.name;
  document.querySelector('[data-level-to]').textContent = next ? `${next.at - s.xp} XP to ${next.name}` : 'Top level reached';

  const user = state.user;
  signedInEls.hidden = !user;
  gate.hidden = Boolean(user);
  if (user) {
    const name = state.profile?.display_name || '';
    document.querySelector('[data-greeting]').textContent = name ? `Hi, ${name}` : 'Your account';
    document.querySelector('[data-email]').textContent = `Signed in as ${user.email}`;
    if (document.activeElement !== nameInput) nameInput.value = name;
  }
});

document.getElementById('name-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const { error } = await updateDisplayName(nameInput.value);
  toast(error ? 'Could not save your name. Use 1–40 characters.' : 'Name saved.');
});

document.getElementById('export-btn').addEventListener('click', () => {
  const st = getState();
  const payload = {
    exported_at: new Date().toISOString(),
    account: { email: st.user.email, display_name: st.profile?.display_name ?? null, created_at: st.user.created_at },
    progress: [...st.items].map(([item_id, completed_at]) => ({ item_id, completed_at })).sort((a, b) => a.completed_at.localeCompare(b.completed_at)),
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'algoorbit-data.json';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
});

document.getElementById('signout-btn').addEventListener('click', async () => {
  await signOut();
  location.replace(url('/'));
});

document.getElementById('delete-btn').addEventListener('click', async (e) => {
  const ok = confirm('Delete your account permanently?\n\nYour profile, progress and tutor usage records will be erased. This cannot be undone.');
  if (!ok) return;
  const btn = e.currentTarget;
  btn.disabled = true;
  btn.textContent = 'Deleting…';
  try {
    const sb = await getClient();
    const { data } = await sb.auth.getSession();
    const res = await fetch('/api/delete-account', { method: 'POST', headers: { Authorization: `Bearer ${data.session?.access_token}` } });
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Delete failed');
    await sb.auth.signOut({ scope: 'local' }).catch(() => {});
    try { localStorage.removeItem('algoorbit:progress:v1'); sessionStorage.clear(); } catch { /* ignore */ }
    alert('Your account has been deleted.');
    location.replace(url('/'));
  } catch (err) {
    btn.disabled = false;
    btn.textContent = 'Delete my account';
    toast(`${err.message}. Try again, or contact us and we'll delete it for you.`);
  }
});
