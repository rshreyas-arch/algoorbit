import { boot, url } from '../ui.js';
import { getClient, onChange } from '../store.js';
import { TUTOR_ENABLED } from '../config.js';
import { renderMarkdown } from '../markdown.js';
import { topicById } from '../data.js';
import { mascot } from '../../content/icons.js';

const AVATAR = mascot(40);

const log = document.getElementById('chat-log');
const form = document.getElementById('chat-form');
const input = document.getElementById('chat-input');
const sendBtn = form.querySelector('button[type=submit]');
const topicSelect = document.getElementById('topic-select');
const gate = document.getElementById('gate');
const unconfigured = document.getElementById('unconfigured');
const empty = document.getElementById('chat-empty');
const quotaEl = document.querySelector('[data-quota]');
const STORE_KEY = 'algoorbit:chat:v1';
const MAX_SENT = 16;

let messages = [];
let busy = false;
let controller = null;

/* ---------- Topic from ?topic= ---------- */
const params = new URLSearchParams(location.search);
if (topicById.has(params.get('topic'))) topicSelect.value = params.get('topic');

/* ---------- Persistence (this browser tab only) ---------- */
function save() { try { sessionStorage.setItem(STORE_KEY, JSON.stringify(messages.slice(-40))); } catch { /* ignore */ } }
function restore() {
  try {
    const m = JSON.parse(sessionStorage.getItem(STORE_KEY) || '[]');
    if (Array.isArray(m)) messages = m.filter((x) => (x.role === 'user' || x.role === 'assistant') && typeof x.content === 'string');
  } catch { messages = []; }
}

/* ---------- Rendering ---------- */
function bubble(role, content) {
  const el = document.createElement('div');
  el.className = `msg ${role}`;
  if (role === 'assistant') {
    el.insertAdjacentHTML('afterbegin', AVATAR);
    const md = document.createElement('div');
    md.className = 'md';
    md.innerHTML = renderMarkdown(content);
    el.appendChild(md);
  } else {
    el.textContent = content;
  }
  return el;
}

function renderAll() {
  log.querySelectorAll('.msg').forEach((el) => el.remove());
  for (const m of messages) log.appendChild(bubble(m.role, m.content));
  empty.hidden = messages.length > 0 || input.disabled;
  log.scrollTop = log.scrollHeight;
}

function setEnabled(on) {
  input.disabled = !on;
  sendBtn.disabled = !on || busy;
}

/* ---------- Sending ---------- */
async function send(text) {
  const content = text.trim();
  if (!content || busy) return;
  busy = true;
  setEnabled(true);
  empty.hidden = true;
  messages.push({ role: 'user', content });
  log.appendChild(bubble('user', content));
  input.value = '';
  autosize();

  const out = document.createElement('div');
  out.className = 'msg assistant';
  out.innerHTML = `${AVATAR}<div class="md"><span class="typing" aria-label="Orbi is typing"><i></i><i></i><i></i></span></div>`;
  log.appendChild(out);
  log.scrollTop = log.scrollHeight;

  let reply = '';
  controller = new AbortController();
  try {
    const client = await getClient();
    const { data } = await client.auth.getSession();
    if (!data.session) throw Object.assign(new Error('Your session expired. Sign in again to keep chatting.'), { friendly: true });

    const res = await fetch('/api/tutor', {
      method: 'POST',
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${data.session.access_token}` },
      body: JSON.stringify({
        mode: document.querySelector('input[name=mode]:checked').value,
        topic: topicSelect.value || null,
        messages: messages.slice(-MAX_SENT),
      }),
    });

    const remaining = res.headers.get('X-Tutor-Remaining');
    if (remaining !== null) quotaEl.textContent = `${remaining} messages left today`;

    if (!res.ok) {
      let msg = 'The tutor is unavailable right now. Try again in a minute.';
      try { msg = (await res.json()).error || msg; } catch { /* not JSON */ }
      throw Object.assign(new Error(msg), { friendly: true });
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    const md = out.querySelector('.md');
    let pending = false;
    const paint = () => {
      pending = false;
      md.innerHTML = renderMarkdown(reply);
      const nearBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 140;
      if (nearBottom) log.scrollTop = log.scrollHeight;
    };
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      reply += decoder.decode(value, { stream: true });
      if (!pending) { pending = true; requestAnimationFrame(paint); }
    }
    reply += decoder.decode();
    paint();
    if (!reply.trim()) throw Object.assign(new Error('The tutor returned an empty reply. Try rephrasing your question.'), { friendly: true });
    messages.push({ role: 'assistant', content: reply });
    save();
  } catch (err) {
    if (err.name === 'AbortError') {
      out.remove();
    } else {
      out.className = 'msg error';
      out.textContent = err.friendly ? err.message : 'Network error — check your connection and try again.';
      // Keep the question so the user can retry: put it back in the box.
      messages.pop();
      input.value = content;
      autosize();
    }
  } finally {
    busy = false;
    controller = null;
    setEnabled(true);
    input.focus();
  }
}

form.addEventListener('submit', (e) => { e.preventDefault(); send(input.value); });
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(input.value); }
});
function autosize() {
  input.style.height = 'auto';
  input.style.height = `${Math.min(input.scrollHeight, 220)}px`;
}
input.addEventListener('input', autosize);

document.querySelectorAll('.starter').forEach((b) => b.addEventListener('click', () => send(b.textContent)));
document.getElementById('new-chat').addEventListener('click', () => {
  controller?.abort();
  messages = [];
  save();
  renderAll();
  if (!input.disabled) empty.hidden = false;
  input.focus();
});

/* ---------- Boot ---------- */
restore();
boot({ needAuth: true });
onChange((state) => {
  if (!TUTOR_ENABLED) {
    unconfigured.hidden = false;
    gate.hidden = true;
    setEnabled(false);
    return;
  }
  const signedIn = Boolean(state.user);
  gate.hidden = signedIn;
  setEnabled(signedIn);
  renderAll();
  empty.hidden = !signedIn || messages.length > 0;
  if (!signedIn) gate.querySelector('a').href = `${url('/login/')}?next=${encodeURIComponent('/tutor/' + location.search)}`;
});
