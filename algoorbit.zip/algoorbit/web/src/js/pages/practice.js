import { boot, celebrate, toast } from '../ui.js';
import { onChange, isDone, setDone } from '../store.js';

boot();

const rows = [...document.querySelectorAll('[data-row]')].map((el) => ({
  el, box: el.querySelector('input[data-item]'), diff: el.dataset.diff, name: el.dataset.name,
}));
const groups = [...document.querySelectorAll('[data-group]')];
const input = document.getElementById('sheet-q');
const empty = document.querySelector('[data-empty]');
const filters = { diff: '', status: '' };

for (const r of rows) {
  r.box.addEventListener('change', async () => {
    r.box.disabled = true;
    const result = await setDone(r.box.dataset.item, r.box.checked);
    r.box.disabled = false;
    if (!result.ok) {
      r.box.checked = !r.box.checked;
      toast("Couldn't save that change. Check your connection and try again.");
      return;
    }
    celebrate(result);
  });
}

function apply() {
  const words = input.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
  let shown = 0;
  for (const r of rows) {
    const done = r.box.checked;
    const ok = (!filters.diff || r.diff === filters.diff)
      && (!filters.status || (filters.status === 'done') === done)
      && words.every((w) => r.name.includes(w));
    r.el.hidden = !ok;
    if (ok) shown++;
  }
  for (const g of groups) {
    const list = [...g.querySelectorAll('[data-row]')];
    const solved = list.filter((el) => el.querySelector('input').checked).length;
    g.hidden = list.every((el) => el.hidden);
    g.querySelector('[data-group-count]').textContent = `${solved} of ${list.length} solved`;
  }
  empty.hidden = shown > 0;
}

document.querySelectorAll('[data-filter]').forEach((btn) => btn.addEventListener('click', () => {
  filters[btn.dataset.filter] = btn.dataset.value;
  document.querySelectorAll(`[data-filter="${btn.dataset.filter}"]`).forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
  apply();
}));
input.addEventListener('input', apply);
document.querySelector('[data-clear]').addEventListener('click', () => {
  input.value = '';
  for (const key of Object.keys(filters)) {
    filters[key] = '';
    document.querySelectorAll(`[data-filter="${key}"]`).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.value === '')));
  }
  apply();
});

onChange(() => {
  for (const r of rows) r.box.checked = isDone(r.box.dataset.item);
  const solved = rows.filter((r) => r.box.checked).length;
  document.querySelector('[data-solved]').textContent = solved;
  document.querySelector('[data-solved-meter]').style.width = `${(solved / rows.length) * 100}%`;
  apply();
});
