import { boot, url } from '../ui.js';
import { getClient, getState } from '../store.js';
import { AUTH_ENABLED, absolute } from '../config.js';
import { bindPasswordUI, bindStrength, authMessage, safeNext } from '../password.js';

const params = new URLSearchParams(location.search);
const next = safeNext(params.get('next'));
const form = document.getElementById('auth-form');
const msg = document.getElementById('auth-msg');
const submit = document.getElementById('auth-submit');
const email = document.getElementById('email');
const password = document.getElementById('password');
const nameInput = document.getElementById('name');
let tab = params.get('tab') === 'signup' ? 'signup' : 'signin';

function say(text, kind = '') {
  msg.hidden = !text;
  msg.textContent = text;
  msg.className = `notice ${kind}`;
}

function setTab(t) {
  tab = t;
  document.querySelectorAll('[data-tab]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === t)));
  document.querySelectorAll('[data-only]').forEach((el) => { el.hidden = el.dataset.only !== t; });
  submit.textContent = t === 'signup' ? 'Create account' : 'Sign in';
  password.autocomplete = t === 'signup' ? 'new-password' : 'current-password';
  say('');
}

document.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => setTab(b.dataset.tab)));
bindPasswordUI();
bindStrength(password, document.querySelector('.strength'));
setTab(tab);

function busy(on) {
  submit.disabled = on;
  submit.textContent = on ? 'Please wait…' : tab === 'signup' ? 'Create account' : 'Sign in';
}

const go = () => location.replace(url(next));

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  say('');
  const em = email.value.trim();
  const pw = password.value;
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) return say('Enter a valid email address.', 'err');
  if (pw.length < 8) return say('Passwords are at least 8 characters.', 'err');

  busy(true);
  const sb = await getClient();
  if (tab === 'signin') {
    const { error } = await sb.auth.signInWithPassword({ email: em, password: pw });
    busy(false);
    if (error) return say(authMessage(error), 'err');
    return go();
  }
  const { data, error } = await sb.auth.signUp({
    email: em,
    password: pw,
    options: {
      data: { display_name: nameInput.value.trim().slice(0, 40) || undefined },
      emailRedirectTo: absolute(`/login/?next=${encodeURIComponent(next)}`),
    },
  });
  busy(false);
  if (error) return say(authMessage(error), 'err');
  if (data.session) return go();
  form.reset();
  say(`Check ${em} for a confirmation link to finish creating your account. Your progress on this device will be added to it when you sign in.`, 'ok');
});

document.getElementById('google-btn').addEventListener('click', async () => {
  const sb = await getClient();
  const { error } = await sb.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: absolute(`/login/?next=${encodeURIComponent(next)}`) },
  });
  if (error) say(authMessage(error), 'err');
});

document.getElementById('forgot').addEventListener('click', async () => {
  const em = email.value.trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) {
    email.focus();
    return say('Type your email address above, then choose "Forgot your password?" again.', 'err');
  }
  const sb = await getClient();
  const { error } = await sb.auth.resetPasswordForEmail(em, { redirectTo: absolute('/reset/') });
  if (error) return say(authMessage(error), 'err');
  say(`If an account exists for ${em}, a reset link is on its way. Open it in this browser.`, 'ok');
});

/* ---------- Boot ---------- */
await boot({ needAuth: AUTH_ENABLED });
if (!AUTH_ENABLED) {
  document.getElementById('auth-unconfigured').hidden = false;
  document.getElementById('auth-ui').hidden = true;
} else {
  if (getState().user) go(); // already signed in, or just returned from Google / email confirmation
  const err = params.get('error_description');
  if (err) say(err, 'err');
}
