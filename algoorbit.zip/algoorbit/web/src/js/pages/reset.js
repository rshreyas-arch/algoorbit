import { boot, url } from '../ui.js';
import { getClient, getState } from '../store.js';
import { AUTH_ENABLED } from '../config.js';
import { bindPasswordUI, bindStrength, authMessage } from '../password.js';

const intro = document.getElementById('reset-intro');
const form = document.getElementById('reset-form');
const msg = document.getElementById('reset-msg');
const pw = document.getElementById('new-password');
const fallback = document.getElementById('reset-fallback');

bindPasswordUI();
bindStrength(pw, form.querySelector('.strength'));

const say = (text, kind) => { msg.hidden = !text; msg.textContent = text; msg.className = `notice ${kind}`; };

await boot({ needAuth: AUTH_ENABLED });

if (!AUTH_ENABLED || !getState().user) {
  intro.textContent = 'This reset link is invalid or has expired. Links work once, for a limited time, and only in the browser where you requested them.';
  fallback.hidden = false;
} else {
  intro.textContent = `Signed in as ${getState().user.email}. Enter a new password below.`;
  form.hidden = false;
  pw.focus();
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (pw.value.length < 8) return say('Use at least 8 characters.', 'err');
  const btn = form.querySelector('button[type=submit]');
  btn.disabled = true;
  const sb = await getClient();
  const { error } = await sb.auth.updateUser({ password: pw.value });
  btn.disabled = false;
  if (error) return say(authMessage(error), 'err');
  say('Password updated. Taking you to your roadmap…', 'ok');
  setTimeout(() => location.replace(url('/roadmap/')), 1400);
});
