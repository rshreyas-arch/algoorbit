import { boot } from '../ui.js';
import { onChange, topicProgress } from '../store.js';

boot();

onChange(() => {
  document.querySelectorAll('[data-topic-card]').forEach((card) => {
    const p = topicProgress(card.dataset.topicCard);
    card.querySelector('.meter i').style.width = `${p.pct}%`;
    const pct = card.querySelector('[data-pct]');
    pct.dataset.hours ??= pct.textContent;
    pct.textContent = p.status === 'done' ? 'Cleared' : p.pct ? `${p.pct}% done` : pct.dataset.hours;
    card.classList.toggle('done', p.status === 'done');
  });
});
