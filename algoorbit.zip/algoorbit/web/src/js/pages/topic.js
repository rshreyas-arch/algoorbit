import { boot, celebrate, toast, confetti } from '../ui.js';
import { onChange, isDone, setDone, topicProgress } from '../store.js';
import { quizItem } from '../data.js';

const article = document.querySelector('[data-topic]');
const topicId = article.dataset.topic;
const boxes = [...document.querySelectorAll('input[data-item]')];

boot();

/* ---------- Checklists ---------- */
for (const box of boxes) {
  box.addEventListener('change', async () => {
    box.disabled = true;
    const result = await setDone(box.dataset.item, box.checked);
    box.disabled = false;
    if (!result.ok) {
      box.checked = !box.checked;
      toast("Couldn't save that change. Check your connection and try again.");
      return;
    }
    celebrate(result);
    if (box.checked && result.before.perTopic.get(topicId).status !== 'done' && result.after.perTopic.get(topicId).status === 'done') {
      toast('Level cleared! It now shines gold on your map.', 'xp');
      confetti();
    }
  });
}

const ring = document.querySelector('[data-ring]');
const CIRC = 97.4;
onChange(() => {
  for (const box of boxes) box.checked = isDone(box.dataset.item);
  const p = topicProgress(topicId);
  document.querySelector('.sidebar [data-pct]').textContent = `${p.pct}%`;
  document.querySelector('[data-count]').textContent = `${p.done} of ${p.total} done`;
  ring.style.strokeDashoffset = String(CIRC * (1 - p.pct / 100));
  document.querySelector('[data-cleared]').hidden = p.status !== 'done';
});

/* ---------- Code tabs + copy ---------- */
document.querySelectorAll('[data-tabs]').forEach((box) => {
  const tabs = [...box.querySelectorAll('[role=tab]')];
  const show = (tab) => {
    for (const t of tabs) {
      const on = t === tab;
      t.setAttribute('aria-selected', String(on));
      t.tabIndex = on ? 0 : -1;
      document.getElementById(t.getAttribute('aria-controls')).hidden = !on;
    }
    try { localStorage.setItem('algoorbit:lang', tab.textContent); } catch { /* ignore */ }
  };
  tabs.forEach((t, i) => {
    t.addEventListener('click', () => show(t));
    t.addEventListener('keydown', (e) => {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      const next = tabs[(i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length];
      show(next);
      next.focus();
    });
  });
  let saved = null;
  try { saved = localStorage.getItem('algoorbit:lang'); } catch { /* ignore */ }
  const pref = tabs.find((t) => t.textContent === saved);
  if (pref) show(pref);

  box.querySelector('[data-copy]').addEventListener('click', async (e) => {
    const visible = box.querySelector('pre:not([hidden]) code');
    try {
      await navigator.clipboard.writeText(visible.textContent);
      e.target.textContent = 'Copied';
      setTimeout(() => { e.target.textContent = 'Copy'; }, 1600);
    } catch {
      toast('Copy failed — select the code and copy it manually.');
    }
  });
});

/* ---------- Quick check ---------- */
const quiz = document.querySelector('[data-quiz]');
if (quiz) {
  const item = quizItem(topicId);
  const questions = [...quiz.querySelectorAll('[data-q]')];
  const foot = quiz.querySelector('[data-quiz-foot]');
  const result = quiz.querySelector('[data-quiz-result]');
  const retry = quiz.querySelector('[data-quiz-retry]');
  let right = 0;
  let answered = 0;

  const reset = () => {
    right = 0; answered = 0;
    foot.hidden = true;
    for (const q of questions) {
      q.classList.remove('answered');
      q.querySelector('.q-why').hidden = true;
      q.querySelectorAll('.q-opt').forEach((b) => { b.disabled = false; b.classList.remove('right', 'wrong'); b.removeAttribute('aria-pressed'); });
    }
  };

  const finish = async () => {
    foot.hidden = false;
    if (right < questions.length) {
      result.textContent = `${right} of ${questions.length} right. Read the explanations, then try again for the XP.`;
      retry.hidden = false;
      return;
    }
    retry.hidden = true;
    if (isDone(item)) { result.textContent = 'All three right again. Nicely done.'; return; }
    const saved = await setDone(item, true);
    if (!saved.ok) { result.textContent = "All three right, but the XP couldn't be saved. Check your connection and try again."; retry.hidden = false; return; }
    result.textContent = 'All three right.';
    celebrate(saved);
  };

  for (const q of questions) {
    q.querySelectorAll('.q-opt').forEach((btn) => btn.addEventListener('click', () => {
      if (q.classList.contains('answered')) return;
      q.classList.add('answered');
      const ok = btn.dataset.ok === '1';
      btn.setAttribute('aria-pressed', 'true');
      btn.classList.add(ok ? 'right' : 'wrong');
      q.querySelectorAll('.q-opt').forEach((b) => { if (b.dataset.ok === '1') b.classList.add('right'); b.disabled = true; });
      const why = q.querySelector('.q-why');
      why.hidden = false;
      why.dataset.verdict = ok ? 'Correct.' : 'Not quite.';
      answered++;
      if (ok) right++;
      if (answered === questions.length) finish();
    }));
  }
  retry.addEventListener('click', () => { reset(); questions[0].querySelector('.q-opt').focus(); });
  onChange(() => { quiz.querySelector('[data-quiz-cleared]').hidden = !isDone(item); });
}

/* ---------- Table of contents: highlight the section being read ---------- */
{
  const links = new Map([...document.querySelectorAll('.toc a')].map((a) => [a.getAttribute('href').slice(1), a]));
  const sections = [...links.keys()].map((id) => document.getElementById(id)).filter(Boolean);
  if (sections.length && 'IntersectionObserver' in window) {
    const visible = new Set();
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) e.isIntersecting ? visible.add(e.target.id) : visible.delete(e.target.id);
      const current = sections.find((s) => visible.has(s.id));
      if (!current) return;
      links.forEach((a, id) => a.classList.toggle('active', id === current.id));
    }, { rootMargin: '-20% 0px -60% 0px' });
    sections.forEach((s) => io.observe(s));
  }
}
