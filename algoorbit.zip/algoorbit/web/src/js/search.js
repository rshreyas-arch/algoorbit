// Site search: a dialog over an index built at generate time (levels, concepts, patterns, problems).
// Loaded on demand the first time someone opens search, so it costs nothing on page load.
import index from '../generated/search.json';
import { url } from './config.js';

const KIND_RANK = { Level: 0, Pattern: 1, Concept: 2, Problem: 3 };
const rows = index.map(([kind, label, detail, path]) => ({ kind, label, detail, path, hay: `${label} ${detail}`.toLowerCase(), low: label.toLowerCase() }));
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function find(query) {
  const words = query.toLowerCase().split(/\s+/).filter(Boolean);
  if (!words.length) return rows.filter((r) => r.kind === 'Level').slice(0, 8);
  const scored = [];
  for (const r of rows) {
    if (!words.every((w) => r.hay.includes(w))) continue;
    const first = words[0];
    const score = (r.low.startsWith(first) ? 0 : new RegExp(`\\b${first.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`).test(r.low) ? 1 : r.low.includes(first) ? 2 : 3) * 10 + KIND_RANK[r.kind];
    scored.push([score, r]);
  }
  return scored.sort((a, b) => a[0] - b[0] || a[1].label.length - b[1].label.length).slice(0, 12).map(([, r]) => r);
}

let dialog;
let input;
let list;
let hits = [];
let active = 0;

function render() {
  hits = find(input.value);
  active = 0;
  list.innerHTML = hits.length
    ? hits.map((r, i) => `<li role="option" id="s-opt-${i}" aria-selected="${i === 0}"><a href="${esc(url(r.path))}" tabindex="-1"><span class="s-kind ${r.kind}">${r.kind}</span><span class="s-label">${esc(r.label)}</span><span class="s-detail">${esc(r.detail)}</span></a></li>`).join('')
    : `<li class="s-none">Nothing matches "${esc(input.value.trim())}". Try a topic such as "binary search" or a problem name.</li>`;
  input.setAttribute('aria-activedescendant', hits.length ? 's-opt-0' : '');
}

function move(step) {
  if (!hits.length) return;
  active = (active + step + hits.length) % hits.length;
  [...list.children].forEach((li, i) => li.setAttribute('aria-selected', String(i === active)));
  list.children[active].scrollIntoView({ block: 'nearest' });
  input.setAttribute('aria-activedescendant', `s-opt-${active}`);
}

function build() {
  dialog = document.createElement('dialog');
  dialog.className = 'search-dialog';
  dialog.setAttribute('aria-label', 'Search');
  dialog.innerHTML = `<div class="s-head"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>
    <input type="search" role="combobox" aria-expanded="true" aria-controls="s-list" aria-autocomplete="list" aria-label="Search levels, concepts, patterns and problems" placeholder="Search levels, concepts, problems" autocomplete="off" spellcheck="false">
    <button type="button" class="s-close" aria-label="Close search">Esc</button></div>
    <ul id="s-list" role="listbox" aria-label="Results"></ul>`;
  document.body.appendChild(dialog);
  input = dialog.querySelector('input');
  list = dialog.querySelector('ul');
  input.addEventListener('input', render);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
    else if (e.key === 'Enter' && hits[active]) { e.preventDefault(); location.href = url(hits[active].path); dialog.close(); }
  });
  dialog.querySelector('.s-close').addEventListener('click', () => dialog.close());
  // A click on the backdrop (the dialog element itself) closes it.
  dialog.addEventListener('click', (e) => { if (e.target === dialog) dialog.close(); });
  // Same-page results (#anchors) should close the dialog too.
  list.addEventListener('click', (e) => { if (e.target.closest('a')) dialog.close(); });
}

export function openSearch() {
  if (!dialog) build();
  if (dialog.open) return;
  input.value = '';
  render();
  dialog.showModal();
  input.focus();
}
