export const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || '';
export const SUPABASE_KEY =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || import.meta.env.VITE_SUPABASE_ANON_KEY || '';

/** Accounts work only when the Supabase project is configured at build time. */
export const AUTH_ENABLED = Boolean(SUPABASE_URL && SUPABASE_KEY);
/** The tutor also needs the server-side API; it can be switched off at build time. */
export const TUTOR_ENABLED = AUTH_ENABLED && import.meta.env.VITE_TUTOR_ENABLED !== 'false';

const html = document.documentElement;
const ROOT = html.dataset.root || '/';
const PREVIEW = html.dataset.preview === '1';

/** Internal link that works both on a real host (clean URLs) and in static preview builds. */
export function url(path) {
  if (!PREVIEW) return path;
  const [p, rest = ''] = path.split(/(?=[?#])/);
  let rel = ROOT + p.replace(/^\//, '');
  if (rel.endsWith('/')) rel += 'index.html';
  return rel + rest;
}

/** Absolute URL on this origin — used for auth redirects. */
export function absolute(path) {
  return new URL(url(path), location.href).href;
}
