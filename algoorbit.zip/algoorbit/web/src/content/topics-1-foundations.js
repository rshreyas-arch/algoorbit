export default [
  {
    id: 'complexity',
    orbit: 'foundations',
    title: 'Complexity Analysis (Big-O)',
    short: 'Big-O',
    prereqs: [],
    hours: 3,
    summary: 'Learn to predict how fast code runs and how much memory it needs before you write it — the skill that decides which algorithm to pick.',
    intro: [
      'Every DSA problem is really two problems: get a correct answer, and get it fast enough. Big-O notation is the language for the second part. It describes how the running time or memory of an algorithm grows as the input grows, ignoring machine speed and constant factors. An O(n) algorithm that takes one second on 10 million items will take about two seconds on 20 million; an O(n²) one will take four times as long.',
      'In practice, complexity analysis is how you read a problem\'s constraints. Online judges run roughly 10⁸ simple operations per second, so when a problem says n ≤ 10⁵, an O(n²) solution (10¹⁰ operations) will time out while O(n log n) passes comfortably. Learning to do this estimate in your head before coding saves more time than any other single habit.',
    ],
    concepts: [
      ['Big-O, Big-Ω and Big-Θ', 'O is an upper bound, Ω a lower bound and Θ a tight bound. When interviewers say "Big-O" they almost always mean the tight worst-case bound.'],
      ['Drop constants and lower-order terms', 'O(3n² + 5n + 20) simplifies to O(n²). Only the fastest-growing term matters once n is large.'],
      ['The common growth classes', 'O(1) < O(log n) < O(n) < O(n log n) < O(n²) < O(2ⁿ) < O(n!). Memorise the order and a rough feel for each.'],
      ['Space complexity', 'Count the extra memory you allocate, including the recursion call stack. A recursive DFS on a path of n nodes uses O(n) stack space.'],
      ['Amortised cost', 'Some operations are occasionally expensive but cheap on average. Appending to a dynamic array is O(1) amortised even though a resize copies everything.'],
      ['Reading constraints', 'Map the input limit to a target complexity before you design anything (see the table below).'],
    ],
    complexityTitle: 'Constraint → target complexity (≈10⁸ ops/sec)',
    complexity: [
      ['n ≤ 10', 'O(n!) — try every permutation'],
      ['n ≤ 20', 'O(2ⁿ · n) — subsets / bitmask'],
      ['n ≤ 500', 'O(n³)'],
      ['n ≤ 5,000', 'O(n²)'],
      ['n ≤ 10⁶', 'O(n log n) or O(n)'],
      ['n ≤ 10¹⁸', 'O(log n) or O(1) — maths or binary search'],
    ],
    patterns: [
      ['Count the loops', 'Nested loops multiply, sequential loops add.', 'A loop inside a loop over the same array is O(n²); two separate passes are O(2n) = O(n).'],
      ['Halving means log n', 'Any loop that cuts the problem in half each step.', 'Binary search, repeated division by 2 and balanced-tree height all give O(log n).'],
      ['Recurrences', 'Recursive divide-and-conquer code.', 'T(n) = 2T(n/2) + O(n) solves to O(n log n) (merge sort). T(n) = T(n/2) + O(1) is O(log n).'],
    ],
    code: {
      label: 'Same task, two complexities',
      python: `def has_duplicate_slow(nums):        # O(n^2) time, O(1) space
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[i] == nums[j]:
                return True
    return False


def has_duplicate_fast(nums):        # O(n) time, O(n) space
    seen = set()
    for x in nums:
        if x in seen:
            return True
        seen.add(x)
    return False`,
      cpp: `bool hasDuplicateSlow(const vector<int>& nums) {   // O(n^2) time, O(1) space
    for (size_t i = 0; i < nums.size(); ++i)
        for (size_t j = i + 1; j < nums.size(); ++j)
            if (nums[i] == nums[j]) return true;
    return false;
}

bool hasDuplicateFast(const vector<int>& nums) {   // O(n) time, O(n) space
    unordered_set<int> seen;
    for (int x : nums) {
        if (seen.count(x)) return true;
        seen.insert(x);
    }
    return false;
}`,
    },
    pitfalls: [
      'Hidden linear costs: <code>x in list</code>, <code>list.pop(0)</code>, slicing and string concatenation in a loop are all O(n) per call.',
      'Forgetting the recursion stack when stating space complexity.',
      'Hash map operations are O(1) on average but O(n) in the worst case — mention it if asked.',
      'Trading time for space is the most common optimisation: the fast version above uses O(n) memory to save a factor of n in time.',
    ],
    problems: [
      ['contains-duplicate', 'Contains Duplicate', 'E'],
      ['missing-number', 'Missing Number', 'E'],
      ['squares-of-a-sorted-array', 'Squares of a Sorted Array', 'E'],
      ['majority-element', 'Majority Element', 'E'],
    ],
  },
  {
    id: 'math-basics',
    orbit: 'foundations',
    title: 'Math for DSA',
    short: 'Math',
    prereqs: ['complexity'],
    hours: 4,
    summary: 'GCD, primes, modular arithmetic and fast exponentiation — the small toolkit that appears in placement tests and contest problems again and again.',
    intro: [
      'You do not need advanced mathematics for most DSA, but a handful of number-theory tools show up constantly: computing a greatest common divisor, listing primes, working "modulo 10⁹+7" so numbers don\'t overflow, and raising numbers to huge powers quickly. Aptitude-style coding rounds in campus placements lean heavily on exactly these.',
      'The common thread is efficiency. Checking primality by trial division up to n is O(n); up to √n it is O(√n); the Sieve of Eratosthenes finds every prime up to n in O(n log log n). Recognising which tool fits turns a timeout into an instant answer.',
    ],
    concepts: [
      ['Euclid\'s GCD', 'gcd(a, b) = gcd(b, a mod b), ending when b is 0. It runs in O(log min(a, b)). lcm(a, b) = a / gcd(a, b) × b (divide first to avoid overflow).'],
      ['Primality up to √n', 'If n has a factor larger than √n it must also have one smaller, so trial division only needs to go to √n.'],
      ['Sieve of Eratosthenes', 'Cross out multiples of each prime starting from p². Produces all primes up to n in O(n log log n).'],
      ['Modular arithmetic', '(a + b) mod m and (a × b) mod m can be reduced at every step. Problems use m = 10⁹+7 because it is prime and products of two residues fit in 64 bits.'],
      ['Fast exponentiation', 'Square the base and halve the exponent: computes aᵇ mod m in O(log b) instead of O(b).'],
      ['Integer overflow', 'In C++/Java a 32-bit int overflows past about 2.1 × 10⁹. Use long long / long for sums and products.'],
    ],
    complexity: [
      ['gcd(a, b)', 'O(log min(a, b))'],
      ['Primality by trial division', 'O(√n)'],
      ['Sieve up to n', 'O(n log log n) time, O(n) space'],
      ['Fast power aᵇ mod m', 'O(log b)'],
    ],
    patterns: [
      ['Reduce modulo at every step', 'Answers "modulo 10⁹+7".', 'Apply % after every addition and multiplication, not only at the end, or intermediate values overflow.'],
      ['Precompute with a sieve', 'Many primality queries on numbers up to ~10⁷.', 'Build the sieve once, then answer each query in O(1).'],
      ['Count factors, not products', 'Trailing zeros, divisibility of factorials.', 'Trailing zeros of n! = number of factors of 5 in 1..n, because factors of 2 are always more plentiful.'],
    ],
    code: {
      label: 'GCD, sieve and modular fast power',
      python: `MOD = 10**9 + 7


def gcd(a, b):
    while b:
        a, b = b, a % b
    return a


def sieve(n):                       # all primes <= n
    if n < 2:
        return []
    is_prime = [True] * (n + 1)
    is_prime[0] = is_prime[1] = False
    for p in range(2, int(n ** 0.5) + 1):
        if is_prime[p]:
            for multiple in range(p * p, n + 1, p):
                is_prime[multiple] = False
    return [i for i, ok in enumerate(is_prime) if ok]


def mod_pow(base, exp, mod=MOD):    # O(log exp)
    result, base = 1, base % mod
    while exp > 0:
        if exp & 1:
            result = result * base % mod
        base = base * base % mod
        exp >>= 1
    return result`,
      cpp: `const long long MOD = 1'000'000'007LL;

long long gcdLL(long long a, long long b) {
    while (b) { long long t = a % b; a = b; b = t; }
    return a;
}

vector<int> sieve(int n) {               // all primes <= n
    vector<int> primes;
    if (n < 2) return primes;
    vector<bool> isPrime(n + 1, true);
    isPrime[0] = isPrime[1] = false;
    for (long long p = 2; p * p <= n; ++p)
        if (isPrime[p])
            for (long long m = p * p; m <= n; m += p) isPrime[m] = false;
    for (int i = 2; i <= n; ++i) if (isPrime[i]) primes.push_back(i);
    return primes;
}

long long modPow(long long base, long long exp, long long mod = MOD) {
    long long result = 1;
    base %= mod;
    while (exp > 0) {
        if (exp & 1) result = result * base % mod;
        base = base * base % mod;
        exp >>= 1;
    }
    return result;
}`,
    },
    pitfalls: [
      'Computing a × b before reducing when both are near 10⁹ overflows a 32-bit int — cast to 64-bit first.',
      'In Python, negative numbers with % return a non-negative result; in C++/Java they can be negative. Add mod before taking % again.',
      'Floating-point sqrt can be off by one for large n; prefer <code>p * p &lt;= n</code> loops.',
    ],
    problems: [
      ['fizz-buzz', 'Fizz Buzz', 'E'],
      ['palindrome-number', 'Palindrome Number', 'E'],
      ['greatest-common-divisor-of-strings', 'Greatest Common Divisor of Strings', 'E'],
      ['count-primes', 'Count Primes', 'M'],
      ['factorial-trailing-zeroes', 'Factorial Trailing Zeroes', 'M'],
      ['super-pow', 'Super Pow', 'M'],
    ],
  },
  {
    id: 'arrays',
    orbit: 'foundations',
    title: 'Arrays',
    short: 'Arrays',
    prereqs: ['complexity'],
    hours: 5,
    summary: 'The most important data structure in interviews: constant-time indexing, in-place tricks, matrices and Kadane\'s algorithm.',
    intro: [
      'An array stores elements in one contiguous block of memory, so the address of element i is simply start + i × size. That arithmetic is why indexing is O(1) and why arrays are cache-friendly and fast in practice. The cost is rigidity: inserting or deleting in the middle shifts every element after it, which is O(n).',
      'Most array problems are not about the array itself but about traversing it cleverly — keeping a running best, overwriting in place with a second index, or noticing that a matrix is just an array of arrays. Master the handful of moves below and a large share of "Easy" and "Medium" problems become routine.',
    ],
    concepts: [
      ['Contiguous memory and O(1) access', 'Index arithmetic gives constant-time reads and writes; scanning is O(n).'],
      ['Static vs dynamic arrays', 'Python lists, C++ vectors and Java ArrayLists double their capacity when full, making append O(1) amortised.'],
      ['In-place modification', 'Use a write index that trails the read index to filter or compact an array without extra memory.'],
      ['Matrices', 'A 2D array is rows of arrays. Practise row-major traversal, transposing, and walking boundaries (spiral order).'],
      ['Reverse-to-rotate', 'Rotating right by k = reverse all, reverse first k, reverse the rest — O(n) time, O(1) space.'],
      ['Kadane\'s algorithm', 'Maximum subarray sum in one pass: at each element either extend the current subarray or start fresh.'],
    ],
    complexity: [
      ['Access by index', 'O(1)'],
      ['Search (unsorted)', 'O(n)'],
      ['Append at end', 'O(1) amortised'],
      ['Insert / delete in the middle', 'O(n)'],
      ['Copy or slice of length k', 'O(k)'],
    ],
    patterns: [
      ['Running best', 'Max profit, max subarray, running minimum.', 'Track the best answer so far and the best "state" ending at the current index in one pass.'],
      ['Write pointer', 'Remove elements, move zeroes, deduplicate.', 'Read every element; copy the keepers to position w and increment w.'],
      ['Index as hash', 'Values are in the range 1..n.', 'Use the sign or position of nums[v − 1] to mark that v was seen — O(1) extra space (first missing positive).'],
    ],
    code: {
      label: 'Kadane\'s algorithm — maximum subarray sum',
      python: `def max_subarray(nums):
    best = current = nums[0]
    for x in nums[1:]:
        current = max(x, current + x)   # extend or restart
        best = max(best, current)
    return best`,
      cpp: `int maxSubArray(const vector<int>& nums) {
    int best = nums[0], current = nums[0];
    for (size_t i = 1; i < nums.size(); ++i) {
        current = max(nums[i], current + nums[i]);   // extend or restart
        best = max(best, current);
    }
    return best;
}`,
    },
    pitfalls: [
      'Off-by-one errors on loop bounds — test with arrays of length 0, 1 and 2.',
      'Removing items from a list while iterating over it skips elements; iterate over a copy or use a write pointer.',
      'Sums of large arrays overflow 32-bit integers.',
      'Python slicing (<code>a[1:]</code>) copies the data — fine for clarity, but it costs O(n) memory.',
    ],
    problems: [
      ['best-time-to-buy-and-sell-stock', 'Best Time to Buy and Sell Stock', 'E'],
      ['move-zeroes', 'Move Zeroes', 'E'],
      ['maximum-subarray', 'Maximum Subarray', 'M'],
      ['rotate-array', 'Rotate Array', 'M'],
      ['spiral-matrix', 'Spiral Matrix', 'M'],
      ['set-matrix-zeroes', 'Set Matrix Zeroes', 'M'],
      ['first-missing-positive', 'First Missing Positive', 'H'],
    ],
  },
  {
    id: 'strings',
    orbit: 'foundations',
    title: 'Strings',
    short: 'Strings',
    prereqs: ['arrays'],
    hours: 5,
    summary: 'Character arrays with their own traps: immutability, counting, palindromes and efficient pattern matching.',
    intro: [
      'A string is an array of characters, so everything from the Arrays topic applies — but strings bring their own habits. In Python and Java they are immutable, so building one character at a time with + quietly turns an O(n) loop into O(n²). The fix is to collect pieces in a list or StringBuilder and join once.',
      'Interview string problems cluster into a few families: counting characters (anagrams), checking symmetry (palindromes), comparing prefixes, and searching for a pattern inside a text. Each family has a standard technique, and recognising the family is most of the work.',
    ],
    concepts: [
      ['Immutability and builders', 'Use list + "".join() in Python or StringBuilder in Java when constructing strings in a loop.'],
      ['Frequency counting', 'For lowercase letters an int[26] beats a hash map: count[c − \'a\']++.'],
      ['Substring vs subsequence', 'A substring is contiguous; a subsequence keeps order but can skip characters. Mixing them up changes the whole algorithm.'],
      ['Palindromes', 'Check with two pointers from both ends, or find them by expanding around each centre (odd and even lengths).'],
      ['Character encoding', 'Characters are small integers (ASCII/Unicode). Comparisons and arithmetic like c − \'0\' rely on this.'],
      ['Pattern matching', 'Naive search is O(n·m). KMP precomputes a prefix function to search in O(n + m); Rabin–Karp uses a rolling hash.'],
    ],
    complexity: [
      ['Index a character', 'O(1)'],
      ['Concatenate a + b', 'O(len a + len b)'],
      ['Compare two strings', 'O(n)'],
      ['Naive substring search', 'O(n · m)'],
      ['KMP search', 'O(n + m)'],
    ],
    patterns: [
      ['Count and compare', 'Anagrams, permutations, ransom-note style questions.', 'Build frequency arrays and compare them, or increment for one string and decrement for the other.'],
      ['Expand around centre', 'Longest palindromic substring, counting palindromes.', 'Treat each index (and each gap) as a centre and expand while characters match — O(n²) time, O(1) space.'],
      ['Canonical key', 'Group strings that are "the same" under some transformation.', 'Map each string to a key (sorted letters, count tuple) and group by key in a hash map.'],
    ],
    code: {
      label: 'Longest palindromic substring — expand around centre',
      python: `def longest_palindrome(s):
    start, end = 0, 0

    def expand(left, right):
        while left >= 0 and right < len(s) and s[left] == s[right]:
            left -= 1
            right += 1
        return left + 1, right - 1

    for i in range(len(s)):
        for lo, hi in (expand(i, i), expand(i, i + 1)):
            if hi - lo > end - start:
                start, end = lo, hi
    return s[start:end + 1]`,
      cpp: `string longestPalindrome(const string& s) {
    int n = s.size(), start = 0, best = n ? 1 : 0;
    auto expand = [&](int l, int r) {
        while (l >= 0 && r < n && s[l] == s[r]) { --l; ++r; }
        if (r - l - 1 > best) { best = r - l - 1; start = l + 1; }
    };
    for (int i = 0; i < n; ++i) { expand(i, i); expand(i, i + 1); }
    return s.substr(start, best);
}`,
    },
    pitfalls: [
      'Repeated <code>s += c</code> in a loop is O(n²) in languages with immutable strings.',
      'Read the problem for case sensitivity and whether to ignore spaces or punctuation.',
      'Python slices exclude the end index; C++ <code>substr(pos, len)</code> takes a length, not an end.',
    ],
    problems: [
      ['valid-anagram', 'Valid Anagram', 'E'],
      ['valid-palindrome', 'Valid Palindrome', 'E'],
      ['longest-common-prefix', 'Longest Common Prefix', 'E'],
      ['find-the-index-of-the-first-occurrence-in-a-string', 'Find the Index of the First Occurrence in a String', 'E'],
      ['group-anagrams', 'Group Anagrams', 'M'],
      ['longest-palindromic-substring', 'Longest Palindromic Substring', 'M'],
      ['string-to-integer-atoi', 'String to Integer (atoi)', 'M'],
      ['shortest-palindrome', 'Shortest Palindrome', 'H'],
    ],
  },
  {
    id: 'hashing',
    orbit: 'foundations',
    title: 'Hash Maps & Sets',
    short: 'Hashing',
    prereqs: ['arrays'],
    hours: 4,
    summary: 'Constant-time lookup is the single most useful optimisation in DSA. Learn how hash tables work and the patterns that use them.',
    intro: [
      'A hash table turns a key into an array index with a hash function, giving average O(1) insert, delete and lookup. Whenever a brute-force solution asks "have I seen something like this before?" inside a loop, a hash map or set can usually remove that inner loop entirely.',
      'Two keys can hash to the same slot (a collision). Real implementations handle this with chaining or open addressing and resize as they fill, which keeps the average cost constant. The worst case is still O(n), which matters in competitive programming where adversarial tests target std::unordered_map.',
    ],
    concepts: [
      ['Hash function and buckets', 'A key is hashed to an index; collisions are resolved by chaining or probing; the table resizes to keep the load factor low.'],
      ['Set vs map', 'A set answers "is x present?"; a map stores a value per key — counts, indices or grouped lists.'],
      ['Frequency counting', 'Counter / unordered_map<int,int> to count occurrences in one pass.'],
      ['Composite keys', 'Use tuples, sorted strings or encoded strings as keys when the identity of an item has several parts.'],
      ['Ordered maps', 'TreeMap / std::map keep keys sorted with O(log n) operations — use them when you need floor, ceiling or ordered iteration.'],
      ['Designing with hashing', 'Combine a hash map with another structure (a doubly linked list for LRU cache, an array for O(1) random pick).'],
    ],
    complexity: [
      ['Insert / lookup / delete', 'O(1) average, O(n) worst'],
      ['Iterate all entries', 'O(n)'],
      ['std::map / TreeMap operations', 'O(log n)'],
    ],
    patterns: [
      ['Complement lookup', 'Find two items that combine to a target.', 'For each x, check whether target − x is already in the map, then insert x.'],
      ['Seen set', 'Duplicates, cycles in sequences (happy number), first unique element.', 'Insert as you go and stop the moment an item repeats.'],
      ['Grouping', 'Bucket items that share a property.', 'map[key].append(item) — then read the groups.'],
    ],
    code: {
      label: 'Two Sum — complement lookup in one pass',
      python: `def two_sum(nums, target):
    index_of = {}
    for i, x in enumerate(nums):
        if target - x in index_of:
            return [index_of[target - x], i]
        index_of[x] = i            # insert after checking
    return []`,
      cpp: `vector<int> twoSum(const vector<int>& nums, int target) {
    unordered_map<int, int> indexOf;
    for (int i = 0; i < (int)nums.size(); ++i) {
        auto it = indexOf.find(target - nums[i]);
        if (it != indexOf.end()) return {it->second, i};
        indexOf[nums[i]] = i;      // insert after checking
    }
    return {};
}`,
    },
    pitfalls: [
      'Inserting before checking lets an element pair with itself.',
      'Python lists are unhashable — convert to a tuple before using them as keys.',
      'In C++, <code>map[key]</code> silently inserts a default value; use <code>find</code> or <code>count</code> to test membership.',
      'Never mutate a map while iterating over it.',
    ],
    problems: [
      ['two-sum', 'Two Sum', 'E'],
      ['ransom-note', 'Ransom Note', 'E'],
      ['isomorphic-strings', 'Isomorphic Strings', 'E'],
      ['happy-number', 'Happy Number', 'E'],
      ['longest-consecutive-sequence', 'Longest Consecutive Sequence', 'M'],
      ['top-k-frequent-elements', 'Top K Frequent Elements', 'M'],
      ['insert-delete-getrandom-o1', 'Insert Delete GetRandom O(1)', 'M'],
      ['lru-cache', 'LRU Cache', 'M'],
    ],
  },
  {
    id: 'recursion',
    orbit: 'foundations',
    title: 'Recursion',
    short: 'Recursion',
    prereqs: ['complexity'],
    hours: 5,
    summary: 'Solve a problem by solving smaller copies of it. Recursion is the gateway to trees, backtracking, divide-and-conquer and DP.',
    intro: [
      'A recursive function calls itself on a smaller input until it reaches a case simple enough to answer directly. Writing one well comes down to a single act of trust: assume the call on the smaller input already works, and only worry about combining its result with the current step. Programmers call this the "leap of faith".',
      'Recursion is not just a coding style — it is how trees, graphs, backtracking and dynamic programming are naturally expressed. The cost model is the recursion tree: the total work is the sum over every call, and the extra space is the depth of the call stack.',
    ],
    concepts: [
      ['Base case and recursive case', 'Every recursive function needs at least one input it answers without recursing, and every call must move toward it.'],
      ['The call stack', 'Each active call keeps its own variables on the stack. Depth n means O(n) space and, for very deep inputs, stack overflow.'],
      ['Recursion trees', 'Draw the calls as a tree to count total work: n levels with 2 children each is O(2ⁿ).'],
      ['Divide and conquer', 'Split the input, solve the parts recursively, combine — merge sort and fast exponentiation are classic examples.'],
      ['Memoisation', 'Cache results of calls with the same arguments. Naive Fibonacci drops from O(2ⁿ) to O(n).'],
      ['Language limits', 'Python\'s default recursion limit is about 1000 and it has no tail-call optimisation; convert very deep recursions to loops.'],
    ],
    complexity: [
      ['Linear recursion (factorial, list sum)', 'O(n) time, O(n) stack'],
      ['Halving recursion (fast power)', 'O(log n)'],
      ['Merge sort', 'O(n log n)'],
      ['Naive Fibonacci', 'O(2ⁿ) — O(n) with memoisation'],
    ],
    patterns: [
      ['Leap of faith', 'Any problem defined in terms of smaller versions of itself.', 'Define what f(n) returns, handle the base case, express f(n) using f(smaller).'],
      ['Halve the input', 'Powers, binary search, divide and conquer.', 'Recurse on half the problem and combine in O(1) or O(n).'],
      ['Recurse on choices', 'Generating combinations, expression evaluation.', 'Each call branches on a decision; this grows into backtracking later in the roadmap.'],
    ],
    code: {
      label: 'Fast exponentiation — x to the power n in O(log n)',
      python: `def power(x, n):
    if n == 0:
        return 1.0
    if n < 0:
        return 1 / power(x, -n)
    half = power(x, n // 2)          # trust the smaller call
    return half * half if n % 2 == 0 else half * half * x`,
      cpp: `double power(double x, long long n) {
    if (n == 0) return 1.0;
    if (n < 0) return 1.0 / power(x, -n);
    double half = power(x, n / 2);      // trust the smaller call
    return (n % 2 == 0) ? half * half : half * half * x;
}`,
    },
    pitfalls: [
      'A missing or unreachable base case causes infinite recursion and a stack overflow.',
      'Calling the function twice on the same input (power(x, n/2) * power(x, n/2)) silently makes the algorithm exponential.',
      'Negating INT_MIN overflows in C++/Java — widen to long long first.',
      'Shared mutable state (a global list) must be restored after each call, or results leak between branches.',
    ],
    problems: [
      ['fibonacci-number', 'Fibonacci Number', 'E'],
      ['reverse-string', 'Reverse String', 'E'],
      ['power-of-three', 'Power of Three', 'E'],
      ['powx-n', 'Pow(x, n)', 'M'],
      ['k-th-symbol-in-grammar', 'K-th Symbol in Grammar', 'M'],
      ['different-ways-to-add-parentheses', 'Different Ways to Add Parentheses', 'M'],
    ],
  },
];
