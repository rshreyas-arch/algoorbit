// The roadmap is six "worlds" — floating islands on the 3D map, climbed in order.
// Each world has a biome: `color` is its grass on the map, `ui` the readable shade
// used for text and icons, `tint` the pale background it gets in the interface.
// Topic prerequisites inside each world are declared on the topics themselves.
export const ORBITS = [
  {
    id: 'foundations',
    n: 1,
    title: 'Foundations',
    biome: 'Meadow',
    color: '#b5cf8e',
    ui: '#4a6b2c',
    tint: '#eef3e6',
    blurb: 'How to reason about cost, plus the three structures every other topic is built on: arrays, strings and hash maps.',
  },
  {
    id: 'patterns',
    n: 2,
    title: 'Core Patterns',
    biome: 'Lagoon',
    color: '#93cbbf',
    ui: '#24685f',
    tint: '#e5f1ee',
    blurb: 'Reusable techniques — two pointers, windows, prefix sums, binary search — that turn O(n²) brute force into O(n) or O(n log n).',
  },
  {
    id: 'linear',
    n: 3,
    title: 'Linear Structures',
    biome: 'Lavender',
    color: '#bdb0dd',
    ui: '#5a4d99',
    tint: '#efecf7',
    blurb: 'Linked lists, stacks and queues: pointer manipulation and the monotonic tricks behind many "next greater" problems.',
  },
  {
    id: 'trees',
    n: 4,
    title: 'Trees & Heaps',
    biome: 'Pinewood',
    color: '#8db58f',
    ui: '#356140',
    tint: '#e7f0e8',
    blurb: 'Hierarchical data: traversals, binary search trees, priority queues and prefix trees.',
  },
  {
    id: 'graphs',
    n: 5,
    title: 'Graphs',
    biome: 'Crystal',
    color: '#a8b9e0',
    ui: '#3d5293',
    tint: '#eaeef8',
    blurb: 'Model anything with nodes and edges: traversal, dependency ordering, connectivity and shortest paths.',
  },
  {
    id: 'mastery',
    n: 6,
    title: 'Mastery',
    biome: 'Ember Peak',
    color: '#e8b196',
    ui: '#97471f',
    tint: '#f8ece5',
    blurb: 'Search and optimisation: backtracking, greedy proofs, dynamic programming, bit tricks and range-query trees.',
  },
];

export const XP = { concept: 10, quiz: 15, E: 20, M: 40, H: 70 };

export const LEVELS = [
  { at: 0, name: 'Cadet' },
  { at: 300, name: 'Navigator' },
  { at: 900, name: 'Pilot' },
  { at: 2000, name: 'Commander' },
  { at: 3800, name: 'Astronaut' },
  { at: 6000, name: 'Orbit Master' },
];
