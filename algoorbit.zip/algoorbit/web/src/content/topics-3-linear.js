export default [
  {
    id: 'linked-lists',
    orbit: 'linear',
    title: 'Linked Lists',
    short: 'Linked Lists',
    prereqs: ['two-pointers', 'recursion'],
    hours: 5,
    summary: 'Nodes joined by pointers. Linked-list problems are really exercises in careful pointer rewiring — dummy heads, reversal and fast/slow pointers.',
    intro: [
      'A linked list stores each element in its own node with a pointer to the next node. There is no index arithmetic, so reaching the k-th element takes O(k) steps — but inserting or removing a node you already hold is O(1), because only a couple of pointers change. Doubly linked lists add a pointer back to the previous node, which is what makes structures like an LRU cache possible.',
      'Interviewers like linked lists because they reveal how carefully you handle state. Almost every problem reduces to three moves: use a dummy node so the head is not a special case, save next before you overwrite it, and use two pointers moving at different speeds to find middles and cycles.',
    ],
    concepts: [
      ['Nodes and pointers', 'Each node holds a value and a reference to the next node; the list is just a reference to the head.'],
      ['Dummy (sentinel) head', 'A fake node before the head means insertions and deletions at the front need no special case.'],
      ['Iterative reversal', 'Walk the list with prev, curr and next pointers, flipping one arrow at a time — O(n) time, O(1) space.'],
      ['Fast and slow pointers', 'Fast moves two steps, slow moves one. Slow lands on the middle; if they ever meet, there is a cycle (Floyd\'s algorithm).'],
      ['Merging sorted lists', 'Repeatedly attach the smaller head to a tail pointer — the basis of merge sort on lists.'],
      ['Doubly linked lists', 'Prev and next pointers allow O(1) removal of a node you hold, used with a hash map in LRU caches.'],
    ],
    complexity: [
      ['Access k-th element', 'O(k)'],
      ['Insert / delete at a known node', 'O(1)'],
      ['Search by value', 'O(n)'],
      ['Reverse', 'O(n) time, O(1) space'],
    ],
    patterns: [
      ['Dummy head + tail', 'Building a new list: merge, partition, remove elements.', 'tail.next = node; tail = node; return dummy.next.'],
      ['Reverse in place', 'Reverse a list or part of it, palindrome check, reorder list.', 'Keep prev/curr/next; reverse a sublist by reconnecting its ends afterwards.'],
      ['Fast & slow / gap pointers', 'Middle node, cycle detection, n-th node from end.', 'Different speeds find middles and cycles; a fixed gap of n finds the n-th from the end.'],
    ],
    code: {
      label: 'Reverse a list and detect a cycle',
      python: `class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def reverse(head):
    prev = None
    while head:
        nxt = head.next          # save before rewiring
        head.next = prev
        prev, head = head, nxt
    return prev


def has_cycle(head):
    slow = fast = head
    while fast and fast.next:
        slow, fast = slow.next, fast.next.next
        if slow is fast:
            return True
    return False`,
      cpp: `struct ListNode {
    int val;
    ListNode* next;
    ListNode(int v = 0, ListNode* n = nullptr) : val(v), next(n) {}
};

ListNode* reverse(ListNode* head) {
    ListNode* prev = nullptr;
    while (head) {
        ListNode* nxt = head->next;   // save before rewiring
        head->next = prev;
        prev = head;
        head = nxt;
    }
    return prev;
}

bool hasCycle(ListNode* head) {
    ListNode *slow = head, *fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) return true;
    }
    return false;
}`,
    },
    pitfalls: [
      'Overwriting node.next before saving it loses the rest of the list.',
      'Dereferencing null: always check fast and fast.next before stepping twice.',
      'Test empty lists, single nodes and two nodes — most bugs live there.',
      'Draw the pointers on paper before coding a rewiring step.',
    ],
    problems: [
      ['reverse-linked-list', 'Reverse Linked List', 'E'],
      ['merge-two-sorted-lists', 'Merge Two Sorted Lists', 'E'],
      ['linked-list-cycle', 'Linked List Cycle', 'E'],
      ['middle-of-the-linked-list', 'Middle of the Linked List', 'E'],
      ['remove-nth-node-from-end-of-list', 'Remove Nth Node From End of List', 'M'],
      ['reorder-list', 'Reorder List', 'M'],
      ['add-two-numbers', 'Add Two Numbers', 'M'],
      ['copy-list-with-random-pointer', 'Copy List with Random Pointer', 'M'],
      ['reverse-nodes-in-k-group', 'Reverse Nodes in k-Group', 'H'],
    ],
  },
  {
    id: 'stacks',
    orbit: 'linear',
    title: 'Stacks & Monotonic Stacks',
    short: 'Stacks',
    prereqs: ['arrays'],
    hours: 4,
    summary: 'Last in, first out. Stacks match brackets, evaluate expressions and — as monotonic stacks — find the next greater element in linear time.',
    intro: [
      'A stack only lets you touch its top: push adds, pop removes, peek looks. That restriction is exactly what you want whenever the most recent unfinished thing must be resolved first — an opening bracket waiting for its partner, an operator waiting for its operands, a function call waiting to return.',
      'The most powerful stack trick is the monotonic stack: a stack kept in increasing or decreasing order by popping anything that breaks the order before pushing. Each pop is the moment an element meets its "next greater" (or smaller) neighbour. Because every element is pushed and popped at most once, problems that look O(n²) — daily temperatures, largest rectangle in a histogram — fall to O(n).',
    ],
    concepts: [
      ['LIFO operations', 'push, pop and peek are all O(1). Arrays/vectors make good stacks; in Python use a list with append and pop.'],
      ['Matching pairs', 'Push openers; on a closer, the top must be its matching opener.'],
      ['Expression evaluation', 'Postfix (Reverse Polish) notation evaluates with one stack; infix needs operator precedence handling.'],
      ['Monotonic stack', 'Keep indices in increasing or decreasing value order; popping reveals each element\'s next greater/smaller element.'],
      ['Stack instead of recursion', 'Any recursion can be simulated with an explicit stack — useful when recursion depth is too large.'],
      ['Auxiliary stacks', 'A second stack can track the running minimum so getMin is O(1).'],
    ],
    complexity: [
      ['push / pop / peek', 'O(1)'],
      ['Monotonic stack over n elements', 'O(n) total — each element pushed and popped once'],
    ],
    patterns: [
      ['Match and cancel', 'Valid parentheses, asteroid collision, removing adjacent duplicates.', 'Push; when the new item cancels the top, pop instead.'],
      ['Next greater / smaller', 'Daily temperatures, stock span, next greater element.', 'Store indices; pop while the current value beats the top, answering each popped index.'],
      ['Nested structure', 'Decode string, basic calculator.', 'Push the current context when you enter a bracket; pop and combine when you leave it.'],
    ],
    code: {
      label: 'Daily temperatures — monotonic stack',
      python: `def daily_temperatures(temps):
    answer = [0] * len(temps)
    stack = []                       # indices; temperatures decreasing
    for i, t in enumerate(temps):
        while stack and temps[stack[-1]] < t:
            j = stack.pop()
            answer[j] = i - j        # i is j's next warmer day
        stack.append(i)
    return answer`,
      cpp: `vector<int> dailyTemperatures(const vector<int>& temps) {
    vector<int> answer(temps.size(), 0);
    vector<int> stack;               // indices; temperatures decreasing
    for (int i = 0; i < (int)temps.size(); ++i) {
        while (!stack.empty() && temps[stack.back()] < temps[i]) {
            int j = stack.back();
            stack.pop_back();
            answer[j] = i - j;
        }
        stack.push_back(i);
    }
    return answer;
}`,
    },
    pitfalls: [
      'Popping or peeking an empty stack — check before you touch the top.',
      'Storing values when you later need positions; push indices and look values up.',
      'Strict (&lt;) vs non-strict (&lt;=) comparisons change how duplicates are handled.',
    ],
    problems: [
      ['valid-parentheses', 'Valid Parentheses', 'E'],
      ['min-stack', 'Min Stack', 'M'],
      ['evaluate-reverse-polish-notation', 'Evaluate Reverse Polish Notation', 'M'],
      ['daily-temperatures', 'Daily Temperatures', 'M'],
      ['decode-string', 'Decode String', 'M'],
      ['asteroid-collision', 'Asteroid Collision', 'M'],
      ['largest-rectangle-in-histogram', 'Largest Rectangle in Histogram', 'H'],
      ['basic-calculator', 'Basic Calculator', 'H'],
    ],
  },
  {
    id: 'queues',
    orbit: 'linear',
    title: 'Queues, Deques & Monotonic Queues',
    short: 'Queues',
    prereqs: ['stacks'],
    hours: 3,
    summary: 'First in, first out. Queues power BFS and scheduling; double-ended queues solve sliding-window maximum in linear time.',
    intro: [
      'A queue serves elements in arrival order: enqueue at the back, dequeue from the front. That makes it the natural structure for anything processed in rounds — breadth-first search explores a graph level by level with a queue, and simulations of waiting lines, task schedulers and rate limiters all use one.',
      'A deque (double-ended queue) allows O(1) pushes and pops at both ends. Its star application is the monotonic deque: keep indices whose values are in decreasing order, drop indices that slide out of the window from the front, and the front is always the window\'s maximum. Sliding-window maximum goes from O(n·k) to O(n).',
    ],
    concepts: [
      ['FIFO operations', 'Enqueue at the back, dequeue at the front, both O(1) with the right implementation.'],
      ['Use a real deque', 'Python list.pop(0) is O(n). Use collections.deque; in C++ use std::queue or std::deque.'],
      ['Circular buffers', 'A fixed array with head and tail indices that wrap around with modulo — how bounded queues are built.'],
      ['Queues in BFS', 'Process nodes in the order discovered; nodes come out in non-decreasing distance from the source.'],
      ['Monotonic deque', 'Maintain decreasing values; pop smaller ones from the back, expired ones from the front.'],
      ['Queue from two stacks', 'An inbox stack and an outbox stack give amortised O(1) queue operations.'],
    ],
    complexity: [
      ['Enqueue / dequeue (deque)', 'O(1)'],
      ['Python list.pop(0)', 'O(n) — avoid'],
      ['Sliding window max with deque', 'O(n) total'],
    ],
    patterns: [
      ['Level-by-level processing', 'BFS, level order traversal, rotting oranges.', 'Record len(queue) at the start of a level and process exactly that many.'],
      ['Monotonic deque', 'Sliding window maximum/minimum, shortest subarray with sum ≥ k.', 'Keep the deque sorted; front is the answer for the current window.'],
      ['Round-based simulation', 'Recent calls counter, Dota2 senate, task scheduling.', 'Push items back with updated state; pop expired items from the front.'],
    ],
    code: {
      label: 'Sliding window maximum — monotonic deque',
      python: `from collections import deque


def max_sliding_window(nums, k):
    dq, out = deque(), []            # indices, values decreasing
    for i, x in enumerate(nums):
        while dq and nums[dq[-1]] <= x:
            dq.pop()                 # smaller values can never be a max again
        dq.append(i)
        if dq[0] <= i - k:
            dq.popleft()             # front index left the window
        if i >= k - 1:
            out.append(nums[dq[0]])
    return out`,
      cpp: `vector<int> maxSlidingWindow(const vector<int>& nums, int k) {
    deque<int> dq;                   // indices, values decreasing
    vector<int> out;
    for (int i = 0; i < (int)nums.size(); ++i) {
        while (!dq.empty() && nums[dq.back()] <= nums[i]) dq.pop_back();
        dq.push_back(i);
        if (dq.front() <= i - k) dq.pop_front();
        if (i >= k - 1) out.push_back(nums[dq.front()]);
    }
    return out;
}`,
    },
    pitfalls: [
      'Using a list as a queue in Python and paying O(n) per dequeue.',
      'Forgetting to expire indices that have left the window.',
      'Reading the front of an empty queue.',
    ],
    problems: [
      ['implement-queue-using-stacks', 'Implement Queue using Stacks', 'E'],
      ['number-of-recent-calls', 'Number of Recent Calls', 'E'],
      ['first-unique-character-in-a-string', 'First Unique Character in a String', 'E'],
      ['design-circular-queue', 'Design Circular Queue', 'M'],
      ['dota2-senate', 'Dota2 Senate', 'M'],
      ['sliding-window-maximum', 'Sliding Window Maximum', 'H'],
      ['shortest-subarray-with-sum-at-least-k', 'Shortest Subarray with Sum at Least K', 'H'],
    ],
  },
];
