import { ORBITS, XP, LEVELS } from './orbits.js';
import t1 from './topics-1-foundations.js';
import t2 from './topics-2-patterns.js';
import t3 from './topics-3-linear.js';
import t4 from './topics-4-trees.js';
import t5 from './topics-5-graphs.js';
import t6 from './topics-6-mastery.js';

export const TOPICS = [...t1, ...t2, ...t3, ...t4, ...t5, ...t6];
export { ORBITS, XP, LEVELS };
export { QUIZZES } from './quizzes.js';
