export default [
  {
    id: 'two-pointers',
    orbit: 'patterns',
    title: 'Two Pointers',
    short: 'Two Pointers',
    prereqs: ['arrays', 'strings'],
    hours: 4,
    summary: 'Walk two indices through an array to eliminate whole groups of candidates at once, turning O(n²) pair searches into O(n).',
    intro: [
      'The two-pointer technique keeps two indices into the same sequence and moves them according to a rule. Its power comes from elimination: when the array is sorted and the sum of a[lo] + a[hi] is too small, no pair using a[lo] with anything left of hi can work either, so lo can advance. One comparison rules out a whole row of the brute-force grid.',
      'There are two shapes. Converging pointers start at both ends and move inward (pair sums, palindromes, container with most water). Same-direction pointers move left to right at different speeds (removing duplicates, partitioning, fast/slow cycle detection). Both run in linear time because each pointer only ever moves forward.',
    ],
    concepts: [
      ['Converging pointers', 'lo at the start, hi at the end; move whichever side the comparison says cannot be part of an answer.'],
      ['Why sorting enables it', 'Sorted order makes "too small → move lo, too big → move hi" provably safe.'],
      ['Read/write pointers', 'One pointer scans, the other marks where the next kept element goes.'],
      ['Partitioning', 'Dutch national flag: three regions (< pivot, = pivot, > pivot) maintained by three pointers in one pass.'],
      ['Skipping duplicates', 'After recording an answer, advance past equal values so the same triple is not reported twice.'],
      ['k-Sum reduction', 'Fix one element and run two pointers on the rest: 3Sum is O(n²), 4Sum O(n³).'],
    ],
    complexity: [
      ['Pair with target sum (sorted)', 'O(n) vs O(n²) brute force'],
      ['3Sum', 'O(n²) after an O(n log n) sort'],
      ['Partition / remove duplicates', 'O(n) time, O(1) space'],
    ],
    patterns: [
      ['Converging', 'Pair or triplet sums, container with most water, trapping rain water.', 'Compare, then move the pointer on the side that limits the answer.'],
      ['Read / write', 'Remove duplicates, remove element, move zeroes.', 'Copy kept elements to the write index — the array is compacted in place.'],
      ['Merge two sorted sequences', 'Merge sorted arrays, intersection of sorted lists.', 'One pointer per sequence; always take the smaller front element.'],
    ],
    code: {
      label: '3Sum — fix one number, two-pointer the rest',
      python: `def three_sum(nums):
    nums.sort()
    result = []
    for i in range(len(nums) - 2):
        if i > 0 and nums[i] == nums[i - 1]:
            continue                       # skip duplicate anchors
        lo, hi = i + 1, len(nums) - 1
        while lo < hi:
            total = nums[i] + nums[lo] + nums[hi]
            if total < 0:
                lo += 1
            elif total > 0:
                hi -= 1
            else:
                result.append([nums[i], nums[lo], nums[hi]])
                lo += 1
                while lo < hi and nums[lo] == nums[lo - 1]:
                    lo += 1                # skip duplicate seconds
                hi -= 1
    return result`,
      cpp: `vector<vector<int>> threeSum(vector<int> nums) {
    sort(nums.begin(), nums.end());
    vector<vector<int>> result;
    int n = nums.size();
    for (int i = 0; i + 2 < n; ++i) {
        if (i > 0 && nums[i] == nums[i - 1]) continue;
        int lo = i + 1, hi = n - 1;
        while (lo < hi) {
            int total = nums[i] + nums[lo] + nums[hi];
            if (total < 0) ++lo;
            else if (total > 0) --hi;
            else {
                result.push_back({nums[i], nums[lo], nums[hi]});
                ++lo;
                while (lo < hi && nums[lo] == nums[lo - 1]) ++lo;
                --hi;
            }
        }
    }
    return result;
}`,
    },
    pitfalls: [
      'Converging pointers only work if the data is sorted (or the problem has an equivalent monotonic property).',
      'Make sure every branch of the loop moves at least one pointer, or you loop forever.',
      'Sorting destroys original indices — store (value, index) pairs if the answer needs them.',
    ],
    problems: [
      ['merge-sorted-array', 'Merge Sorted Array', 'E'],
      ['remove-duplicates-from-sorted-array', 'Remove Duplicates from Sorted Array', 'E'],
      ['two-sum-ii-input-array-is-sorted', 'Two Sum II – Input Array Is Sorted', 'M'],
      ['3sum', '3Sum', 'M'],
      ['container-with-most-water', 'Container With Most Water', 'M'],
      ['sort-colors', 'Sort Colors', 'M'],
      ['trapping-rain-water', 'Trapping Rain Water', 'H'],
    ],
  },
  {
    id: 'sliding-window',
    orbit: 'patterns',
    title: 'Sliding Window',
    short: 'Sliding Window',
    prereqs: ['two-pointers', 'hashing'],
    hours: 5,
    summary: 'Maintain a moving range over an array or string and update its state incrementally instead of recomputing every subarray.',
    intro: [
      'Many problems ask for the best contiguous subarray or substring that satisfies a condition. Checking every one is O(n²) or worse. A sliding window keeps a single range [left, right], grows it by moving right, and shrinks it by moving left whenever the condition breaks. Because each element enters and leaves the window at most once, the total work is O(n).',
      'The art is choosing the window state: a running sum, a count of each character, the number of distinct values. The state must be cheap to update when one element enters or leaves. If you can do that, the problem is probably a sliding window.',
    ],
    concepts: [
      ['Fixed-size window', 'Add the new element, remove the one that fell off the left, update the answer — e.g. maximum average of k consecutive numbers.'],
      ['Variable-size window', 'Expand right every step; while the window is invalid, shrink from the left.'],
      ['Window state', 'Sum, frequency map, distinct count or "chars still needed" — updated in O(1) per move.'],
      ['Longest vs shortest', 'For the longest valid window, update the answer after shrinking; for the shortest, update while the window is still valid during shrinking.'],
      ['"Exactly K" trick', 'Count of subarrays with exactly K = atMost(K) − atMost(K − 1).'],
      ['When windows fail', 'With negative numbers, a larger window does not mean a larger sum, so "shrink while sum > target" breaks. Use prefix sums instead.'],
    ],
    complexity: [
      ['All subarrays, brute force', 'O(n²) windows, often O(n³) total'],
      ['Sliding window', 'O(n) time'],
      ['Window with frequency map', 'O(n) time, O(alphabet) space'],
    ],
    patterns: [
      ['Fixed window', 'Problems that say "subarray of size k".', 'Pre-fill k elements, then slide one step at a time.'],
      ['Longest valid window', 'Longest substring without repeats, with at most k replacements, fruit into baskets.', 'Expand; shrink only until valid again; record right − left + 1.'],
      ['Shortest covering window', 'Minimum window substring, minimum size subarray sum.', 'Expand until valid; then shrink as far as possible while recording the length.'],
    ],
    code: {
      label: 'Longest substring without repeating characters',
      python: `def length_of_longest_substring(s):
    last_seen = {}
    left = best = 0
    for right, ch in enumerate(s):
        if ch in last_seen and last_seen[ch] >= left:
            left = last_seen[ch] + 1          # jump past the repeat
        last_seen[ch] = right
        best = max(best, right - left + 1)
    return best`,
      cpp: `int lengthOfLongestSubstring(const string& s) {
    array<int, 256> lastSeen;
    lastSeen.fill(-1);
    int left = 0, best = 0;
    for (int right = 0; right < (int)s.size(); ++right) {
        unsigned char ch = s[right];
        if (lastSeen[ch] >= left) left = lastSeen[ch] + 1;
        lastSeen[ch] = right;
        best = max(best, right - left + 1);
    }
    return best;
}`,
    },
    pitfalls: [
      'Forgetting to update the window state when the left edge moves.',
      'Window length is right − left + 1, not right − left.',
      'Applying a shrinking window to arrays with negative numbers.',
    ],
    problems: [
      ['maximum-average-subarray-i', 'Maximum Average Subarray I', 'E'],
      ['longest-substring-without-repeating-characters', 'Longest Substring Without Repeating Characters', 'M'],
      ['longest-repeating-character-replacement', 'Longest Repeating Character Replacement', 'M'],
      ['permutation-in-string', 'Permutation in String', 'M'],
      ['minimum-size-subarray-sum', 'Minimum Size Subarray Sum', 'M'],
      ['fruit-into-baskets', 'Fruit Into Baskets', 'M'],
      ['minimum-window-substring', 'Minimum Window Substring', 'H'],
      ['subarrays-with-k-different-integers', 'Subarrays with K Different Integers', 'H'],
    ],
  },
  {
    id: 'prefix-sums',
    orbit: 'patterns',
    title: 'Prefix Sums & Difference Arrays',
    short: 'Prefix Sums',
    prereqs: ['arrays', 'hashing'],
    hours: 3,
    summary: 'Precompute running totals once to answer any range-sum query in O(1), and count subarrays with a target sum using a hash map.',
    intro: [
      'A prefix sum array stores, at position i, the total of the first i elements. The sum of any range [l, r] is then prefix[r + 1] − prefix[l]: two lookups instead of a loop. Building the array is O(n) once; every query afterwards is O(1).',
      'The idea generalises beautifully. Combined with a hash map of previously seen prefix sums, it counts subarrays summing to k in one pass — even with negative numbers, where sliding windows fail. Run it backwards and you get the difference array, which applies many range updates in O(1) each.',
    ],
    concepts: [
      ['Building prefix sums', 'prefix[0] = 0 and prefix[i + 1] = prefix[i] + a[i]. The extra leading zero removes edge cases.'],
      ['Range query', 'sum(l..r) = prefix[r + 1] − prefix[l].'],
      ['Prefix sum + hash map', 'A subarray ending at i sums to k exactly when some earlier prefix equals prefix_i − k.'],
      ['2D prefix sums', 'P[i][j] = sum of the rectangle above-left; any sub-rectangle is four lookups via inclusion–exclusion.'],
      ['Difference arrays', 'To add v to a[l..r], do d[l] += v and d[r + 1] −= v; one prefix-sum pass at the end produces the final array.'],
      ['Other prefix operations', 'Prefix XOR, prefix products and prefix counts follow the same idea (product of array except self uses prefix and suffix products).'],
    ],
    complexity: [
      ['Build prefix array', 'O(n)'],
      ['Range sum query', 'O(1)'],
      ['2D build / query', 'O(m·n) / O(1)'],
      ['Range update with difference array', 'O(1) each, O(n) to finalise'],
    ],
    patterns: [
      ['Many range queries, no updates', 'Range sum query, pivot index.', 'Build once, answer each query in O(1).'],
      ['Count subarrays with a property', 'Sum equals k, sum divisible by k.', 'Keep a map from prefix value (or prefix mod k) to how often it has occurred.'],
      ['Batch of range updates', 'Booking systems, car pooling, flight bookings.', 'Mark boundaries in a difference array, then sweep once.'],
    ],
    code: {
      label: 'Count subarrays whose sum equals k',
      python: `from collections import defaultdict


def subarray_sum(nums, k):
    seen = defaultdict(int)
    seen[0] = 1                 # empty prefix
    running = count = 0
    for x in nums:
        running += x
        count += seen[running - k]
        seen[running] += 1
    return count`,
      cpp: `int subarraySum(const vector<int>& nums, int k) {
    unordered_map<long long, int> seen{{0, 1}};   // empty prefix
    long long running = 0;
    int count = 0;
    for (int x : nums) {
        running += x;
        auto it = seen.find(running - k);
        if (it != seen.end()) count += it->second;
        ++seen[running];
    }
    return count;
}`,
    },
    pitfalls: [
      'Forgetting to seed the map with prefix 0 → 1 misses subarrays that start at index 0.',
      'Updating the map before querying it can count an empty subarray.',
      'Prefix sums overflow 32-bit integers on large inputs.',
      'If the array changes between queries, plain prefix sums go stale — use a Fenwick tree (see Range Queries).',
    ],
    problems: [
      ['range-sum-query-immutable', 'Range Sum Query – Immutable', 'E'],
      ['find-pivot-index', 'Find Pivot Index', 'E'],
      ['product-of-array-except-self', 'Product of Array Except Self', 'M'],
      ['subarray-sum-equals-k', 'Subarray Sum Equals K', 'M'],
      ['continuous-subarray-sum', 'Continuous Subarray Sum', 'M'],
      ['range-sum-query-2d-immutable', 'Range Sum Query 2D – Immutable', 'M'],
      ['car-pooling', 'Car Pooling', 'M'],
    ],
  },
  {
    id: 'binary-search',
    orbit: 'patterns',
    title: 'Binary Search',
    short: 'Binary Search',
    prereqs: ['arrays', 'recursion'],
    hours: 5,
    summary: 'Halve the search space every step. Beyond sorted arrays, binary search finds the answer to any problem with a monotonic yes/no condition.',
    intro: [
      'Binary search finds a target in a sorted array by repeatedly comparing with the middle element and discarding the half that cannot contain it. Thirty comparisons are enough for a billion elements. The idea is simple; the implementation is famously easy to get subtly wrong at the boundaries.',
      'The bigger idea is that binary search works on any monotonic predicate — a yes/no question whose answer switches from "no" to "yes" exactly once. "Can Koko finish all bananas at speed k?" is false for small k and true for large k, so you can binary search on k itself. This "binary search on the answer" pattern solves many optimisation problems that look nothing like searching.',
    ],
    concepts: [
      ['Invariant-driven loops', 'Decide what lo and hi mean (e.g. the answer is always in [lo, hi]) and keep that true after every update.'],
      ['Overflow-safe midpoint', 'mid = lo + (hi − lo) / 2 avoids overflow in languages with fixed-size integers.'],
      ['Lower and upper bound', 'First index ≥ x and first index > x — the building blocks for counting occurrences and finding ranges.'],
      ['Monotonic predicates', 'If ok(x) implies ok(x + 1), the first x where ok is true can be found by binary search.'],
      ['Binary search on the answer', 'Search over possible answers (speed, capacity, days) and test feasibility with a greedy check.'],
      ['Rotated sorted arrays', 'At least one half around mid is always sorted; use it to decide which half to keep.'],
    ],
    complexity: [
      ['Search in sorted array', 'O(log n)'],
      ['Binary search on answer', 'O(log(range) × cost of feasibility check)'],
      ['Lower/upper bound', 'O(log n)'],
    ],
    patterns: [
      ['Exact match', 'Classic search in a sorted array.', 'Return when a[mid] equals the target; otherwise discard a half.'],
      ['First true', 'First bad version, lower bound, search insert position.', 'If ok(mid), record and go left (hi = mid − 1); else go right.'],
      ['Minimise the maximum', 'Ship packages in D days, split array largest sum, Koko eating bananas.', 'Binary search the answer value; check feasibility greedily in O(n).'],
    ],
    code: {
      label: 'Reusable "first true" template + Koko eating bananas',
      python: `def first_true(lo, hi, ok):
    """Smallest x in [lo, hi] with ok(x) True; returns hi + 1 if none."""
    while lo <= hi:
        mid = lo + (hi - lo) // 2
        if ok(mid):
            hi = mid - 1
        else:
            lo = mid + 1
    return lo


def min_eating_speed(piles, h):
    def can_finish(k):
        return sum((p + k - 1) // k for p in piles) <= h
    return first_true(1, max(piles), can_finish)`,
      cpp: `template <class Pred>
long long firstTrue(long long lo, long long hi, Pred ok) {
    while (lo <= hi) {
        long long mid = lo + (hi - lo) / 2;
        if (ok(mid)) hi = mid - 1;
        else lo = mid + 1;
    }
    return lo;   // hi + 1 if none
}

int minEatingSpeed(const vector<int>& piles, int h) {
    auto canFinish = [&](long long k) {
        long long hours = 0;
        for (int p : piles) hours += (p + k - 1) / k;
        return hours <= h;
    };
    int maxPile = *max_element(piles.begin(), piles.end());
    return (int)firstTrue(1, maxPile, canFinish);
}`,
    },
    pitfalls: [
      'Mixing conventions (inclusive hi with <code>&lt;</code>, or lo = mid with an exclusive bound) is the source of most infinite loops.',
      'The predicate must be truly monotonic; otherwise binary search returns garbage silently.',
      'Test with arrays of size 1 and 2, and with the target at both ends.',
    ],
    problems: [
      ['binary-search', 'Binary Search', 'E'],
      ['search-insert-position', 'Search Insert Position', 'E'],
      ['first-bad-version', 'First Bad Version', 'E'],
      ['find-first-and-last-position-of-element-in-sorted-array', 'Find First and Last Position of Element in Sorted Array', 'M'],
      ['search-in-rotated-sorted-array', 'Search in Rotated Sorted Array', 'M'],
      ['find-minimum-in-rotated-sorted-array', 'Find Minimum in Rotated Sorted Array', 'M'],
      ['koko-eating-bananas', 'Koko Eating Bananas', 'M'],
      ['median-of-two-sorted-arrays', 'Median of Two Sorted Arrays', 'H'],
    ],
  },
  {
    id: 'sorting',
    orbit: 'patterns',
    title: 'Sorting Algorithms',
    short: 'Sorting',
    prereqs: ['recursion', 'arrays'],
    hours: 5,
    summary: 'How merge sort, quicksort, heap sort and counting sort work, when each is the right tool, and how sorting unlocks other techniques.',
    intro: [
      'Sorting is rarely the whole problem, but it is the first step in an enormous number of solutions: once data is ordered, duplicates sit next to each other, two pointers become valid, intervals can be merged and binary search applies. Knowing the built-in sort is O(n log n) is often all you need — but interviews also test whether you understand how the classic algorithms work.',
      'Comparison-based sorting cannot beat O(n log n) in the worst case. Merge sort guarantees it and is stable; quicksort is usually fastest in practice but degrades to O(n²) with bad pivots; heap sort uses O(1) extra space. When values come from a small range, counting sort and radix sort skip comparisons entirely and run in linear time.',
    ],
    concepts: [
      ['Merge sort', 'Split in half, sort each half recursively, merge. O(n log n) always, stable, needs O(n) extra space.'],
      ['Quicksort and partitioning', 'Pick a pivot, partition around it, recurse. O(n log n) on average, O(n²) worst case — randomise the pivot.'],
      ['Heap sort', 'Build a max-heap, repeatedly move the max to the end. O(n log n), in place, not stable.'],
      ['Counting and radix sort', 'Count occurrences of each value (range k) for O(n + k); radix sorts digit by digit.'],
      ['Stability', 'A stable sort keeps equal elements in their original order — essential when sorting by several keys in passes.'],
      ['Custom comparators and quickselect', 'Sort by any rule (largest number, by frequency); quickselect finds the k-th element in O(n) average.'],
    ],
    complexity: [
      ['Bubble / insertion sort', 'O(n²); insertion is O(n) on nearly sorted data'],
      ['Merge sort', 'O(n log n) time, O(n) space, stable'],
      ['Quicksort', 'O(n log n) average, O(n²) worst'],
      ['Heap sort', 'O(n log n) time, O(1) space'],
      ['Counting sort', 'O(n + k) for values in a range of size k'],
    ],
    patterns: [
      ['Sort, then sweep', 'Merging intervals, finding duplicates, greedy scheduling.', 'Sorting makes related items adjacent; a single pass finishes the job.'],
      ['Custom order', 'Largest number from digits, sort by frequency, relative order.', 'Write a comparator that encodes the desired order (and is a strict weak ordering).'],
      ['Partial sorting', 'k-th largest, top-k.', 'Quickselect (O(n) average) or a heap (O(n log k)) instead of a full sort.'],
    ],
    code: {
      label: 'Merge sort',
      python: `def merge_sort(a):
    if len(a) <= 1:
        return a
    mid = len(a) // 2
    left, right = merge_sort(a[:mid]), merge_sort(a[mid:])
    merged, i, j = [], 0, 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:          # <= keeps the sort stable
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged`,
      cpp: `void mergeSort(vector<int>& a, int lo, int hi, vector<int>& tmp) {   // sorts [lo, hi)
    if (hi - lo <= 1) return;
    int mid = lo + (hi - lo) / 2;
    mergeSort(a, lo, mid, tmp);
    mergeSort(a, mid, hi, tmp);
    int i = lo, j = mid, k = lo;
    while (i < mid && j < hi) tmp[k++] = (a[i] <= a[j]) ? a[i++] : a[j++];
    while (i < mid) tmp[k++] = a[i++];
    while (j < hi) tmp[k++] = a[j++];
    for (int t = lo; t < hi; ++t) a[t] = tmp[t];
}

void mergeSort(vector<int>& a) {
    vector<int> tmp(a.size());
    mergeSort(a, 0, (int)a.size(), tmp);
}`,
    },
    pitfalls: [
      'C++ comparators must return a &lt; b, never a &lt;= b — non-strict comparators cause undefined behaviour in std::sort.',
      'Quicksort with a fixed first/last pivot is O(n²) on already sorted input.',
      'Sorting loses original positions; keep the index alongside the value if you need it.',
    ],
    problems: [
      ['relative-sort-array', 'Relative Sort Array', 'E'],
      ['sort-an-array', 'Sort an Array', 'M'],
      ['sort-list', 'Sort List', 'M'],
      ['largest-number', 'Largest Number', 'M'],
      ['sort-characters-by-frequency', 'Sort Characters By Frequency', 'M'],
      ['h-index', 'H-Index', 'M'],
    ],
  },
  {
    id: 'intervals',
    orbit: 'patterns',
    title: 'Intervals & Sweep Line',
    short: 'Intervals',
    prereqs: ['sorting'],
    hours: 3,
    summary: 'Merge, insert and schedule ranges. Almost every interval problem starts by sorting and then sweeps once.',
    intro: [
      'Interval problems describe ranges — meetings, bookings, balloons on a number line — and ask how they overlap. Two intervals [a, b] and [c, d] overlap exactly when a ≤ d and c ≤ b. Once intervals are sorted by start, any overlap must be with the most recently kept interval, so a single linear pass can merge them.',
      'A second family is about counting overlaps at each point in time. The sweep-line technique turns each interval into two events (+1 at the start, −1 at the end), sorts the events and walks through them keeping a running count. The peak count is the number of rooms, platforms or machines needed.',
    ],
    concepts: [
      ['Overlap condition', 'Intervals [a, b] and [c, d] overlap iff a ≤ d and c ≤ b. Check whether touching endpoints count for your problem.'],
      ['Sort by start to merge', 'After sorting, compare each interval only with the last merged one.'],
      ['Sort by end for scheduling', 'To keep the most non-overlapping intervals, always pick the one that finishes first.'],
      ['Sweep line', 'Convert to start/end events, sort, and maintain a running count of active intervals.'],
      ['Inserting into sorted intervals', 'Copy the ones fully before, merge everything that overlaps, copy the rest.'],
      ['Heaps for active intervals', 'A min-heap of end times tracks which rooms free up first.'],
    ],
    complexity: [
      ['Sort intervals', 'O(n log n)'],
      ['Merge after sorting', 'O(n)'],
      ['Sweep line over 2n events', 'O(n log n)'],
    ],
    patterns: [
      ['Merge', 'Merge intervals, insert interval, summary ranges.', 'Sort by start; extend the last interval or start a new one.'],
      ['Greedy by end time', 'Non-overlapping intervals, minimum arrows to burst balloons.', 'Sort by end; take an interval whenever it starts after the last chosen end.'],
      ['Two-list intersection', 'Interval list intersections.', 'Two pointers, one per list; advance the one that ends first.'],
    ],
    code: {
      label: 'Merge overlapping intervals',
      python: `def merge(intervals):
    intervals.sort(key=lambda iv: iv[0])
    merged = []
    for start, end in intervals:
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)   # overlap: extend
        else:
            merged.append([start, end])
    return merged`,
      cpp: `vector<vector<int>> merge(vector<vector<int>> intervals) {
    sort(intervals.begin(), intervals.end());
    vector<vector<int>> merged;
    for (auto& iv : intervals) {
        if (!merged.empty() && iv[0] <= merged.back()[1])
            merged.back()[1] = max(merged.back()[1], iv[1]);   // overlap: extend
        else
            merged.push_back(iv);
    }
    return merged;
}`,
    },
    pitfalls: [
      'Whether [1, 2] and [2, 3] overlap depends on the problem — read it carefully.',
      'When extending, take max(end, current end); a later interval can be fully contained in the previous one.',
      'In sweep lines, decide whether an end event at time t is processed before a start event at t.',
    ],
    problems: [
      ['summary-ranges', 'Summary Ranges', 'E'],
      ['merge-intervals', 'Merge Intervals', 'M'],
      ['insert-interval', 'Insert Interval', 'M'],
      ['non-overlapping-intervals', 'Non-overlapping Intervals', 'M'],
      ['minimum-number-of-arrows-to-burst-balloons', 'Minimum Number of Arrows to Burst Balloons', 'M'],
      ['interval-list-intersections', 'Interval List Intersections', 'M'],
      ['minimum-interval-to-include-each-query', 'Minimum Interval to Include Each Query', 'H'],
    ],
  },
];
