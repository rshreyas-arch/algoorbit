export default [
  {
    id: 'binary-trees',
    orbit: 'trees',
    title: 'Binary Trees',
    short: 'Binary Trees',
    prereqs: ['recursion', 'queues'],
    hours: 6,
    summary: 'Traversals, depth, diameter and lowest common ancestors. Tree problems are recursion problems: decide what each subtree returns.',
    intro: [
      'A binary tree is a set of nodes where each node has at most two children. Trees model hierarchies — file systems, organisation charts, parsed expressions — and they are the most common interview topic after arrays. Nearly every tree problem is solved by visiting each node once, so the real question is in what order and carrying what information.',
      'Think of each recursive call as asking a subtree a question. Top-down solutions pass information down (the depth so far, the allowed range). Bottom-up solutions ask each child for an answer and combine them (the height of a subtree, whether it is balanced). Breadth-first traversal with a queue handles anything phrased in terms of levels.',
    ],
    concepts: [
      ['Terminology', 'Root, leaf, parent, child, depth (distance from root), height (longest path down to a leaf).'],
      ['Depth-first traversals', 'Preorder (node, left, right), inorder (left, node, right) and postorder (left, right, node).'],
      ['Breadth-first traversal', 'Visit level by level with a queue — right side view, zigzag order, minimum depth.'],
      ['Bottom-up recursion', 'Return a value from each subtree and combine: height, diameter, balanced check, max path sum.'],
      ['Top-down recursion', 'Pass state as parameters: path sums, valid ranges, depth so far.'],
      ['Lowest common ancestor', 'The first node where p and q are found in different subtrees (or the node is one of them).'],
    ],
    complexity: [
      ['Any traversal', 'O(n) time'],
      ['Recursion stack', 'O(h): O(log n) balanced, O(n) skewed'],
      ['BFS queue', 'O(w) where w is the maximum width'],
    ],
    patterns: [
      ['Return from children', 'Max depth, diameter, balanced tree, max path sum.', 'Compute left and right results, combine, and update a global best if needed.'],
      ['Carry state down', 'Path sum, good nodes, sum root-to-leaf numbers.', 'Add the current node to the state before recursing into children.'],
      ['Level order', 'Right side view, average of levels, zigzag traversal.', 'BFS, processing len(queue) nodes per level.'],
    ],
    code: {
      label: 'Max depth (DFS) and level order (BFS)',
      python: `from collections import deque


class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val, self.left, self.right = val, left, right


def max_depth(root):
    if not root:
        return 0
    return 1 + max(max_depth(root.left), max_depth(root.right))


def level_order(root):
    if not root:
        return []
    levels, queue = [], deque([root])
    while queue:
        level = []
        for _ in range(len(queue)):
            node = queue.popleft()
            level.append(node.val)
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        levels.append(level)
    return levels`,
      cpp: `struct TreeNode {
    int val;
    TreeNode *left, *right;
    TreeNode(int v = 0) : val(v), left(nullptr), right(nullptr) {}
};

int maxDepth(TreeNode* root) {
    if (!root) return 0;
    return 1 + max(maxDepth(root->left), maxDepth(root->right));
}

vector<vector<int>> levelOrder(TreeNode* root) {
    vector<vector<int>> levels;
    if (!root) return levels;
    queue<TreeNode*> q;
    q.push(root);
    while (!q.empty()) {
        vector<int> level;
        for (int i = (int)q.size(); i > 0; --i) {
            TreeNode* node = q.front(); q.pop();
            level.push_back(node->val);
            if (node->left) q.push(node->left);
            if (node->right) q.push(node->right);
        }
        levels.push_back(level);
    }
    return levels;
}`,
    },
    pitfalls: [
      'Forgetting the null case — every recursive tree function needs it first.',
      'Confusing depth and height, or counting edges vs nodes; read the definition in the problem.',
      'A global "best" variable must be reset between test cases.',
      'Deep, skewed trees can overflow the recursion stack — iterate with an explicit stack if n is large.',
    ],
    problems: [
      ['maximum-depth-of-binary-tree', 'Maximum Depth of Binary Tree', 'E'],
      ['invert-binary-tree', 'Invert Binary Tree', 'E'],
      ['same-tree', 'Same Tree', 'E'],
      ['diameter-of-binary-tree', 'Diameter of Binary Tree', 'E'],
      ['binary-tree-level-order-traversal', 'Binary Tree Level Order Traversal', 'M'],
      ['binary-tree-right-side-view', 'Binary Tree Right Side View', 'M'],
      ['lowest-common-ancestor-of-a-binary-tree', 'Lowest Common Ancestor of a Binary Tree', 'M'],
      ['construct-binary-tree-from-preorder-and-inorder-traversal', 'Construct Binary Tree from Preorder and Inorder Traversal', 'M'],
      ['binary-tree-maximum-path-sum', 'Binary Tree Maximum Path Sum', 'H'],
      ['serialize-and-deserialize-binary-tree', 'Serialize and Deserialize Binary Tree', 'H'],
    ],
  },
  {
    id: 'bst',
    orbit: 'trees',
    title: 'Binary Search Trees',
    short: 'BST',
    prereqs: ['binary-trees', 'binary-search'],
    hours: 4,
    summary: 'Trees that keep data sorted: left is smaller, right is larger. Search, insert and delete follow one root-to-leaf path.',
    intro: [
      'A binary search tree adds one rule to a binary tree: everything in a node\'s left subtree is smaller than the node, and everything in its right subtree is larger. That rule turns every lookup into binary search along a single path, and an inorder traversal visits the values in sorted order.',
      'The catch is shape. A BST built from sorted input degenerates into a linked list with O(n) operations. Self-balancing trees (AVL, red–black) fix this by rotating nodes, and you use them every day without noticing: C++ std::map and std::set and Java\'s TreeMap are balanced BSTs with guaranteed O(log n) operations.',
    ],
    concepts: [
      ['The BST property', 'The rule applies to whole subtrees, not just direct children — a classic source of wrong "validate BST" solutions.'],
      ['Inorder is sorted', 'Inorder traversal of a BST yields values in increasing order; k-th smallest is the k-th node visited.'],
      ['Search and insert', 'Compare with the current node and go left or right; insert where you fall off the tree.'],
      ['Deletion', 'Leaf: remove. One child: splice it in. Two children: replace with the inorder successor, then delete that.'],
      ['Balance', 'Height decides cost. Balanced trees keep h = O(log n); skewed trees make it O(n).'],
      ['Ordered containers', 'std::map/set, TreeMap/TreeSet give floor, ceiling, and ordered iteration in O(log n).'],
    ],
    complexity: [
      ['Search / insert / delete', 'O(h): O(log n) balanced, O(n) skewed'],
      ['Inorder traversal', 'O(n)'],
      ['Min / max', 'O(h) — walk left or right'],
    ],
    patterns: [
      ['Range-bounded recursion', 'Validate BST, trim a BST, range sum of BST.', 'Pass (low, high) bounds down; prune subtrees outside the range.'],
      ['Inorder walk', 'k-th smallest, recover swapped nodes, BST iterator.', 'Use the sorted order directly, iteratively with a stack if needed.'],
      ['Guided descent', 'Search, insert, LCA in a BST, closest value.', 'One comparison per level decides the direction.'],
    ],
    code: {
      label: 'Validate a BST with bounds',
      python: `def is_valid_bst(root, low=float('-inf'), high=float('inf')):
    if not root:
        return True
    if not (low < root.val < high):
        return False
    return (is_valid_bst(root.left, low, root.val) and
            is_valid_bst(root.right, root.val, high))`,
      cpp: `struct TreeNode {
    int val;
    TreeNode *left, *right;
    TreeNode(int v = 0) : val(v), left(nullptr), right(nullptr) {}
};

bool isValidBST(TreeNode* root, long long low = LLONG_MIN, long long high = LLONG_MAX) {
    if (!root) return true;
    if (root->val <= low || root->val >= high) return false;
    return isValidBST(root->left, low, root->val) &&
           isValidBST(root->right, root->val, high);
}`,
    },
    pitfalls: [
      'Only comparing a node with its children misses violations deeper down.',
      'Using INT_MIN/INT_MAX as bounds breaks when node values equal them — use wider types or nullable bounds.',
      'Check whether duplicates are allowed and on which side they go.',
    ],
    problems: [
      ['search-in-a-binary-search-tree', 'Search in a Binary Search Tree', 'E'],
      ['convert-sorted-array-to-binary-search-tree', 'Convert Sorted Array to Binary Search Tree', 'E'],
      ['validate-binary-search-tree', 'Validate Binary Search Tree', 'M'],
      ['kth-smallest-element-in-a-bst', 'Kth Smallest Element in a BST', 'M'],
      ['lowest-common-ancestor-of-a-binary-search-tree', 'Lowest Common Ancestor of a Binary Search Tree', 'M'],
      ['insert-into-a-binary-search-tree', 'Insert into a Binary Search Tree', 'M'],
      ['delete-node-in-a-bst', 'Delete Node in a BST', 'M'],
      ['recover-binary-search-tree', 'Recover Binary Search Tree', 'M'],
    ],
  },
  {
    id: 'heaps',
    orbit: 'trees',
    title: 'Heaps & Priority Queues',
    short: 'Heaps',
    prereqs: ['binary-trees', 'sorting'],
    hours: 4,
    summary: 'Always know the smallest (or largest) item in O(1) and remove it in O(log n). The tool for top-k, merging and scheduling problems.',
    intro: [
      'A heap is a complete binary tree stored in an array where every parent is no larger than its children (a min-heap) or no smaller (a max-heap). It does not keep everything sorted — only the root is guaranteed to be the extreme — and that relaxed promise is what lets push and pop run in O(log n).',
      'Whenever a problem repeatedly asks for "the smallest so far", "the k largest" or "the next event to happen", reach for a heap. Python\'s heapq is a min-heap (negate values for a max-heap); C++ std::priority_queue is a max-heap by default (pass greater<> for a min-heap).',
    ],
    concepts: [
      ['Array representation', 'Children of index i live at 2i + 1 and 2i + 2; parent at (i − 1) / 2. No pointers needed.'],
      ['Sift up and sift down', 'Push appends then bubbles up; pop moves the last element to the root and bubbles it down.'],
      ['Heapify in O(n)', 'Building a heap from an array bottom-up is linear, not O(n log n).'],
      ['Top-k with a size-k heap', 'Keep a min-heap of the k largest seen; anything smaller than the root is discarded.'],
      ['Two heaps', 'A max-heap for the lower half and a min-heap for the upper half give a running median.'],
      ['Lazy deletion', 'Heaps cannot remove arbitrary items efficiently; mark them stale and skip them when they surface.'],
    ],
    complexity: [
      ['Peek min/max', 'O(1)'],
      ['Push / pop', 'O(log n)'],
      ['Build from n items', 'O(n)'],
      ['Top-k of n items', 'O(n log k)'],
    ],
    patterns: [
      ['Top-k', 'k-th largest, k closest points, top-k frequent.', 'Maintain a heap of size k with the "worst kept" item at the root.'],
      ['K-way merge', 'Merge k sorted lists, smallest range covering k lists.', 'Push the head of each list; pop the smallest and push its successor.'],
      ['Greedy scheduling', 'Task scheduler, IPO, meeting rooms.', 'Always process the most urgent or most profitable available item next.'],
    ],
    code: {
      label: 'K-th largest element with a size-k min-heap',
      python: `import heapq


def find_kth_largest(nums, k):
    heap = []
    for x in nums:
        heapq.heappush(heap, x)
        if len(heap) > k:
            heapq.heappop(heap)      # drop the smallest
    return heap[0]`,
      cpp: `int findKthLargest(const vector<int>& nums, int k) {
    priority_queue<int, vector<int>, greater<int>> heap;   // min-heap
    for (int x : nums) {
        heap.push(x);
        if ((int)heap.size() > k) heap.pop();             // drop the smallest
    }
    return heap.top();
}`,
    },
    pitfalls: [
      'Mixing up default directions: heapq is a min-heap, priority_queue is a max-heap.',
      'Pushing tuples whose second element is not comparable — add a counter as a tie-breaker.',
      'Using a heap when you need to search or remove arbitrary elements; use a balanced BST (std::set) instead.',
    ],
    problems: [
      ['kth-largest-element-in-a-stream', 'Kth Largest Element in a Stream', 'E'],
      ['last-stone-weight', 'Last Stone Weight', 'E'],
      ['k-closest-points-to-origin', 'K Closest Points to Origin', 'M'],
      ['kth-largest-element-in-an-array', 'Kth Largest Element in an Array', 'M'],
      ['task-scheduler', 'Task Scheduler', 'M'],
      ['find-median-from-data-stream', 'Find Median from Data Stream', 'H'],
      ['merge-k-sorted-lists', 'Merge k Sorted Lists', 'H'],
      ['ipo', 'IPO', 'H'],
    ],
  },
  {
    id: 'tries',
    orbit: 'trees',
    title: 'Tries (Prefix Trees)',
    short: 'Tries',
    prereqs: ['binary-trees', 'strings', 'hashing'],
    hours: 3,
    summary: 'A tree of characters where shared prefixes share nodes. Ideal for autocomplete, dictionaries and prefix queries.',
    intro: [
      'A trie stores a set of strings character by character. The root represents the empty string, each edge adds one character, and a flag marks nodes where a complete word ends. Because words with a common prefix share the same path, checking whether any word starts with "algo" costs four steps no matter how many words are stored.',
      'Tries shine when you have many queries against one dictionary: autocomplete suggestions, spell checking, replacing words by their roots, or searching a grid for many words at once (build one trie, run one DFS). A binary version — a trie over the bits of numbers — finds the maximum XOR pair in linear time.',
    ],
    concepts: [
      ['Node structure', 'A map or 26-slot array of children, plus an end-of-word flag (or a count of words ending here).'],
      ['Insert, search, startsWith', 'All three walk the word one character at a time — O(L) for a word of length L.'],
      ['Prefix counts', 'Store how many words pass through each node to answer "how many words start with p?" in O(L).'],
      ['Trie + DFS', 'Word Search II: walk the grid and the trie together, pruning as soon as no word has the current prefix.'],
      ['Wildcard search', 'A "." matches any character — branch into every child at that position.'],
      ['Binary tries', 'Insert numbers bit by bit from the most significant; greedily choose the opposite bit to maximise XOR.'],
    ],
    complexity: [
      ['Insert / search / startsWith', 'O(L) per word'],
      ['Build from words', 'O(total characters)'],
      ['Space', 'O(total characters × alphabet) worst case with arrays'],
    ],
    patterns: [
      ['Prefix lookup', 'Autocomplete, search suggestions, replace words.', 'Walk to the prefix node, then collect or check below it.'],
      ['Many words, one search', 'Word Search II, concatenated words.', 'Build one trie from all words and traverse it alongside the search.'],
      ['Bitwise greedy', 'Maximum XOR of two numbers.', 'For each bit, prefer the child that differs from the current number.'],
    ],
    code: {
      label: 'Trie with insert, search and startsWith',
      python: `class Trie:
    def __init__(self):
        self.root = {}

    def insert(self, word):
        node = self.root
        for ch in word:
            node = node.setdefault(ch, {})
        node['#end'] = True

    def _walk(self, text):
        node = self.root
        for ch in text:
            if ch not in node:
                return None
            node = node[ch]
        return node

    def search(self, word):
        node = self._walk(word)
        return node is not None and '#end' in node

    def starts_with(self, prefix):
        return self._walk(prefix) is not None`,
      cpp: `class Trie {
    struct Node {
        array<unique_ptr<Node>, 26> next;
        bool end = false;
    };
    Node root;

    const Node* walk(const string& s) const {
        const Node* node = &root;
        for (char c : s) {
            node = node->next[c - 'a'].get();
            if (!node) return nullptr;
        }
        return node;
    }

public:
    void insert(const string& word) {
        Node* node = &root;
        for (char c : word) {
            auto& child = node->next[c - 'a'];
            if (!child) child = make_unique<Node>();
            node = child.get();
        }
        node->end = true;
    }
    bool search(const string& word) const {
        const Node* node = walk(word);
        return node && node->end;
    }
    bool startsWith(const string& prefix) const { return walk(prefix) != nullptr; }
};`,
    },
    pitfalls: [
      'Forgetting the end-of-word flag makes every prefix look like a word.',
      'A 26-slot array per node is fast but memory hungry; use a hash map for large alphabets.',
      'In Word Search II, remove found words (or prune empty branches) to avoid duplicates and timeouts.',
    ],
    problems: [
      ['implement-trie-prefix-tree', 'Implement Trie (Prefix Tree)', 'M'],
      ['design-add-and-search-words-data-structure', 'Design Add and Search Words Data Structure', 'M'],
      ['replace-words', 'Replace Words', 'M'],
      ['longest-word-in-dictionary', 'Longest Word in Dictionary', 'M'],
      ['search-suggestions-system', 'Search Suggestions System', 'M'],
      ['maximum-xor-of-two-numbers-in-an-array', 'Maximum XOR of Two Numbers in an Array', 'M'],
      ['word-search-ii', 'Word Search II', 'H'],
    ],
  },
];
