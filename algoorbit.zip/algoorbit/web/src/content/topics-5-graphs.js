export default [
  {
    id: 'graphs',
    orbit: 'graphs',
    title: 'Graph Traversal: BFS & DFS',
    short: 'BFS & DFS',
    prereqs: ['binary-trees', 'queues', 'hashing'],
    hours: 6,
    summary: 'Represent networks as adjacency lists and explore them with breadth-first and depth-first search — including grids, which are graphs in disguise.',
    intro: [
      'A graph is a set of vertices connected by edges. Roads between cities, friendships, web links, course prerequisites and the cells of a maze are all graphs. Trees are a special case — connected and without cycles — so everything you learned about tree traversal carries over, with one addition: because graphs can contain cycles, you must remember which vertices you have already visited.',
      'Breadth-first search (BFS) explores in rings of increasing distance using a queue, so in an unweighted graph it finds shortest paths. Depth-first search (DFS) dives as deep as possible before backtracking, using recursion or a stack, and is the natural fit for connectivity, cycle detection and exploring every path. Both visit each vertex and edge once: O(V + E).',
    ],
    concepts: [
      ['Graph vocabulary', 'Vertices, edges, directed vs undirected, weighted vs unweighted, degree, connected components.'],
      ['Adjacency list vs matrix', 'Lists use O(V + E) space and suit sparse graphs; a matrix uses O(V²) but answers "is there an edge?" in O(1).'],
      ['Visited tracking', 'Mark a vertex when you first discover it so cycles do not cause infinite loops or duplicate work.'],
      ['BFS and shortest paths', 'In unweighted graphs, the first time BFS reaches a vertex is via a shortest path.'],
      ['DFS and components', 'Each DFS launched from an unvisited vertex explores exactly one connected component.'],
      ['Grids as graphs', 'Each cell is a vertex with up to four neighbours; flood fill and island counting are graph traversals.'],
    ],
    complexity: [
      ['BFS / DFS (adjacency list)', 'O(V + E) time, O(V) space'],
      ['BFS / DFS (adjacency matrix)', 'O(V²)'],
      ['Grid traversal', 'O(rows × cols)'],
    ],
    patterns: [
      ['Flood fill / count components', 'Number of islands, max area of island, provinces.', 'Loop over all vertices; start a traversal from each unvisited one and count.'],
      ['Multi-source BFS', 'Rotting oranges, walls and gates, distance to nearest 0.', 'Put every source in the queue at distance 0, then run one BFS.'],
      ['Two-colouring', 'Is graph bipartite, possible bipartition.', 'Colour neighbours opposite colours during BFS/DFS; a conflict means not bipartite.'],
    ],
    code: {
      label: 'Number of islands — BFS on a grid',
      python: `from collections import deque


def num_islands(grid):
    rows, cols = len(grid), len(grid[0])
    islands = 0
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] != '1':
                continue
            islands += 1
            grid[r][c] = '0'                     # mark when enqueuing
            queue = deque([(r, c)])
            while queue:
                y, x = queue.popleft()
                for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    ny, nx = y + dy, x + dx
                    if 0 <= ny < rows and 0 <= nx < cols and grid[ny][nx] == '1':
                        grid[ny][nx] = '0'
                        queue.append((ny, nx))
    return islands`,
      cpp: `int numIslands(vector<vector<char>>& grid) {
    int rows = grid.size(), cols = grid[0].size(), islands = 0;
    const int dirs[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    for (int r = 0; r < rows; ++r)
        for (int c = 0; c < cols; ++c) {
            if (grid[r][c] != '1') continue;
            ++islands;
            grid[r][c] = '0';                    // mark when enqueuing
            queue<pair<int, int>> q;
            q.push({r, c});
            while (!q.empty()) {
                auto [y, x] = q.front(); q.pop();
                for (auto& d : dirs) {
                    int ny = y + d[0], nx = x + d[1];
                    if (ny >= 0 && ny < rows && nx >= 0 && nx < cols && grid[ny][nx] == '1') {
                        grid[ny][nx] = '0';
                        q.push({ny, nx});
                    }
                }
            }
        }
    return islands;
}`,
    },
    pitfalls: [
      'Marking visited when dequeuing instead of enqueuing lets the same cell enter the queue many times.',
      'For undirected graphs, add each edge in both directions.',
      'Graphs can be disconnected — loop over every vertex, not just vertex 0.',
      'Recursive DFS on a 1000 × 1000 grid will overflow the stack in many languages; prefer BFS or an explicit stack.',
    ],
    problems: [
      ['flood-fill', 'Flood Fill', 'E'],
      ['find-if-path-exists-in-graph', 'Find if Path Exists in Graph', 'E'],
      ['number-of-islands', 'Number of Islands', 'M'],
      ['max-area-of-island', 'Max Area of Island', 'M'],
      ['clone-graph', 'Clone Graph', 'M'],
      ['rotting-oranges', 'Rotting Oranges', 'M'],
      ['pacific-atlantic-water-flow', 'Pacific Atlantic Water Flow', 'M'],
      ['is-graph-bipartite', 'Is Graph Bipartite?', 'M'],
      ['word-ladder', 'Word Ladder', 'H'],
    ],
  },
  {
    id: 'topological-sort',
    orbit: 'graphs',
    title: 'Topological Sort',
    short: 'Topo Sort',
    prereqs: ['graphs'],
    hours: 3,
    summary: 'Order tasks so every dependency comes first. Topological sorting also detects impossible (cyclic) dependency graphs.',
    intro: [
      'A topological order of a directed graph lists every vertex so that each edge u → v has u before v. Build systems compile libraries before the programs that use them, package managers install dependencies first, and universities sequence prerequisite courses — all are topological sorts. Such an order exists exactly when the graph has no directed cycle (it is a DAG).',
      'Kahn\'s algorithm is the most practical way to compute one: repeatedly take a vertex with no remaining incoming edges, output it, and remove its outgoing edges. If you run out of such vertices before outputting everything, the remaining vertices form a cycle — which is how "can all courses be finished?" is answered.',
    ],
    concepts: [
      ['Directed acyclic graphs', 'Topological order exists if and only if there are no directed cycles.'],
      ['Indegree', 'The number of incoming edges; a vertex with indegree 0 has no unmet dependencies.'],
      ['Kahn\'s algorithm (BFS)', 'Queue all indegree-0 vertices; pop, output, decrement neighbours, enqueue those that reach 0.'],
      ['DFS post-order', 'Reverse post-order of a DFS is a topological order; a back edge (to a vertex on the current path) means a cycle.'],
      ['Cycle detection', 'Kahn: fewer than V vertices output. DFS: a vertex is revisited while still "in progress" (grey).'],
      ['DP on a DAG', 'Process vertices in topological order to compute longest paths or earliest finish times.'],
    ],
    complexity: [
      ['Kahn\'s algorithm', 'O(V + E)'],
      ['DFS-based sort', 'O(V + E)'],
    ],
    patterns: [
      ['Can it be done? / In what order?', 'Course schedule I and II, build order.', 'Run Kahn\'s; success means the output contains every vertex.'],
      ['Three-colour DFS', 'Find eventual safe states, cycle detection.', 'White = unvisited, grey = on the stack, black = finished.'],
      ['Longest path in a DAG', 'Parallel courses III, longest increasing path in a matrix.', 'Relax edges in topological order, tracking the best value per vertex.'],
    ],
    code: {
      label: 'Course Schedule II — Kahn\'s algorithm',
      python: `from collections import deque


def find_order(num_courses, prerequisites):
    graph = [[] for _ in range(num_courses)]
    indegree = [0] * num_courses
    for course, pre in prerequisites:
        graph[pre].append(course)            # pre must come before course
        indegree[course] += 1
    queue = deque(i for i in range(num_courses) if indegree[i] == 0)
    order = []
    while queue:
        node = queue.popleft()
        order.append(node)
        for nxt in graph[node]:
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                queue.append(nxt)
    return order if len(order) == num_courses else []   # [] means a cycle`,
      cpp: `vector<int> findOrder(int numCourses, const vector<vector<int>>& prerequisites) {
    vector<vector<int>> graph(numCourses);
    vector<int> indegree(numCourses, 0);
    for (auto& p : prerequisites) {
        graph[p[1]].push_back(p[0]);         // p[1] must come before p[0]
        ++indegree[p[0]];
    }
    queue<int> q;
    for (int i = 0; i < numCourses; ++i) if (indegree[i] == 0) q.push(i);
    vector<int> order;
    while (!q.empty()) {
        int node = q.front(); q.pop();
        order.push_back(node);
        for (int nxt : graph[node])
            if (--indegree[nxt] == 0) q.push(nxt);
    }
    if ((int)order.size() != numCourses) return {};   // cycle
    return order;
}`,
    },
    pitfalls: [
      'Getting the edge direction backwards — write down "u must come before v" and draw u → v.',
      'Topological sort only applies to directed graphs.',
      'Vertices with no edges at all still belong in the order; seed the queue from every vertex.',
    ],
    problems: [
      ['find-the-town-judge', 'Find the Town Judge', 'E'],
      ['course-schedule', 'Course Schedule', 'M'],
      ['course-schedule-ii', 'Course Schedule II', 'M'],
      ['find-eventual-safe-states', 'Find Eventual Safe States', 'M'],
      ['minimum-height-trees', 'Minimum Height Trees', 'M'],
      ['parallel-courses-iii', 'Parallel Courses III', 'H'],
      ['longest-increasing-path-in-a-matrix', 'Longest Increasing Path in a Matrix', 'H'],
    ],
  },
  {
    id: 'union-find',
    orbit: 'graphs',
    title: 'Union-Find (Disjoint Set Union)',
    short: 'Union-Find',
    prereqs: ['graphs'],
    hours: 3,
    summary: 'Merge groups and ask "are these two connected?" in near-constant time. The engine behind Kruskal\'s MST and dynamic connectivity.',
    intro: [
      'Union-Find maintains a collection of disjoint groups. It supports two operations: find(x) returns a representative of x\'s group, and union(a, b) merges the groups containing a and b. Each group is stored as a tree of parent pointers, and the representative is the root.',
      'Two small optimisations make it astonishingly fast. Path compression flattens the tree every time you call find, and union by size (or rank) always hangs the smaller tree under the larger one. Together they bring the amortised cost to O(α(n)), where α is the inverse Ackermann function — at most 4 for any input that fits in the universe.',
    ],
    concepts: [
      ['Parent array', 'parent[x] = x means x is a root; otherwise follow parents to reach the root.'],
      ['Path compression', 'During find, point nodes directly (or closer) to the root so later finds are faster.'],
      ['Union by size/rank', 'Attach the smaller tree beneath the larger to keep trees shallow.'],
      ['Counting components', 'Start with n components and decrement on every successful union.'],
      ['Cycle detection in undirected graphs', 'If an edge connects two vertices already in the same group, it closes a cycle.'],
      ['Kruskal\'s MST', 'Sort edges by weight and add each one that joins two different groups.'],
    ],
    complexity: [
      ['find / union (both optimisations)', 'O(α(n)) amortised ≈ O(1)'],
      ['Without optimisations', 'O(n) per operation worst case'],
      ['Kruskal\'s MST', 'O(E log E) — dominated by sorting'],
    ],
    patterns: [
      ['Dynamic connectivity', 'Number of provinces, network connected, redundant connection.', 'Union every edge; query or count components afterwards.'],
      ['Equivalence grouping', 'Accounts merge, satisfiability of equations, similar strings.', 'Union things that are "equal", then check or collect groups by root.'],
      ['Minimum spanning tree', 'Min cost to connect all points.', 'Sort edges, union greedily, stop after V − 1 edges.'],
    ],
    code: {
      label: 'Disjoint Set Union with path compression and union by size',
      python: `class DSU:
    def __init__(self, n):
        self.parent = list(range(n))
        self.size = [1] * n
        self.components = n

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]   # path halving
            x = self.parent[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return False                 # already connected
        if self.size[ra] < self.size[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra             # smaller tree under larger
        self.size[ra] += self.size[rb]
        self.components -= 1
        return True`,
      cpp: `struct DSU {
    vector<int> parent, sz;
    int components;
    explicit DSU(int n) : parent(n), sz(n, 1), components(n) {
        iota(parent.begin(), parent.end(), 0);
    }
    int find(int x) {
        while (parent[x] != x) {
            parent[x] = parent[parent[x]];   // path halving
            x = parent[x];
        }
        return x;
    }
    bool unite(int a, int b) {
        int ra = find(a), rb = find(b);
        if (ra == rb) return false;
        if (sz[ra] < sz[rb]) swap(ra, rb);
        parent[rb] = ra;
        sz[ra] += sz[rb];
        --components;
        return true;
    }
};`,
    },
    pitfalls: [
      'Setting parent[a] = b instead of linking the roots corrupts the structure.',
      'Map non-integer identifiers (emails, strings) to integer ids first, or use a dictionary-based DSU.',
      'Union-Find answers connectivity in undirected graphs; it cannot handle edge deletions or directed reachability.',
    ],
    problems: [
      ['number-of-provinces', 'Number of Provinces', 'M'],
      ['redundant-connection', 'Redundant Connection', 'M'],
      ['accounts-merge', 'Accounts Merge', 'M'],
      ['number-of-operations-to-make-network-connected', 'Number of Operations to Make Network Connected', 'M'],
      ['satisfiability-of-equality-equations', 'Satisfiability of Equality Equations', 'M'],
      ['most-stones-removed-with-same-row-or-column', 'Most Stones Removed with Same Row or Column', 'M'],
    ],
  },
  {
    id: 'shortest-paths',
    orbit: 'graphs',
    title: 'Shortest Paths & Minimum Spanning Trees',
    short: 'Shortest Paths',
    prereqs: ['graphs', 'heaps', 'union-find'],
    hours: 6,
    summary: 'Dijkstra, Bellman-Ford, Floyd-Warshall and Prim/Kruskal — choosing the right algorithm based on edge weights and what you need to connect.',
    intro: [
      'Once edges have weights, BFS no longer finds shortest paths. Dijkstra\'s algorithm generalises it: instead of a plain queue it uses a min-heap keyed by distance, always settling the closest unsettled vertex next. It is correct as long as no edge weight is negative, and it runs in O((V + E) log V).',
      'Other situations call for other tools. Bellman-Ford tolerates negative edges, detects negative cycles and naturally limits paths to k edges. Floyd-Warshall computes all-pairs distances in O(V³) for small graphs. And when the goal is not a path but the cheapest set of edges connecting every vertex — a minimum spanning tree — Prim\'s (heap-based) or Kruskal\'s (Union-Find-based) algorithm applies.',
    ],
    concepts: [
      ['Edge relaxation', 'If dist[u] + w < dist[v], improve dist[v]. Every shortest-path algorithm is a strategy for ordering relaxations.'],
      ['Dijkstra\'s algorithm', 'Min-heap of (distance, vertex); skip stale entries; requires non-negative weights.'],
      ['Bellman-Ford', 'Relax all edges V − 1 times; a further improvement means a negative cycle. Running k rounds limits paths to k edges.'],
      ['Floyd-Warshall', 'dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]) for every intermediate k — O(V³) all pairs.'],
      ['0-1 BFS', 'With weights 0 and 1 only, a deque replaces the heap: push 0-edges to the front, 1-edges to the back.'],
      ['Minimum spanning trees', 'Prim grows one tree with a heap; Kruskal sorts edges and unions components.'],
    ],
    complexity: [
      ['BFS (unweighted)', 'O(V + E)'],
      ['Dijkstra with binary heap', 'O((V + E) log V)'],
      ['Bellman-Ford', 'O(V · E)'],
      ['Floyd-Warshall', 'O(V³) time, O(V²) space'],
      ['Prim / Kruskal MST', 'O(E log V) / O(E log E)'],
    ],
    patterns: [
      ['Single-source, non-negative', 'Network delay time, path with minimum effort.', 'Dijkstra; the "distance" can be any monotone cost, such as the maximum step so far.'],
      ['At most k edges', 'Cheapest flights within k stops.', 'Bellman-Ford for k + 1 rounds, copying the distance array each round.'],
      ['Connect everything cheaply', 'Min cost to connect all points.', 'Kruskal with Union-Find, or Prim with a heap on dense graphs.'],
    ],
    code: {
      label: 'Dijkstra\'s algorithm with a min-heap',
      python: `import heapq


def dijkstra(n, edges, source):
    graph = [[] for _ in range(n)]
    for u, v, w in edges:
        graph[u].append((v, w))
    dist = [float('inf')] * n
    dist[source] = 0
    heap = [(0, source)]
    while heap:
        d, u = heapq.heappop(heap)
        if d > dist[u]:
            continue                         # stale entry
        for v, w in graph[u]:
            if d + w < dist[v]:
                dist[v] = d + w
                heapq.heappush(heap, (dist[v], v))
    return dist`,
      cpp: `vector<long long> dijkstra(int n, const vector<array<int, 3>>& edges, int source) {
    vector<vector<pair<int, int>>> graph(n);
    for (auto& e : edges) graph[e[0]].push_back({e[1], e[2]});
    const long long INF = LLONG_MAX / 4;
    vector<long long> dist(n, INF);
    priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<>> heap;
    dist[source] = 0;
    heap.push({0, source});
    while (!heap.empty()) {
        auto [d, u] = heap.top(); heap.pop();
        if (d > dist[u]) continue;           // stale entry
        for (auto [v, w] : graph[u])
            if (d + w < dist[v]) {
                dist[v] = d + w;
                heap.push({dist[v], v});
            }
    }
    return dist;
}`,
    },
    pitfalls: [
      'Dijkstra gives wrong answers with negative edge weights.',
      'Forgetting to skip stale heap entries makes Dijkstra much slower.',
      'Using INT_MAX as infinity and then adding a weight overflows; use a large but safe sentinel.',
      'Problems often number vertices from 1 — size arrays accordingly.',
    ],
    problems: [
      ['network-delay-time', 'Network Delay Time', 'M'],
      ['shortest-path-in-binary-matrix', 'Shortest Path in Binary Matrix', 'M'],
      ['path-with-minimum-effort', 'Path With Minimum Effort', 'M'],
      ['cheapest-flights-within-k-stops', 'Cheapest Flights Within K Stops', 'M'],
      ['find-the-city-with-the-smallest-number-of-neighbors-at-a-threshold-distance', 'Find the City With the Smallest Number of Neighbors at a Threshold Distance', 'M'],
      ['min-cost-to-connect-all-points', 'Min Cost to Connect All Points', 'M'],
      ['swim-in-rising-water', 'Swim in Rising Water', 'H'],
    ],
  },
];
