// One 24×24 line icon per topic, drawn from the data structure or idea itself.
// Shared by the page generator (HTML) and the browser (3D map labels).
const P = (d) => `<path d="${d}"/>`;
const C = (cx, cy, r, fill = false) => `<circle cx="${cx}" cy="${cy}" r="${r}"${fill ? ' fill="currentColor"' : ''}/>`;
const R = (x, y, w, h, rx = 1.5, fill = false) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}"${fill ? ' fill="currentColor"' : ''}/>`;

export const TOPIC_ICONS = {
  complexity: P('M4 3v17h17') + P('M7 17c5-1 8-5 11-12') + P('M7 17c4 0 8-1 11-3'),
  'math-basics': P('M17 5H7l6 7-6 7h10'),
  arrays: R(2, 8, 5, 8, 1) + R(9.5, 8, 5, 8, 1) + R(17, 8, 5, 8, 1, true),
  strings: P('M4 18 8 6l4 12') + P('M5.5 14h5') + P('M15 9.5c1-1 4-1.2 4.6.6V18') + P('M19.6 13.5c-2-.4-4.6 0-4.6 2.2 0 2.4 3.4 2.4 4.6.3'),
  hashing: P('M9.5 4 7.5 20') + P('M16.5 4l-2 16') + P('M4 9h16') + P('M3 15h16'),
  recursion: R(3, 3, 18, 18, 3) + R(7, 7, 10, 10, 2) + R(10.5, 10.5, 3, 3, 1, true),
  'two-pointers': P('M3 19h18') + P('M6 4v10') + P('M3.5 11.5 6 14l2.5-2.5') + P('M18 4v10') + P('M15.5 11.5 18 14l2.5-2.5'),
  'sliding-window': P('M2 10h20') + P('M2 16h20') + P('M6 10v6') + P('M10 10v6') + P('M14 10v6') + P('M18 10v6') + R(8.5, 7, 11, 12, 2),
  'prefix-sums': P('M5 20v-4') + P('M10 20v-8') + P('M15 20v-11') + P('M20 20V4'),
  'binary-search': C(10.5, 10.5, 6.5) + P('M15.5 15.5 21 21') + P('M10.5 7v7'),
  sorting: P('M4 6h16') + P('M4 12h11') + P('M4 18h6') + P('M18 13v7') + P('M15.5 17.5 18 20l2.5-2.5'),
  intervals: P('M3 9h11') + P('M10 15h11') + P('M3 6v6') + P('M14 6v6') + P('M10 12v6') + P('M21 12v6'),
  'linked-lists': C(4.5, 12, 2.5) + C(12, 12, 2.5) + C(19.5, 12, 2.5, true) + P('M7 12h2.5') + P('M14.5 12H17'),
  stacks: R(5, 15, 14, 5, 1.5) + R(5, 9.5, 14, 5, 1.5) + R(5, 4, 14, 5, 1.5, true),
  queues: R(2, 8, 4.5, 8, 1, true) + R(8, 8, 4.5, 8, 1) + R(14, 8, 4.5, 8, 1) + P('M19.5 12H23') + P('M21 10l2 2-2 2'),
  'binary-trees': C(12, 5, 2.5, true) + C(6, 18, 2.5) + C(18, 18, 2.5) + P('M10.6 7 7.3 15.8') + P('M13.4 7l3.3 8.8'),
  bst: C(12, 5, 2.5) + C(6, 18, 2) + C(18, 18, 3, true) + P('M10.6 7 7 16') + P('M13.4 7l3.2 8.4'),
  heaps: P('M12 3 21 20H3Z') + C(12, 9, 2, true),
  tries: C(12, 4, 2.2, true) + P('M12 6.2V11') + P('M12 11 5 15') + P('M12 11v5') + P('M12 11l7 4') + C(5, 17, 1.8) + C(12, 18, 1.8) + C(19, 17, 1.8),
  graphs: C(5, 6, 2.2) + C(19, 5, 2.2) + C(12, 13, 2.4, true) + C(5, 19, 2.2) + C(19, 19, 2.2) + P('M6.8 7.3 10.2 11.6') + P('M17.4 6.6 13.7 11.4') + P('M10.4 14.7 6.6 17.6') + P('M14 14.6l3.4 3') + P('M7.2 6h9.6'),
  'topological-sort': R(2, 9, 5, 6, 1.5, true) + R(9.5, 9, 5, 6, 1.5) + R(17, 9, 5, 6, 1.5) + P('M7 12h2.5') + P('M14.5 12H17') + P('M4.5 9C6 3 18 3 19.5 9'),
  'union-find': C(9, 12, 6) + C(15, 12, 6),
  'shortest-paths': C(5, 18, 2.5, true) + P('M19 3.5c-2.5 0-4 1.8-4 4 0 3 4 6.5 4 6.5s4-3.5 4-6.5c0-2.2-1.5-4-4-4Z') + P('M7.5 18H13c3 0 3-4 0-4H9c-3 0-3-3.5 0-3.5h2'),
  backtracking: P('M12 21V13') + P('M12 13 6 6') + P('M12 13l6-7') + P('M4 4l4 4') + P('M8 4 4 8') + C(18, 5, 2, true),
  greedy: C(12, 13, 7) + C(12, 13, 3.5) + P('M12 2v4') + P('M9.5 4.5 12 2l2.5 2.5'),
  'dp-1d': P('M3 20h5v-5h5v-5h5V5h3'),
  'dp-2d': R(3, 3, 18, 18, 2) + P('M3 9h18') + P('M3 15h18') + P('M9 3v18') + P('M15 3v18') + R(15, 15, 6, 6, 0, true),
  'bit-manipulation': R(2.5, 5, 8, 14, 4) + P('M17 5v14') + P('M14.5 7.5 17 5'),
  'range-queries': P('M3 5h18') + P('M3 11h8') + P('M13 11h8') + P('M3 17h3.5') + P('M8.5 17h2.5') + P('M13 17h3.5') + P('M18.5 17H21'),
};

export function topicIcon(id, size = 24, extra = '') {
  return `<svg class="ti" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"${extra}>${TOPIC_ICONS[id] || ''}</svg>`;
}

/** Orbi, the site mascot: a round little probe with an orbit ring for an antenna. */
export function mascot(size = 48, cls = 'mascot') {
  return `<svg class="${cls}" viewBox="0 0 64 64" width="${size}" height="${size}" aria-hidden="true">
<line x1="32" y1="14" x2="32" y2="6.5" stroke="#101218" stroke-width="2.6" stroke-linecap="round"/>
<ellipse cx="32" cy="6" rx="7" ry="2.5" fill="none" stroke="#3e5bd8" stroke-width="2.2"/>
<circle cx="32" cy="6" r="2.4" fill="#3e5bd8"/>
<circle cx="32" cy="36" r="22" fill="#f6c54a" stroke="#101218" stroke-width="2.6"/>
<path d="M15 42.5c6 7.5 28 7.5 34 0" fill="none" stroke="#d49a1c" stroke-width="2.6" stroke-linecap="round" opacity=".5"/>
<ellipse cx="24.5" cy="33" rx="3.2" ry="4.4" fill="#101218"/>
<ellipse cx="39.5" cy="33" rx="3.2" ry="4.4" fill="#101218"/>
<circle cx="25.5" cy="31.4" r="1.1" fill="#fff"/>
<circle cx="40.5" cy="31.4" r="1.1" fill="#fff"/>
<path d="M28.2 42.4c2.3 1.8 5.3 1.8 7.6 0" fill="none" stroke="#101218" stroke-width="2.4" stroke-linecap="round"/>
</svg>`;
}

export const UI_ICONS = {
  flame: '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M12 2c1 4 6 6.5 6 12a6 6 0 0 1-12 0c0-3 1.6-4.8 3-6 .2 2 1 3 2.2 3.4C11 8.5 11 5 12 2Z" fill="#e2703c"/><path d="M12 12c.5 2 3 3 3 5.2a3 3 0 0 1-6 0c0-1.6 1-2.6 2-3.2.2.9.6 1.4 1 1.6-.3-1.3-.4-2.4 0-3.6Z" fill="#f2c25a"/></svg>',
  coin: '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><circle cx="12" cy="12" r="9.5" fill="#e9b949" stroke="#b98316" stroke-width="1.6"/><path d="M12 7v10M9.5 9.5h4a1.8 1.8 0 0 1 0 3.5h-3a1.8 1.8 0 0 0 0 3.5h4" fill="none" stroke="#7d570c" stroke-width="1.8" stroke-linecap="round"/></svg>',
  star: '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="m12 2.8 2.8 5.8 6.3.9-4.6 4.4 1.1 6.3L12 17.2l-5.6 3 1.1-6.3L2.9 9.5l6.3-.9Z" fill="#e9b949" stroke="#b98316" stroke-width="1.4" stroke-linejoin="round"/></svg>',
  lock: '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
};
