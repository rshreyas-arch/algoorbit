export default [
  {
    id: 'backtracking',
    orbit: 'mastery',
    title: 'Backtracking',
    short: 'Backtracking',
    prereqs: ['recursion', 'binary-trees'],
    hours: 6,
    summary: 'Build solutions one choice at a time and undo choices that lead nowhere. The systematic way to generate subsets, permutations and puzzle solutions.',
    intro: [
      'Backtracking explores a tree of decisions. At each step you make a choice, recurse to make the rest, and then undo the choice so the next option starts from a clean state. Subsets, permutations, combinations, N-Queens and Sudoku are all walks through such a tree.',
      'The output of these problems is often exponential in size, so the goal is not a polynomial algorithm but an efficient search: generate each candidate exactly once, avoid duplicates, and prune branches early when they cannot possibly succeed. Good pruning is the difference between an instant answer and a timeout.',
    ],
    concepts: [
      ['Choose → explore → un-choose', 'Append a choice to the path, recurse, then pop it — the path always reflects the current branch.'],
      ['The decision tree', 'Each level is a decision; each leaf is a candidate. Its size tells you the complexity.'],
      ['Subsets vs combinations vs permutations', 'Subsets: include/exclude each item. Combinations: pass a start index. Permutations: track which items are used.'],
      ['Handling duplicates', 'Sort first, then skip an item equal to the previous one at the same tree level.'],
      ['Pruning', 'Stop exploring as soon as the partial solution is invalid or cannot reach the target.'],
      ['Constraint satisfaction', 'N-Queens and Sudoku keep sets of used columns/diagonals/boxes for O(1) validity checks.'],
    ],
    complexity: [
      ['All subsets', 'O(n · 2ⁿ)'],
      ['All permutations', 'O(n · n!)'],
      ['Combinations of size k', 'O(k · C(n, k))'],
    ],
    patterns: [
      ['Subsets / combinations', 'Subsets, combination sum, letter combinations.', 'Loop i from start; recurse with i + 1 (or i if reuse is allowed).'],
      ['Permutations', 'Permutations, next arrangement, anagram generation.', 'Loop over all items; skip those already used in the path.'],
      ['Grid search', 'Word search, N-Queens, Sudoku.', 'Mark a cell or position as used before recursing and unmark it afterwards.'],
    ],
    code: {
      label: 'Combination Sum — reuse allowed, pruned by sorting',
      python: `def combination_sum(candidates, target):
    candidates.sort()
    result, path = [], []

    def backtrack(start, remaining):
        if remaining == 0:
            result.append(path[:])          # copy the current path
            return
        for i in range(start, len(candidates)):
            if candidates[i] > remaining:
                break                       # sorted, so the rest are too big
            path.append(candidates[i])      # choose
            backtrack(i, remaining - candidates[i])   # i: reuse allowed
            path.pop()                      # un-choose

    backtrack(0, target)
    return result`,
      cpp: `class CombinationSum {
    vector<vector<int>> result;
    vector<int> path;
    void backtrack(const vector<int>& c, int start, int remaining) {
        if (remaining == 0) { result.push_back(path); return; }
        for (int i = start; i < (int)c.size(); ++i) {
            if (c[i] > remaining) break;    // sorted, so the rest are too big
            path.push_back(c[i]);           // choose
            backtrack(c, i, remaining - c[i]);
            path.pop_back();                // un-choose
        }
    }
public:
    vector<vector<int>> solve(vector<int> candidates, int target) {
        sort(candidates.begin(), candidates.end());
        backtrack(candidates, 0, target);
        return result;
    }
};`,
    },
    pitfalls: [
      'Appending the path itself instead of a copy — every saved answer then changes as the path does.',
      'Forgetting to undo a choice (pop, unmark) corrupts sibling branches.',
      'Skipping duplicates across levels instead of within one level drops valid answers.',
    ],
    problems: [
      ['binary-watch', 'Binary Watch', 'E'],
      ['subsets', 'Subsets', 'M'],
      ['permutations', 'Permutations', 'M'],
      ['combination-sum', 'Combination Sum', 'M'],
      ['subsets-ii', 'Subsets II', 'M'],
      ['letter-combinations-of-a-phone-number', 'Letter Combinations of a Phone Number', 'M'],
      ['word-search', 'Word Search', 'M'],
      ['palindrome-partitioning', 'Palindrome Partitioning', 'M'],
      ['n-queens', 'N-Queens', 'H'],
      ['sudoku-solver', 'Sudoku Solver', 'H'],
    ],
  },
  {
    id: 'greedy',
    orbit: 'mastery',
    title: 'Greedy Algorithms',
    short: 'Greedy',
    prereqs: ['sorting', 'heaps'],
    hours: 4,
    summary: 'Make the locally best choice and never look back. Fast and simple — when you can prove it works.',
    intro: [
      'A greedy algorithm builds a solution step by step, always taking the option that looks best right now. When it works, it is usually the simplest and fastest solution available: one pass, sometimes after a sort. The jump game, gas station and interval scheduling problems all have elegant greedy answers.',
      'The danger is that greedy choices can be wrong. Paying 30 with coins {1, 15, 25} greedily uses 25 + 1×5 = six coins, while 15 + 15 uses two. The habit to build is a quick proof: an exchange argument (swapping any optimal solution\'s choice for the greedy one never makes it worse) or a "greedy stays ahead" argument. If you cannot find one, consider dynamic programming.',
    ],
    concepts: [
      ['Greedy choice property', 'A globally optimal solution can be reached by making a locally optimal choice at each step.'],
      ['Exchange argument', 'Show that replacing an optimal solution\'s choice with the greedy choice never hurts.'],
      ['Sort, then decide', 'Many greedy solutions sort by deadline, end time, ratio or size first.'],
      ['Track the frontier', 'Jump games keep the farthest reachable index instead of exploring every path.'],
      ['Two-pass greedy', 'Some constraints come from both sides (candy distribution) — sweep left-to-right, then right-to-left.'],
      ['When greedy fails', 'Coin change with arbitrary denominations and 0/1 knapsack need DP.'],
    ],
    complexity: [
      ['Single pass', 'O(n)'],
      ['Sort then pass', 'O(n log n)'],
      ['Greedy with a heap', 'O(n log n)'],
    ],
    patterns: [
      ['Reachability frontier', 'Jump game I and II, video stitching.', 'Track the farthest index reachable; count a jump each time you pass the current frontier.'],
      ['Running balance', 'Gas station, lemonade change.', 'Track a running surplus; reset the start point when it goes negative.'],
      ['Sort and match', 'Assign cookies, boats to save people, hand of straights.', 'Sort both sides and pair smallest-with-smallest (or largest-with-smallest) using pointers.'],
    ],
    code: {
      label: 'Jump Game II — minimum jumps with a frontier',
      python: `def jump(nums):
    jumps = 0
    current_end = farthest = 0
    for i in range(len(nums) - 1):
        farthest = max(farthest, i + nums[i])
        if i == current_end:            # must jump to go further
            jumps += 1
            current_end = farthest
    return jumps`,
      cpp: `int jump(const vector<int>& nums) {
    int jumps = 0, currentEnd = 0, farthest = 0;
    for (int i = 0; i + 1 < (int)nums.size(); ++i) {
        farthest = max(farthest, i + nums[i]);
        if (i == currentEnd) {          // must jump to go further
            ++jumps;
            currentEnd = farthest;
        }
    }
    return jumps;
}`,
    },
    pitfalls: [
      'Trusting a greedy idea that only works on the sample — try to break it with a small counter-example first.',
      'Sorting by the wrong key (start time instead of end time in interval scheduling).',
      'Ties can matter; decide how equal keys should be ordered.',
    ],
    problems: [
      ['assign-cookies', 'Assign Cookies', 'E'],
      ['lemonade-change', 'Lemonade Change', 'E'],
      ['jump-game', 'Jump Game', 'M'],
      ['jump-game-ii', 'Jump Game II', 'M'],
      ['gas-station', 'Gas Station', 'M'],
      ['partition-labels', 'Partition Labels', 'M'],
      ['hand-of-straights', 'Hand of Straights', 'M'],
      ['candy', 'Candy', 'H'],
    ],
  },
  {
    id: 'dp-1d',
    orbit: 'mastery',
    title: 'Dynamic Programming I (1D)',
    short: 'DP 1D',
    prereqs: ['recursion', 'greedy'],
    hours: 8,
    summary: 'Solve each subproblem once and reuse the answer. Learn to define states and recurrences on one-dimensional problems.',
    intro: [
      'Dynamic programming applies when a problem breaks into overlapping subproblems — the same smaller question is asked again and again — and the best answer can be built from best answers to those subproblems. Instead of recomputing, you store each answer once. Climbing stairs, house robber and coin change are the classic first examples.',
      'Every DP solution has the same four parts: a state (what dp[i] means, in words), a recurrence (how dp[i] is computed from smaller states), base cases, and an evaluation order. You can write it top-down as recursion with memoisation, or bottom-up as a loop filling a table. If dp[i] only depends on the last few values, you can keep just those and use O(1) space.',
    ],
    concepts: [
      ['Overlapping subproblems', 'The naive recursion solves the same inputs repeatedly — the signal that caching will help.'],
      ['Defining the state', 'Write a sentence: "dp[i] = the fewest coins needed to make amount i." Most DP bugs are unclear states.'],
      ['Recurrence relation', 'Express dp[i] using smaller states, usually by considering the last decision made.'],
      ['Top-down vs bottom-up', 'Memoised recursion is easier to derive; iterative tables avoid recursion limits and are often faster.'],
      ['Space optimisation', 'When dp[i] depends only on dp[i − 1] and dp[i − 2], keep two variables instead of an array.'],
      ['Longest increasing subsequence', 'O(n²) DP, or O(n log n) by binary searching a "tails" array.'],
    ],
    complexity: [
      ['General', 'O(number of states × work per state)'],
      ['Climbing stairs / house robber', 'O(n) time, O(1) space'],
      ['Coin change', 'O(amount × coins)'],
      ['LIS', 'O(n²) or O(n log n)'],
    ],
    patterns: [
      ['Fibonacci-style', 'Climbing stairs, house robber, decode ways.', 'dp[i] combines dp[i − 1] and dp[i − 2] depending on the choice at step i.'],
      ['Unbounded choices', 'Coin change, word break, perfect squares.', 'For each target value, try every option that fits and take the best.'],
      ['Best ending here', 'Longest increasing subsequence, maximum product subarray.', 'dp[i] = best answer for sequences ending exactly at index i.'],
    ],
    code: {
      label: 'House Robber (O(1) space) and Coin Change',
      python: `def rob(nums):
    take = skip = 0                  # best if we rob / skip the previous house
    for x in nums:
        take, skip = skip + x, max(take, skip)
    return max(take, skip)


def coin_change(coins, amount):
    INF = amount + 1
    dp = [0] + [INF] * amount        # dp[a] = fewest coins to make a
    for a in range(1, amount + 1):
        for c in coins:
            if c <= a:
                dp[a] = min(dp[a], dp[a - c] + 1)
    return dp[amount] if dp[amount] <= amount else -1`,
      cpp: `int rob(const vector<int>& nums) {
    int take = 0, skip = 0;          // best if we rob / skip the previous house
    for (int x : nums) {
        int newTake = skip + x;
        skip = max(take, skip);
        take = newTake;
    }
    return max(take, skip);
}

int coinChange(const vector<int>& coins, int amount) {
    const int INF = amount + 1;
    vector<int> dp(amount + 1, INF); // dp[a] = fewest coins to make a
    dp[0] = 0;
    for (int a = 1; a <= amount; ++a)
        for (int c : coins)
            if (c <= a) dp[a] = min(dp[a], dp[a - c] + 1);
    return dp[amount] <= amount ? dp[amount] : -1;
}`,
    },
    pitfalls: [
      'Starting to code before writing down what the state means.',
      'Wrong base cases — dp[0] for "make amount 0" is 0 coins, not infinity.',
      'Using INT_MAX as infinity and then adding 1 overflows.',
      'Filling the table in an order where dp[i] is read before it is computed.',
    ],
    problems: [
      ['climbing-stairs', 'Climbing Stairs', 'E'],
      ['min-cost-climbing-stairs', 'Min Cost Climbing Stairs', 'E'],
      ['house-robber', 'House Robber', 'M'],
      ['house-robber-ii', 'House Robber II', 'M'],
      ['coin-change', 'Coin Change', 'M'],
      ['decode-ways', 'Decode Ways', 'M'],
      ['word-break', 'Word Break', 'M'],
      ['longest-increasing-subsequence', 'Longest Increasing Subsequence', 'M'],
      ['longest-valid-parentheses', 'Longest Valid Parentheses', 'H'],
    ],
  },
  {
    id: 'dp-2d',
    orbit: 'mastery',
    title: 'Dynamic Programming II (2D, Knapsack, Strings)',
    short: 'DP 2D',
    prereqs: ['dp-1d'],
    hours: 8,
    summary: 'Grid paths, knapsack, longest common subsequence and edit distance — DP where the state needs two indices.',
    intro: [
      'Many problems need two numbers to describe a subproblem: a position in two different strings, a row and a column of a grid, or an item index and a remaining capacity. The table becomes two-dimensional, but the method is unchanged — define the state, find the recurrence from the last decision, set base cases, and fill the table in a valid order.',
      'Three families cover most interview questions. Grid DP counts or optimises paths. Two-sequence DP compares strings character by character (LCS, edit distance). Knapsack DP decides, for each item, whether to take it given a budget — and with the right loop direction its table compresses to one dimension.',
    ],
    concepts: [
      ['Grid DP', 'dp[r][c] depends on the cells above and to the left — unique paths, minimum path sum.'],
      ['Two-sequence DP', 'dp[i][j] describes prefixes a[:i] and b[:j]; compare a[i − 1] with b[j − 1].'],
      ['Longest common subsequence', 'Match → 1 + dp[i − 1][j − 1]; otherwise max(dp[i − 1][j], dp[i][j − 1]).'],
      ['Edit distance', 'Insert, delete or replace — take the cheapest of three neighbours plus one.'],
      ['0/1 knapsack', 'Each item used at most once: in 1D, iterate the capacity from high to low so items are not reused.'],
      ['Unbounded knapsack and interval DP', 'Iterate capacity upward to allow reuse (coin change II); interval DP (burst balloons) builds answers on ranges [i, j] from shorter ranges.'],
    ],
    complexity: [
      ['Grid / two-sequence DP', 'O(m · n) time, O(min(m, n)) space possible'],
      ['0/1 knapsack', 'O(n · capacity)'],
      ['Interval DP', 'O(n³) typically'],
    ],
    patterns: [
      ['Paths in a grid', 'Unique paths, minimum path sum, dungeon game.', 'Fill row by row; the first row and column are base cases.'],
      ['Compare two strings', 'LCS, edit distance, distinct subsequences.', 'Table of size (m + 1) × (n + 1) with empty-prefix base cases.'],
      ['Subset sum / knapsack', 'Partition equal subset sum, target sum, coin change II.', 'dp[c] = whether (or how many ways) capacity c can be reached; mind the loop direction.'],
    ],
    code: {
      label: 'Edit distance',
      python: `def min_distance(a, b):
    m, n = len(a), len(b)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1):
        dp[i][0] = i                 # delete everything
    for j in range(n + 1):
        dp[0][j] = j                 # insert everything
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if a[i - 1] == b[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(dp[i - 1][j],      # delete
                                   dp[i][j - 1],      # insert
                                   dp[i - 1][j - 1])  # replace
    return dp[m][n]`,
      cpp: `int minDistance(const string& a, const string& b) {
    int m = a.size(), n = b.size();
    vector<vector<int>> dp(m + 1, vector<int>(n + 1, 0));
    for (int i = 0; i <= m; ++i) dp[i][0] = i;   // delete everything
    for (int j = 0; j <= n; ++j) dp[0][j] = j;   // insert everything
    for (int i = 1; i <= m; ++i)
        for (int j = 1; j <= n; ++j)
            dp[i][j] = (a[i - 1] == b[j - 1])
                ? dp[i - 1][j - 1]
                : 1 + min({dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]});
    return dp[m][n];
}`,
    },
    pitfalls: [
      'Off-by-one between table indices (prefix length) and string indices (i − 1).',
      'Iterating knapsack capacity in the wrong direction silently switches between 0/1 and unbounded.',
      'Allocating a full 2D table when only the previous row is needed can exceed memory limits.',
    ],
    problems: [
      ['pascals-triangle', 'Pascal\'s Triangle', 'E'],
      ['unique-paths', 'Unique Paths', 'M'],
      ['minimum-path-sum', 'Minimum Path Sum', 'M'],
      ['longest-common-subsequence', 'Longest Common Subsequence', 'M'],
      ['partition-equal-subset-sum', 'Partition Equal Subset Sum', 'M'],
      ['target-sum', 'Target Sum', 'M'],
      ['coin-change-ii', 'Coin Change II', 'M'],
      ['edit-distance', 'Edit Distance', 'M'],
      ['longest-palindromic-subsequence', 'Longest Palindromic Subsequence', 'M'],
      ['burst-balloons', 'Burst Balloons', 'H'],
      ['regular-expression-matching', 'Regular Expression Matching', 'H'],
    ],
  },
  {
    id: 'bit-manipulation',
    orbit: 'mastery',
    title: 'Bit Manipulation',
    short: 'Bits',
    prereqs: ['math-basics'],
    hours: 3,
    summary: 'Work directly with binary: XOR tricks, counting bits, masks and subset enumeration — tiny code, big speedups.',
    intro: [
      'Every integer is a row of bits, and processors operate on all of them at once. Bitwise operators — AND, OR, XOR, NOT and shifts — let you test, set and clear individual bits in O(1), pack a set of up to 64 flags into one number, and spot patterns that are invisible in decimal.',
      'A few identities do most of the work. x ^ x = 0 and x ^ 0 = x, so XOR-ing a list cancels every pair and leaves the odd one out. x & (x − 1) removes the lowest set bit, so a loop of it counts set bits. And the integers from 0 to 2ⁿ − 1, read as bitmasks, enumerate every subset of n items.',
    ],
    concepts: [
      ['Binary and two\'s complement', 'Negative numbers are stored as ~x + 1; the highest bit is the sign in fixed-width integers.'],
      ['The operators', '&, |, ^, ~, << and >>; test bit i with (x >> i) & 1, set it with x | (1 << i), clear it with x & ~(1 << i).'],
      ['XOR cancellation', 'Pairs cancel to 0 — find the single number, the missing number, or swap without a temporary.'],
      ['Lowest set bit', 'x & (x − 1) clears it; x & −x isolates it (the basis of Fenwick trees).'],
      ['Counting bits', 'Kernighan\'s loop, or bits[i] = bits[i >> 1] + (i & 1) for all numbers up to n.'],
      ['Bitmasks as sets', 'Represent subsets of ≤ 20 items as integers to enumerate or use as DP states.'],
    ],
    complexity: [
      ['Any single bitwise operation', 'O(1)'],
      ['Count set bits (Kernighan)', 'O(number of set bits)'],
      ['Enumerate all subsets of n', 'O(2ⁿ)'],
    ],
    patterns: [
      ['XOR to cancel pairs', 'Single number, missing number, find the difference.', 'XOR everything together; duplicates disappear.'],
      ['Bit-by-bit construction', 'Reverse bits, single number II, sum of two integers.', 'Process bit positions 0..31 independently and rebuild the answer.'],
      ['Mask enumeration', 'Subsets, maximum product of word lengths.', 'Encode each item\'s properties as a mask; compare with a single AND.'],
    ],
    code: {
      label: 'Single Number and Counting Bits',
      python: `def single_number(nums):
    result = 0
    for x in nums:
        result ^= x              # pairs cancel out
    return result


def count_bits(n):
    bits = [0] * (n + 1)
    for i in range(1, n + 1):
        bits[i] = bits[i >> 1] + (i & 1)
    return bits`,
      cpp: `int singleNumber(const vector<int>& nums) {
    int result = 0;
    for (int x : nums) result ^= x;  // pairs cancel out
    return result;
}

vector<int> countBits(int n) {
    vector<int> bits(n + 1, 0);
    for (int i = 1; i <= n; ++i) bits[i] = bits[i >> 1] + (i & 1);
    return bits;
}`,
    },
    pitfalls: [
      'Operator precedence: in C++/Java, <code>x &amp; 1 == 0</code> means <code>x &amp; (1 == 0)</code> — always parenthesise.',
      'Python integers are unbounded, so negative numbers never "wrap"; mask with 0xFFFFFFFF to emulate 32-bit behaviour.',
      'Shifting a 32-bit int by 32 or more is undefined in C++; use <code>1LL &lt;&lt; i</code> for large i.',
    ],
    problems: [
      ['single-number', 'Single Number', 'E'],
      ['number-of-1-bits', 'Number of 1 Bits', 'E'],
      ['counting-bits', 'Counting Bits', 'E'],
      ['reverse-bits', 'Reverse Bits', 'E'],
      ['single-number-ii', 'Single Number II', 'M'],
      ['sum-of-two-integers', 'Sum of Two Integers', 'M'],
      ['bitwise-and-of-numbers-range', 'Bitwise AND of Numbers Range', 'M'],
      ['maximum-product-of-word-lengths', 'Maximum Product of Word Lengths', 'M'],
    ],
  },
  {
    id: 'range-queries',
    orbit: 'mastery',
    title: 'Range Queries: Fenwick & Segment Trees',
    short: 'Range Queries',
    prereqs: ['prefix-sums', 'binary-trees', 'bit-manipulation'],
    hours: 6,
    summary: 'When the array keeps changing, prefix sums break. Fenwick and segment trees answer range queries and updates in O(log n).',
    intro: [
      'Prefix sums answer range-sum queries instantly — until a single element changes and the whole prefix array must be rebuilt. Range-query trees fix this by storing partial aggregates over blocks of the array so that both a point update and a range query touch only O(log n) blocks.',
      'A Fenwick tree (binary indexed tree) is a remarkably short structure for prefix sums with updates, built entirely on the lowest-set-bit trick. A segment tree is more general: each node stores an aggregate (sum, min, max, gcd) for a segment, and with lazy propagation it also supports updating whole ranges at once. These appear in harder interview rounds and constantly in competitive programming.',
    ],
    concepts: [
      ['Why prefix sums are not enough', 'An update at index i invalidates every prefix after i — O(n) per update.'],
      ['Fenwick tree', 'tree[i] covers a block whose length is the lowest set bit of i; update and query walk i ± (i & −i).'],
      ['Segment tree', 'A binary tree over index ranges; a query combines O(log n) nodes that exactly cover [l, r].'],
      ['Choosing the aggregate', 'Any associative operation works: sum, min, max, gcd, XOR.'],
      ['Lazy propagation', 'Defer range updates at a node until a query or update needs to go below it.'],
      ['Coordinate compression', 'Map large or sparse values to ranks 0..n−1 so they can index a tree (count smaller numbers after self).'],
    ],
    complexity: [
      ['Fenwick: update / prefix query', 'O(log n)'],
      ['Segment tree: build', 'O(n)'],
      ['Segment tree: update / query', 'O(log n)'],
      ['Range update with lazy propagation', 'O(log n)'],
    ],
    patterns: [
      ['Point update, range query', 'Range sum query – mutable.', 'Fenwick tree for sums; segment tree for min/max.'],
      ['Counting with a BIT', 'Count of smaller numbers after self, reverse pairs, inversions.', 'Compress values, scan the array, query how many earlier values fall in a range, then add the current one.'],
      ['Range update', 'Booking counts, falling squares.', 'Segment tree with lazy tags, or a Fenwick tree over a difference array.'],
    ],
    code: {
      label: 'Fenwick tree (binary indexed tree)',
      python: `class Fenwick:
    def __init__(self, n):
        self.tree = [0] * (n + 1)

    def add(self, i, delta):            # a[i] += delta, 0-indexed
        i += 1
        while i < len(self.tree):
            self.tree[i] += delta
            i += i & -i

    def prefix(self, i):                # sum of a[0:i]
        total = 0
        while i > 0:
            total += self.tree[i]
            i -= i & -i
        return total

    def range_sum(self, left, right):   # sum of a[left..right]
        return self.prefix(right + 1) - self.prefix(left)`,
      cpp: `struct Fenwick {
    vector<long long> tree;
    explicit Fenwick(int n) : tree(n + 1, 0) {}
    void add(int i, long long delta) {          // a[i] += delta, 0-indexed
        for (++i; i < (int)tree.size(); i += i & -i) tree[i] += delta;
    }
    long long prefix(int i) const {             // sum of a[0, i)
        long long total = 0;
        for (; i > 0; i -= i & -i) total += tree[i];
        return total;
    }
    long long rangeSum(int left, int right) const {   // sum of a[left..right]
        return prefix(right + 1) - prefix(left);
    }
};`,
    },
    pitfalls: [
      'Fenwick trees are 1-indexed internally; mixing conventions causes infinite loops at index 0.',
      'Segment-tree arrays need about 4n slots when built recursively.',
      'For an update that sets a value (rather than adds), add the difference from the old value.',
    ],
    problems: [
      ['range-sum-query-mutable', 'Range Sum Query – Mutable', 'M'],
      ['corporate-flight-bookings', 'Corporate Flight Bookings', 'M'],
      ['count-of-smaller-numbers-after-self', 'Count of Smaller Numbers After Self', 'H'],
      ['reverse-pairs', 'Reverse Pairs', 'H'],
      ['count-of-range-sum', 'Count of Range Sum', 'H'],
      ['my-calendar-iii', 'My Calendar III', 'H'],
      ['falling-squares', 'Falling Squares', 'H'],
    ],
  },
];
