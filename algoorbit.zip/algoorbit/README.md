# AlgoOrbit

A free, gamified DSA roadmap with a 3D map and an AI tutor.

- **29 topics in 6 orbits** — Big-O to segment trees, each with concepts, a complexity cheat sheet, patterns, tested Python + C++ templates, common mistakes and 4–11 LeetCode practice problems (221 total).
- **3D island map** (Three.js) — six floating worlds, one tile per level; cleared levels turn gold and Orbi the mascot marks your next one. List view for accessibility.
- **Quick checks** — three multiple-choice questions on every topic (87 in all) with an explanation for each answer; all three right earns XP.
- **Practice sheet** (`/practice/`) — all 221 problems in one list, filterable by name, difficulty and solved status.
- **Search** — press `/` or Ctrl+K anywhere to find a level, concept, pattern or problem.
- **XP, levels and streaks** — derived from progress rows, so there's no score anyone can inflate.
- **Accounts** — email/password and Google sign-in via Supabase Auth; guest progress merges into the account on first sign-in.
- **AI tutor** — Hint / Explain / Review modes, streamed from Claude through a server function with per-user daily limits.
- **AdSense-ready** — pre-rendered content pages, sitemap, robots.txt, ads.txt, privacy/terms/about/contact pages, ad slots only on content pages.

**To put it online, follow [LAUNCH.md](LAUNCH.md).**

## Stack

| Layer | Choice |
| --- | --- |
| Pages | Static HTML generated from `web/src/content/*` by `scripts/generate.mjs`, bundled by Vite |
| 3D | Three.js (`web/src/js/world-scene.js`) |
| Auth + DB | Supabase (Postgres with Row Level Security) — `supabase/schema.sql` |
| API | Serverless functions — `netlify/functions/` (or `api/` on Vercel), shared code in `server/` |
| Hosting | Netlify (`netlify.toml`) — free plan allows ads. `vercel.json` included as an alternative. |
| AI | Anthropic Claude (`claude-haiku-5-5` by default) |

## Develop

```bash
npm install
cp .env.example .env     # fill in what you have; the site works without any keys (guest mode)
npm run dev              # http://localhost:5173 — /api/* routes run locally too
npm test                 # content, database security (embedded Postgres) and API tests
npm run build            # → dist/
```

## Project layout

```
web/src/content/     topic articles and quizzes.js (edit these to change the curriculum)
web/src/js/          browser code: store.js (auth + progress), world-scene.js (3D), pages/*
web/src/styles/      single stylesheet
scripts/             page generator (HTML, sitemap, robots, ads.txt)
server/              AI tutor + account deletion handlers (Request → Response)
netlify/functions/   Netlify wrappers      api/  Vercel wrappers
supabase/schema.sql  tables, RLS policies, quota functions
tests/               node:test suites
```

## Security notes

- Every table has Row Level Security; users can only read/insert/delete their own rows. `tests/schema.test.mjs` attacks the schema with Supabase-like roles to prove it.
- The secret Supabase key and the Anthropic key exist only in server env vars. Nothing with those values is prefixed `VITE_`.
- The tutor endpoint verifies the Supabase session, checks the request origin, validates and size-limits input, and enforces a daily quota atomically in Postgres.
- Account/auth pages send a strict Content-Security-Policy. Content pages use a looser one so AdSense can run (see `netlify.toml`).
- Model output is rendered through DOMPurify.
