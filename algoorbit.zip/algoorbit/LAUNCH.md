# Launch guide

Everything in the code is done. These steps need your own accounts, so you do them — roughly 1–2 hours, plus waiting time for Google. Do them in order.

| You'll need | Cost |
| --- | --- |
| GitHub account | Free |
| Supabase project (auth + database) | Free tier is enough to start |
| Netlify account (hosting) | Free plan — allows ads and commercial use |
| Anthropic API key (AI tutor) | Pay as you go — set a spend limit |
| A domain name (.com or .in) | ~₹600–1,000/year — **required for AdSense** |

---

## 1. Put the code on GitHub

```bash
cd algoorbit
npm install
npm test          # all suites should pass
git init && git add . && git commit -m "AlgoOrbit"
```

Create an empty **private** repo on github.com, then `git remote add origin …` and `git push -u origin main`.

## 2. Supabase — accounts and database

1. supabase.com → **New project**. Pick region **Mumbai (ap-south-1)**. Save the database password somewhere safe.
2. **SQL Editor → New query** → paste all of `supabase/schema.sql` → **Run**. (Safe to re-run.)
3. **Authentication → Sign In / Providers → Email**: keep *Confirm email* on. Set minimum password length to **8**.
4. **Authentication → URL Configuration**
   - Site URL: `https://www.your-domain.com`
   - Redirect URLs: `https://www.your-domain.com/login/`, `https://www.your-domain.com/reset/`, and for local testing `http://localhost:5173/**`
5. **Google sign-in** (optional but recommended):
   - console.cloud.google.com → APIs & Services → **OAuth consent screen** (External, app name *AlgoOrbit*, your email).
   - **Credentials → Create credentials → OAuth client ID → Web application**. Authorized redirect URI: `https://YOUR-PROJECT-REF.supabase.co/auth/v1/callback`
   - Paste the client ID and secret into Supabase → Authentication → Providers → **Google** → Enable.
6. **Project Settings → API Keys**: copy the project URL, the **publishable** key (`sb_publishable_…`) and a **secret** key (`sb_secret_…`). The secret key must never go in browser code or a `VITE_` variable.

## 3. Anthropic — the AI tutor

1. console.anthropic.com → **API keys → Create key**.
2. **Billing → Limits**: set a monthly spend limit (e.g. $5) so a traffic spike can't surprise you.
3. Cost guide: the default model is Claude Haiku 5.5. A typical tutor exchange (~3k tokens in, ~600 out) costs well under a tenth of a cent, so 1,000 messages is on the order of $1. Each account is capped at `TUTOR_DAILY_LIMIT` messages a day (default 30).

## 4. Netlify — go live

Use Netlify: its free plan allows ads. (Vercel's free Hobby plan explicitly forbids AdSense — if you prefer Vercel, `vercel.json` is ready, but you'd need the $20/month Pro plan once ads are on.)

1. app.netlify.com → **Add new site → Import an existing project** → GitHub → pick your repo. The repo's `netlify.toml` sets the build command, output folder, functions and security headers — leave the form defaults.
2. **Site configuration → Environment variables** — add every line from `.env.example` that you have values for:

   | Name | Value |
   | --- | --- |
   | `SITE_URL` | `https://www.your-domain.com` |
   | `CONTACT_EMAIL` | an address you read |
   | `SITE_OWNER` | your name (optional — shown on About) |
   | `VITE_SUPABASE_URL`, `SUPABASE_URL` | Supabase project URL |
   | `VITE_SUPABASE_PUBLISHABLE_KEY` | publishable key |
   | `SUPABASE_SECRET_KEY` | secret key — mark it **secret** |
   | `ANTHROPIC_API_KEY` | your key — mark it **secret** |

3. **Deploys → Trigger deploy**. Open the `*.netlify.app` URL and test: sign up, confirm the email, tick a concept, ask the tutor something.
4. **Domain management → Add a domain** → `your-domain.com`. Use Netlify DNS (simplest) or add the records it shows at your registrar. Make `www.your-domain.com` the primary domain so it matches `SITE_URL`. HTTPS is issued automatically.
5. Redeploy once after the domain works, so the sitemap and canonical URLs use it.
6. Add the new domain's `/login/` and `/reset/` URLs to Supabase's redirect list (step 2.4) if you hadn't yet.

## 5. Google Search — get indexed

1. search.google.com/search-console → **Add property → Domain** → enter `your-domain.com` → add the TXT record it gives you at your registrar → **Verify**.
   (Alternative: URL-prefix property with the *HTML tag* method — put the `content` value in the `GOOGLE_SITE_VERIFICATION` env var and redeploy.)
2. **Sitemaps** → submit `sitemap.xml`.
3. **URL Inspection** → request indexing for `/`, `/learn/` and a few topic pages.
4. Indexing usually takes days to a few weeks. Share the site (college groups, LinkedIn, IEEE chapter) to get the first real visitors.

## 6. AdSense — apply

**Be realistic about timing.** Google decides; nothing in code guarantees approval. What reviewers check, and where this site stands:

| Requirement | Status |
| --- | --- |
| Your own top-level domain (not `*.vercel.app`) | Step 4 |
| Privacy policy with the Google cookie disclosure, About, Contact, Terms | Built in — set `CONTACT_EMAIL` |
| Substantial original content (≈15+ solid articles) | 29 topic articles — **personalise them first (below)** |
| Site indexed and getting some organic traffic | Step 5, then wait |
| You are 18+ with a Google account | You |
| Domain age | Several 2026 approval guides report Google expects Indian domains to be ~6 months old. It isn't in Google's published policy, so treat it as likely rather than certain. |

**Make the content yours before applying.** The topic articles were drafted with AI. Google allows AI-assisted content but rejects sites that look mass-produced. Read each topic, fix anything you'd explain differently, and add something only you can: a worked example from a problem you solved, an interview question you were asked, a diagram. Edit `web/src/content/topics-*.js`, then `npm test` and push.

When ready:

1. adsense.google.com → sign up → **Sites → Add site** → `your-domain.com`.
2. Copy your publisher ID (`ca-pub-…`) into the Netlify env var `ADSENSE_CLIENT` → redeploy. This adds the AdSense script and verification meta tag to content pages and publishes `/ads.txt`.
3. Back in AdSense → **Verify** the site → **Request review**. Reviews take days to a few weeks. If rejected, fix the stated reason and wait at least a couple of weeks before reapplying — repeated quick reapplications can lock you out for longer.
4. **Privacy & messaging → European regulations** → create the consent message (required to serve ads to EEA/UK visitors).
5. After approval: turn on **Auto ads**, or create a *Display* ad unit and put its ID in `ADSENSE_SLOT_ARTICLE` for the in-article slots. Ads never appear on the sign-in, account or tutor pages.

## 7. Before you share it widely

- [ ] Sign up with a second test account and confirm it can't see the first one's progress.
- [ ] Supabase → **Authentication → Rate limits**: keep the defaults; consider enabling **CAPTCHA (Cloudflare Turnstile)** if you see spam sign-ups.
- [ ] Anthropic spend limit set.
- [ ] `CONTACT_EMAIL` is an inbox you check.
- [ ] Review `privacy` and `terms` pages (templates — not legal advice).

## Updating the site

Edit content or code → `npm test` → `git push`. Netlify rebuilds automatically.
