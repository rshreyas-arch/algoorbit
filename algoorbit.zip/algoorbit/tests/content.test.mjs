import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TOPICS, ORBITS, QUIZZES, XP } from '../web/src/content/index.js';

test('topic ids unique, orbits valid, prereqs earlier and existing', () => {
  const seen = new Set();
  const orbitIds = new Set(ORBITS.map((o) => o.id));
  for (const t of TOPICS) {
    assert.ok(!seen.has(t.id), `duplicate id ${t.id}`);
    assert.ok(orbitIds.has(t.orbit), `bad orbit ${t.orbit}`);
    for (const p of t.prereqs) assert.ok(seen.has(p), `${t.id}: prereq ${p} must appear earlier`);
    seen.add(t.id);
    assert.match(t.id, /^[a-z0-9-]+$/);
    for (const key of ['title', 'short', 'summary', 'intro', 'concepts', 'complexity', 'patterns', 'code', 'pitfalls', 'problems'])
      assert.ok(t[key], `${t.id} missing ${key}`);
    assert.ok(t.concepts.length >= 5, `${t.id} needs ≥5 concepts`);
    assert.ok(t.problems.length >= 4, `${t.id} needs ≥4 problems`);
    for (const p of t.patterns) assert.equal(p.length, 3, `${t.id} pattern shape`);
  }
});

test('problem slugs unique and well formed', () => {
  const seen = new Map();
  for (const t of TOPICS)
    for (const [slug, , diff] of t.problems) {
      assert.match(slug, /^[a-z0-9-]+$/, slug);
      assert.ok(['E', 'M', 'H'].includes(diff), `${slug} difficulty`);
      assert.ok(!seen.has(slug), `${slug} in both ${seen.get(slug)} and ${t.id}`);
      seen.set(slug, t.id);
    }
});

test('python templates compile', () => {
  const dir = mkdtempSync(join(tmpdir(), 'py-'));
  for (const t of TOPICS) {
    const f = join(dir, `${t.id.replace(/-/g, '_')}.py`);
    writeFileSync(f, t.code.python);
    execFileSync('python3', ['-m', 'py_compile', f]);
  }
});

test('c++ templates compile', () => {
  const dir = mkdtempSync(join(tmpdir(), 'cpp-'));
  for (const t of TOPICS) {
    const f = join(dir, `${t.id}.cpp`);
    writeFileSync(f, `#include <bits/stdc++.h>\nusing namespace std;\n${t.code.cpp}\n`);
    try {
      execFileSync('g++', ['-std=c++17', '-fsyntax-only', '-Wall', f], { stdio: 'pipe' });
    } catch (e) {
      assert.fail(`${t.id}: ${e.stderr}`);
    }
  }
});

test('pitfall HTML only uses <code> tags', () => {
  for (const t of TOPICS)
    for (const p of t.pitfalls)
      assert.doesNotMatch(p.replace(/<\/?code>/g, ''), /[<>]/, `${t.id}: escape < and > in "${p}"`);
});

test('every topic has a three-question quick check with one right answer each', () => {
  assert.deepEqual(Object.keys(QUIZZES).sort(), TOPICS.map((t) => t.id).sort());
  assert.ok(XP.quiz > 0);
  for (const [id, questions] of Object.entries(QUIZZES)) {
    assert.equal(questions.length, 3, `${id} needs 3 questions`);
    for (const [q, options, answer, why] of questions) {
      assert.ok(q.length > 15 && why.length > 15, `${id}: question and explanation text`);
      assert.equal(options.length, 4, `${id}: "${q}" needs 4 options`);
      assert.equal(new Set(options).size, 4, `${id}: "${q}" has duplicate options`);
      assert.ok(Number.isInteger(answer) && answer >= 0 && answer < 4, `${id}: answer index`);
    }
  }
  // The quick check is stored as "<topic>:p:quiz", so no real problem may use that slug.
  for (const t of TOPICS) assert.ok(!t.problems.some(([slug]) => slug === 'quiz'));
});
