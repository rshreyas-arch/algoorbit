// Runs supabase/schema.sql inside an embedded Postgres with Supabase-like roles and defaults,
// then tries to read and write other users' data. Every attack below must fail.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { PGlite } from '@electric-sql/pglite';

const A = '11111111-1111-4111-8111-111111111111';
const B = '22222222-2222-4222-8222-222222222222';
const C = '33333333-3333-4333-8333-333333333333';

const PRELUDE = `
create role anon nologin;
create role authenticated nologin;
create role service_role nologin bypassrls;
create schema auth;
create table auth.users (id uuid primary key, email text, raw_user_meta_data jsonb not null default '{}'::jsonb);
create function auth.uid() returns uuid language sql stable as
  $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
grant usage on schema public, auth to anon, authenticated, service_role;
grant execute on function auth.uid() to anon, authenticated, service_role;
-- Supabase's defaults: API roles get broad privileges on new objects; RLS is what protects data.
alter default privileges in schema public grant all on tables to anon, authenticated, service_role;
alter default privileges in schema public grant all on functions to anon, authenticated, service_role;
`;

let db;
async function as(role, uid, sql, params) {
  await db.exec(`reset role; select set_config('request.jwt.claim.sub', '${uid || ''}', false); set role ${role};`);
  try { return await db.query(sql, params); } finally { await db.exec('reset role;'); }
}
const rejects = (p, re) => assert.rejects(p, re);

test.before(async () => {
  db = new PGlite();
  await db.exec(PRELUDE);
  const schema = fs.readFileSync(new URL('../supabase/schema.sql', import.meta.url), 'utf8');
  await db.exec(schema);
  await db.exec(schema); // idempotent re-run
  await db.query(`insert into auth.users (id, email, raw_user_meta_data) values ($1, 'asha@example.com', '{"display_name":"Asha"}'), ($2, 'ben@example.com', '{}'), ($3, 'chen@example.com', '{"full_name":"Chen Li"}')`, [A, B, C]);
});

test('sign-up trigger creates profiles', async () => {
  const { rows } = await db.query('select id, display_name from public.profiles order by display_name');
  assert.deepEqual(rows.map((r) => r.display_name).sort(), ['Asha', 'Chen Li', 'ben']);
});

test('users can write and read only their own progress', async () => {
  await as('authenticated', A, `insert into public.progress (item_id) values ('arrays:c1'), ('arrays:p:two-sum')`);
  await as('authenticated', B, `insert into public.progress (item_id) values ('graphs:c2')`);
  const a = await as('authenticated', A, 'select user_id, item_id from public.progress order by item_id');
  assert.equal(a.rows.length, 2);
  assert.ok(a.rows.every((r) => r.user_id === A));
});

test('guest-progress merge (insert … on conflict do nothing) works under RLS', async () => {
  const r = await as('authenticated', B, `insert into public.progress (user_id, item_id) values ($1, 'graphs:c2'), ($1, 'graphs:c3') on conflict (user_id, item_id) do nothing`, [B]);
  assert.equal(r.affectedRows, 1);
});

test('cannot insert progress for another user', async () => {
  await rejects(as('authenticated', A, `insert into public.progress (user_id, item_id) values ($1, 'arrays:c2')`, [B]), /row-level security/);
});

test('cannot delete or update another user\'s progress', async () => {
  const del = await as('authenticated', A, `delete from public.progress where user_id = $1`, [B]);
  assert.equal(del.affectedRows, 0);
  await rejects(as('authenticated', A, `update public.progress set completed_at = now()`), /permission denied/);
  const { rows } = await db.query(`select count(*)::int as n from public.progress where user_id = $1`, [B]);
  assert.equal(rows[0].n, 2);
});

test('anonymous visitors cannot read anything', async () => {
  await rejects(as('anon', '', 'select * from public.progress'), /permission denied/);
  await rejects(as('anon', '', 'select * from public.profiles'), /permission denied/);
  await rejects(as('anon', '', 'select * from public.tutor_usage'), /permission denied/);
});

test('malformed item ids and future timestamps are rejected', async () => {
  await rejects(as('authenticated', A, `insert into public.progress (item_id) values ('<script>')`), /check constraint/);
  await rejects(as('authenticated', A, `insert into public.progress (item_id, completed_at) values ('arrays:c3', now() + interval '30 days')`), /check constraint/);
});

test('profiles: update own name only, and only the name', async () => {
  await as('authenticated', A, `update public.profiles set display_name = 'Asha R' where id = $1`, [A]);
  const other = await as('authenticated', A, `update public.profiles set display_name = 'hacked' where id = $1`, [B]);
  assert.equal(other.affectedRows, 0);
  await rejects(as('authenticated', A, `update public.profiles set created_at = now() where id = $1`, [A]), /permission denied/);
  await rejects(as('authenticated', A, `update public.profiles set display_name = '' where id = $1`, [A]), /check constraint/);
  const seen = await as('authenticated', A, 'select display_name from public.profiles');
  assert.deepEqual(seen.rows, [{ display_name: 'Asha R' }]);
});

test('tutor quota: only the server can consume it, and the limit holds', async () => {
  await rejects(as('authenticated', A, 'select public.consume_tutor_quota($1, 100)', [A]), /permission denied/);
  await rejects(as('authenticated', A, `insert into public.tutor_usage (user_id, count) values ($1, 0)`, [A]), /permission denied/);
  const results = [];
  for (let i = 0; i < 3; i++) {
    const r = await as('service_role', '', 'select public.consume_tutor_quota($1, 2) as left', [A]);
    results.push(r.rows[0].left);
  }
  assert.deepEqual(results, [1, 0, -1]);
  await as('service_role', '', 'select public.refund_tutor_quota($1)', [A]);
  const again = await as('service_role', '', 'select public.consume_tutor_quota($1, 2) as left', [A]);
  assert.equal(again.rows[0].left, 0);
  const own = await as('authenticated', B, 'select * from public.tutor_usage');
  assert.equal(own.rows.length, 0, 'B cannot see A\'s usage');
});

test('per-user row cap stops table stuffing', async () => {
  await db.exec(`reset role; select set_config('request.jwt.claim.sub', '${C}', false); set role authenticated;`);
  try {
    await db.exec(`insert into public.progress (item_id) select 'y' || g || ':c1' from generate_series(1, 600) g`);
    await rejects(db.exec(`insert into public.progress (item_id) values ('z:c1')`), /progress limit reached/);
  } finally { await db.exec('reset role;'); }
});

test('deleting the auth user removes all their data', async () => {
  await db.query('delete from auth.users where id = $1', [A]);
  for (const t of ['profiles', 'progress', 'tutor_usage']) {
    const col = t === 'profiles' ? 'id' : 'user_id';
    const { rows } = await db.query(`select count(*)::int as n from public.${t} where ${col} = $1`, [A]);
    assert.equal(rows[0].n, 0, `${t} not cleaned up`);
  }
});
