// Exercises the serverless handlers with a fake network: Supabase auth/RPC and the Anthropic API.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createTutorHandler, normaliseMessages, buildSystemPrompt } from '../server/tutor.js';
import { createDeleteAccountHandler } from '../server/delete-account.js';

const ENV = {
  SUPABASE_URL: 'https://proj.supabase.co',
  SUPABASE_SECRET_KEY: 'sb_secret_test',
  ANTHROPIC_API_KEY: 'sk-ant-test',
  TUTOR_DAILY_LIMIT: '5',
};
const USER = { id: '11111111-1111-4111-8111-111111111111', email: 'a@example.com', aud: 'authenticated', role: 'authenticated' };

function sse(texts, stop = 'end_turn') {
  const ev = (type, data) => `event: ${type}\ndata: ${JSON.stringify({ type, ...data })}\n\n`;
  return ev('message_start', { message: { id: 'msg_1', type: 'message', role: 'assistant', content: [], model: 'm', stop_reason: null, stop_sequence: null, usage: { input_tokens: 1, output_tokens: 1 } } })
    + ev('content_block_start', { index: 0, content_block: { type: 'text', text: '' } })
    + texts.map((t) => ev('content_block_delta', { index: 0, delta: { type: 'text_delta', text: t } })).join('')
    + ev('content_block_stop', { index: 0 })
    + ev('message_delta', { delta: { stop_reason: stop, stop_sequence: null }, usage: { output_tokens: 5 } })
    + ev('message_stop', {});
}

function fakeNet({ quota = 4, anthropicStatus = 200, texts = ['Think about ', '**hash maps**.'], stop } = {}) {
  const calls = [];
  const fetchImpl = async (input, init = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    const headers = new Headers(init.headers || (typeof input === 'object' ? input.headers : undefined));
    const body = init.body ? JSON.parse(init.body) : null;
    calls.push({ url, method: init.method || 'GET', headers, body });
    if (url.endsWith('/auth/v1/user')) {
      return headers.get('authorization') === 'Bearer good.token.value'
        ? Response.json(USER)
        : Response.json({ code: 401, msg: 'invalid JWT' }, { status: 401 });
    }
    if (url.includes('/rest/v1/rpc/consume_tutor_quota')) return Response.json(quota);
    if (url.includes('/rest/v1/rpc/refund_tutor_quota')) return new Response(null, { status: 204 });
    if (url.includes('/auth/v1/admin/users/')) return Response.json({});
    if (url.startsWith('https://api.anthropic.com/v1/messages')) {
      if (anthropicStatus !== 200) return Response.json({ type: 'error', error: { type: 'overloaded_error', message: 'busy' } }, { status: anthropicStatus });
      return new Response(sse(texts, stop), { headers: { 'content-type': 'text/event-stream' } });
    }
    throw new Error(`unexpected fetch ${url}`);
  };
  return { fetchImpl, calls };
}

const req = (body, { token = 'good.token.value', origin, method = 'POST' } = {}) => new Request('https://algoorbit.example/api/tutor', {
  method,
  headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}), ...(origin ? { origin } : {}) },
  body: method === 'POST' ? JSON.stringify(body) : undefined,
});
const good = { mode: 'hint', topic: 'hashing', messages: [{ role: 'user', content: 'How do I speed up two sum?' }] };

test('streams the reply and reports remaining quota', async () => {
  const net = fakeNet();
  const res = await createTutorHandler({ env: ENV, fetch: net.fetchImpl })(req(good, { origin: 'https://algoorbit.example' }));
  assert.equal(res.status, 200);
  assert.equal(res.headers.get('x-tutor-remaining'), '4');
  assert.equal(await res.text(), 'Think about **hash maps**.');
  const ai = net.calls.find((c) => c.url.startsWith('https://api.anthropic.com'));
  assert.ok(ai.headers.get('x-api-key') === 'sk-ant-test' || ai.headers.get('authorization') === 'Bearer sk-ant-test', 'API key sent');
  assert.equal(ai.body.model, 'claude-haiku-5-5');
  assert.equal(ai.body.stream, true);
  assert.match(ai.body.system, /Mode: HINT/);
  assert.match(ai.body.system, /Hash Maps & Sets/);
  assert.deepEqual(ai.body.messages, good.messages);
  const rpc = net.calls.find((c) => c.url.includes('consume_tutor_quota'));
  assert.deepEqual(rpc.body, { p_user_id: USER.id, p_limit: 5 });
});

test('rejects missing or invalid tokens before spending anything', async () => {
  for (const token of [null, 'bad.token.value']) {
    const net = fakeNet();
    const res = await createTutorHandler({ env: ENV, fetch: net.fetchImpl })(req(good, { token }));
    assert.equal(res.status, 401);
    assert.ok(!net.calls.some((c) => c.url.includes('anthropic') || c.url.includes('rpc')));
  }
});

test('rejects cross-origin browser requests', async () => {
  const net = fakeNet();
  const res = await createTutorHandler({ env: ENV, fetch: net.fetchImpl })(req(good, { origin: 'https://evil.example' }));
  assert.equal(res.status, 403);
  assert.equal(net.calls.length, 0);
});

test('enforces the daily limit', async () => {
  const net = fakeNet({ quota: -1 });
  const res = await createTutorHandler({ env: ENV, fetch: net.fetchImpl })(req(good));
  assert.equal(res.status, 429);
  assert.match((await res.json()).error, /all 5 tutor messages/);
  assert.ok(!net.calls.some((c) => c.url.includes('anthropic')));
});

test('refunds quota when the model is unavailable', async () => {
  const net = fakeNet({ anthropicStatus: 529 });
  const res = await createTutorHandler({ env: ENV, fetch: net.fetchImpl })(req(good));
  assert.equal(res.status, 503);
  assert.ok(net.calls.some((c) => c.url.includes('refund_tutor_quota')));
});

test('notes truncated replies', async () => {
  const net = fakeNet({ texts: ['partial'], stop: 'max_tokens' });
  const res = await createTutorHandler({ env: ENV, fetch: net.fetchImpl })(req(good));
  assert.match(await res.text(), /cut short/);
});

test('validates input', async () => {
  const handler = createTutorHandler({ env: ENV, fetch: fakeNet().fetchImpl });
  assert.equal((await handler(req(good, { method: 'GET' }))).status, 405);
  assert.equal((await handler(req({ messages: [] }))).status, 400);
  assert.equal((await handler(req({ messages: [{ role: 'system', content: 'x' }] }))).status, 400);
  assert.equal((await handler(req({ messages: [{ role: 'user', content: 'x'.repeat(7000) }] }))).status, 400);
  assert.equal((await handler(req({ messages: [{ role: 'user', content: 'hi' }, { role: 'assistant', content: 'yo' }] }))).status, 400);
});

test('returns 503 when not configured', async () => {
  const res = await createTutorHandler({ env: {}, fetch: fakeNet().fetchImpl })(req(good));
  assert.equal(res.status, 503);
});

test('normaliseMessages merges, trims and keeps a user turn first and last', () => {
  const { messages } = normaliseMessages([
    { role: 'assistant', content: 'stale' },
    { role: 'user', content: 'a' }, { role: 'user', content: 'b' },
    { role: 'assistant', content: 'c' }, { role: 'user', content: '  d  ' },
  ]);
  assert.deepEqual(messages, [{ role: 'user', content: 'a\n\nb' }, { role: 'assistant', content: 'c' }, { role: 'user', content: 'd' }]);
  const long = Array.from({ length: 10 }, (_, i) => ({ role: i % 2 ? 'assistant' : 'user', content: 'x'.repeat(5000) }));
  long.push({ role: 'user', content: 'last' });
  const r = normaliseMessages(long.slice(-11));
  assert.ok(r.messages.reduce((n, m) => n + m.content.length, 0) <= 24000);
  assert.equal(r.messages[0].role, 'user');
});

test('system prompt modes', () => {
  assert.match(buildSystemPrompt('explain', null), /Mode: EXPLAIN/);
  assert.match(buildSystemPrompt('review', 'graphs'), /Mode: REVIEW[\s\S]*Graph Traversal/);
  assert.doesNotMatch(buildSystemPrompt('hint', 'not-a-topic'), /currently studying/);
});

test('delete-account removes only the caller', async () => {
  const net = fakeNet();
  const handler = createDeleteAccountHandler({ env: ENV, fetch: net.fetchImpl });
  assert.equal((await handler(req(null, { token: 'bad.token.value' }))).status, 401);
  const res = await handler(req(null));
  assert.equal(res.status, 200);
  const del = net.calls.find((c) => c.url.includes('/auth/v1/admin/users/') && c.method === 'DELETE');
  assert.equal(del.method, 'DELETE');
  assert.ok(del.url.endsWith(`/auth/v1/admin/users/${USER.id}`));
});
