import { json, readEnv, originAllowed, adminClient, authenticate } from './common.js';

/** Deletes the caller's own auth user. Profile, progress and usage rows cascade via foreign keys. */
export function createDeleteAccountHandler(deps = {}) {
  return async function handle(request) {
    const cfg = readEnv(deps.env);
    if (request.method !== 'POST') return json(405, { error: 'Use POST.' }, { Allow: 'POST' });
    if (!originAllowed(request, cfg)) return json(403, { error: 'Cross-origin requests are not allowed.' });
    if (!cfg.supabaseUrl || !cfg.supabaseSecret) return json(503, { error: 'Accounts are not configured on this server.' });

    const admin = adminClient(cfg, deps.fetch);
    const user = await authenticate(request, admin);
    if (!user) return json(401, { error: 'Sign in again before deleting your account' });

    const { error } = await admin.auth.admin.deleteUser(user.id);
    if (error) {
      console.error('delete user failed', error.message);
      return json(500, { error: 'Could not delete the account' });
    }
    return json(200, { ok: true });
  };
}
