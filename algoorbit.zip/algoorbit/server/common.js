import { createClient } from '@supabase/supabase-js';

export function json(status, body, headers = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers },
  });
}

export function readEnv(env = process.env) {
  return {
    supabaseUrl: env.SUPABASE_URL || env.VITE_SUPABASE_URL || '',
    supabaseSecret: env.SUPABASE_SECRET_KEY || env.SUPABASE_SERVICE_ROLE_KEY || '',
    anthropicKey: env.ANTHROPIC_API_KEY || '',
    anthropicBaseUrl: env.ANTHROPIC_BASE_URL || undefined,
    model: env.ANTHROPIC_MODEL || 'claude-haiku-5-5',
    dailyLimit: Math.max(1, Number.parseInt(env.TUTOR_DAILY_LIMIT || '30', 10) || 30),
    allowedOrigins: (env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
  };
}

/** Browsers send Origin on POST; only accept our own origin (or an explicit allow-list). */
export function originAllowed(request, cfg) {
  const origin = request.headers.get('origin');
  if (!origin) return true; // non-browser client; the bearer token still has to be valid
  if (cfg.allowedOrigins.includes(origin)) return true;
  let originHost;
  try { originHost = new URL(origin).host; } catch { return false; }
  const hosts = [new URL(request.url).host, request.headers.get('x-forwarded-host'), request.headers.get('host')];
  return hosts.some((h) => h && h.split(',')[0].trim() === originHost);
}

export function adminClient(cfg, fetchImpl) {
  return createClient(cfg.supabaseUrl, cfg.supabaseSecret, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
    global: fetchImpl ? { fetch: fetchImpl } : undefined,
  });
}

/** Verify the caller's Supabase access token. Returns the user or null. */
export async function authenticate(request, admin) {
  const header = request.headers.get('authorization') || '';
  const m = header.match(/^Bearer\s+([A-Za-z0-9\-_.]+)$/);
  if (!m) return null;
  const { data, error } = await admin.auth.getUser(m[1]);
  if (error || !data?.user) return null;
  return data.user;
}
